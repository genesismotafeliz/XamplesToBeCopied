﻿
namespace IDelitySolutions
{
    using Xamarin.Forms;

    public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
