DataAccessLayer
===============

An implementation of a Data Access Layer utilizing Entity Framework. 
Includes popular patterns like Unit Of Work (UoW) and Repository in conjunction with Entity Framework (EF).

