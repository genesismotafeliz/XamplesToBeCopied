﻿var ViewModel = function() {};

ViewModel.prototype.CreatedAt = ko.observable();
ViewModel.prototype.UpdatedAt = ko.observable();
ViewModel.prototype.CreatedBy = ko.observable();
ViewModel.prototype.UpdatedBy = ko.observable();