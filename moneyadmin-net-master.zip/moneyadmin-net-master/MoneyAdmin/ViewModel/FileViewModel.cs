﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MoneyAdmin.ViewModel
{
    public class FileViewModel : BaseViewModel
    {

    }
}
