Social company - January 2013
======

VIDEO YOUTUBE : https://www.youtube.com/watch?v=3v4-NQYpS7M

======

Social network for businesses. A Social network where coworkers with a same email address can by the main company feed or a custom created group share status updates, like a status, comment and post images.

Folder "ZoombuM1": application <br />
Folder "ZoombuM1Service": webservice + dal

Technologies: ASP MVC 4, Entity Framework, jQuery

