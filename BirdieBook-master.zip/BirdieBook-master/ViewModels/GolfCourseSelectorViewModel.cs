﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BirdieBook.Models;

namespace BirdieBook.ViewModels
{
    public class GolfCourseSelectorViewModel
    {
        public GolfCourse GolfCourse;
    }
}
