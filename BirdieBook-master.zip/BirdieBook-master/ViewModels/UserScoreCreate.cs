﻿namespace BirdieBook.ViewModels
{
    public class UserScoreCreate
    {
        public string UserRoundId { get; set; }
        public string TeeBoxId { get; set; }
        public int HoleNumber { get; set; }
    }
}
