﻿using Microsoft.AspNetCore.Mvc;

namespace BirdieBook.Controllers
{
    public class SocialController : Controller
    {
        public IActionResult Index()
        {
            throw new System.NotImplementedException();
        }
    }
}