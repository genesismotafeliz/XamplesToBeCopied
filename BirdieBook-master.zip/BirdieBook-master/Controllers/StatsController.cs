﻿using Microsoft.AspNetCore.Mvc;

namespace BirdieBook.Controllers
{
    public class StatsController : Controller
    {
        public IActionResult Index()
        {
            throw new System.NotImplementedException();
        }
    }
}