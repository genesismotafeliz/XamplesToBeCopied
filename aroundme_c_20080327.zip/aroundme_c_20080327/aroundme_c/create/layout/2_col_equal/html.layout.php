<style type="text/css">

#left {
    float: left;
    margin-left: 2%;
    width: 49%;
}

#right {
    float: left;
    width: 49%;
}

</style>


<div id="left">
    <!-- START OF LEFT COLUMN -->

    <!-- END OF LEFT COLUMN -->
</div>

<div id="right">
    <!-- START OF RIGHT COLUMN -->

    <!-- END OF RIGHT COLUMN -->
</div>

<div style="clear:both;"></div>
