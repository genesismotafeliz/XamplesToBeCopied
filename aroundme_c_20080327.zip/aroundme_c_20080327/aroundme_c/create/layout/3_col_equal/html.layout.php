<style type="text/css">

#left {
    float: left;
    margin-left: 2%;
    width: 28%;
}

#middle {
    float: left;
    margin-left: 2%;
    width: 36%;
}

#right {
    float: left;
    margin-left: 2%;
    width: 28%;
}

</style>


<div id="left">
    <!-- START OF LEFT COLUMN -->

    <!-- END OF LEFT COLUMN -->
</div>


<div id="middle">
    <!-- START OF MIDDLE COLUMN -->

    <!-- END OF MIDDLE COLUMN -->
</div>


<div id="right">
<!-- START OF RIGHT COLUMN -->

<!-- END OF RIGHT COLUMN -->
</div>

<div style="clear:both;"></div>
