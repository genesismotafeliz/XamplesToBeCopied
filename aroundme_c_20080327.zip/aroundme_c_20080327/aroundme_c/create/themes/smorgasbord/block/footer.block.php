<div id="footer">
    <p>This work is licensed under a <a href="http://www.gnu.org/copyleft/fdl.html">GNU Free Documentation License</a>.  Made with <a href="http://www.barnraiser.org/">AROUNDMe collaboration server</a>.</p>
</div>