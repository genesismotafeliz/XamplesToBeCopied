<AM_BLOCK plugin="custom" name="navigation" />

<div id="col_left_520">
    <h1>Discussion</h1>
    <AM_BLOCK plugin="barnraiser_forum" name="subject" />
</div>

<div id="col_right_320">
    <h1>Connections</h1>
    <AM_BLOCK plugin="barnraiser_connection" name="gallery" limit="16" />
    <h1>Forum</h1>
    <AM_BLOCK plugin="barnraiser_forum" name="subject_search" />
    <ul>
      <li><a href="index.php?wp=forum">List all discussions</a></li>
    </ul>
    <h1>Tags</h1>
    <AM_BLOCK plugin="barnraiser_forum" name="tagcloud" />
    <h1>Connect</h1>
    <AM_BLOCK plugin="barnraiser_connection" name="connect" />
</div>

<div style="clear:both;"></div>

<AM_BLOCK plugin="custom" name="footer" />