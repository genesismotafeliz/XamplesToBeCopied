<AM_BLOCK plugin="custom" name="navigation" />

<div id="col_left_520">
    <h1>Wiki</h1>
    <AM_BLOCK plugin="barnraiser_wiki" name="page" wikipage="wikihome" />
</div>

<div id="col_right_320">
    <h1>Wiki page history</h1>
    <AM_BLOCK plugin="barnraiser_wiki" name="history" limit="10" />

</div>

<div style="clear:both;"></div>

<AM_BLOCK plugin="custom" name="footer" />