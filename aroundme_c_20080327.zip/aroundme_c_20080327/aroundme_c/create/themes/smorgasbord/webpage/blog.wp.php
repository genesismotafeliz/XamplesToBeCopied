<AM_BLOCK plugin="custom" name="navigation" />

<div id="col_left_520">
    <h1>Blog</h1>
    <AM_BLOCK plugin="barnraiser_blog" name="entry"  />
</div>

<div id="col_right_320">
    <h1>Connections</h1>
    <AM_BLOCK plugin="barnraiser_connection" name="gallery" limit="21" />
    <h1>Connect</h1>
    <AM_BLOCK plugin="barnraiser_connection" name="connect" />
    <h1>Latest entries</h1>
    <AM_BLOCK plugin="barnraiser_blog" name="list" limit="6" trim="140"  />

</div>

<div style="clear:both;"></div>

<AM_BLOCK plugin="custom" name="footer" />