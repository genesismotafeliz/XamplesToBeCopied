Hi AM_SYS_KEYWORD_RECIPIENT_NICKNAME,

The following discussion has received a reply:

AM_KEYWORD_SUBJECT_TITLE

From AM_KEYWORD_SUBJECT_REPLY_NICKNAME: AM_KEYWORD_SUBJECT_REPLY_DATETIME

AM_KEYWORD_SUBJECT_REPLY_BODY

View this discussion: AM_KEYWORD_SUBJECT_URL
Remove this notification: AM_KEYWORD_REMOVE_NOTIFICATION_URL


This email was sent from AM_KEYWORD_WEBSPACE_TITLE using Barnraisers AROUNDMe collaboration server; the perfect solution for anyone wishing to create a collaborative social space on the Web.

AM_KEYWORD_WEBSPACE_URL
http://www.barnraiser.org
