Hi AM_SYS_KEYWORD_RECIPIENT_NICKNAME,

This is your digest from AM_KEYWORD_WEBSPACE_TITLE ( AM_KEYWORD_WEBSPACE_URL ).


<tracked_subjects>
Tracked discussions
<tracked_subjects_loop>
AM_KEYWORD_TRACKED_SUBJECT_TITLE
AM_KEYWORD_TRACKED_SUBJECT_URL
Author: AM_KEYWORD_TRACKED_SUBJECT_AUTHOR, published: AM_KEYWORD_TRACKED_SUBJECT_CREATE_DATETIME
Received AM_KEYWORD_TRACKED_SUBJECT_REPLIES replies since you last connected (AM_KEYWORD_TRACKED_SUBJECT_REPLIES_TOTAL in total).

</tracked_subjects_loop>

.........................................................................

</tracked_subjects>

<new_subjects>
New discussions
<new_subjects_loop>
AM_KEYWORD_NEW_SUBJECT_TITLE
AM_KEYWORD_NEW_SUBJECT_URL
Author: AM_KEYWORD_NEW_SUBJECT_AUTHOR, published: AM_KEYWORD_NEW_SUBJECT_CREATE_DATETIME
Received AM_KEYWORD_NEW_SUBJECT_REPLIES_TOTAL replies in total.

</new_subjects_loop>

.........................................................................

</new_subjects>

<new_posts>
New replies
<new_posts_loop>
AM_KEYWORD_NEW_POST_TITLE
AM_KEYWORD_NEW_POST_URL
Author: AM_KEYWORD_NEW_POST_AUTHOR, published: AM_KEYWORD_NEW_POST_CREATE_DATETIME
Reply: AM_KEYWORD_NEW_POST_BODY

</new_posts_loop>

.........................................................................
</new_posts>

Connection activity
AM_SYS_KEYWORD_CONNECTION_TOTAL people have connected to this webspace. AM_SYS_KEYWORD_CONNECTION_PERIOD_TOTAL connections are new since your last digest. You last connected on AM_KEYWORD_LAST_CONNECTION_DATETIME.

.........................................................................


Go to webspace: AM_KEYWORD_WEBSPACE_URL
Cancel this digest email: AM_KEYWORD_REMOVE_DIGEST_URL

This digest email was sent from AM_KEYWORD_WEBSPACE_TITLE using Barnraisers AROUNDMe collaboration server; the perfect solution for anyone wishing to create a collaborative social space on the Web.

AM_KEYWORD_WEBSPACE_URL
http://www.barnraiser.org