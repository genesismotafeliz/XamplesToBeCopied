// -----------------------------------------------------------------------
// This file is part of AROUNDMe
// 
// Copyright (C) 2003-2008 Barnraiser
// http://www.barnraiser.org/
// info@barnraiser.org
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; see the file COPYING.txt.  If not, see
// <http://www.gnu.org/licenses/>
// -----------------------------------------------------------------------


>> WELCOME
   Welcome to AROUNDMe collaboration server. AROUNDMe collaboration
   server is the perfect solution for anyone wishing to create
   collaborative social space on the Web. See the instructions in
   "documents/INSTALL.txt" to install it or "documents/UPGRADE.txt"
   to upgrade from the previous version.


>> COPYING
   See the "documents/COPYING.txt" file for instructions.
   Please note, all images showing "AROUNDMe" or "Barnraiser" logos are a 
   trademark of Barnraiser. You can distribute them under the terms of the 
   copy license, however you are forbidden to alter them.


>> SUPPORT US
   This software is maintained by Barnraiser. We are a network of people
   who have come together to give you the tools you need to share knowledge
   and collaborate around shared interests. All our software is free. We
   are funded from donations in support of our project and development
   activities. If you would like to consider donating to us you will find
   a donate button on our web page - http://www.barnraiser.org/

// DOCUMENT ENDS -------------------------------------------------------