﻿namespace Products1.Droid
{
    public class Constants
    {
        public const string SenderID = "638797791519"; // Google API Project Number
        public const string ListenConnectionString = "Endpoint=" +
            "sb://productsclass.servicebus.windows.net/;" +
            "SharedAccessKeyName=DefaultFullSharedAccessSignature;" +
            "SharedAccessKey=H8SNoyeqmGwTUpenZ2DArE9mLhHS3WrAFPL96wpwp6s=";
        public const string NotificationHubName = "ProductsClass";
    }
}
