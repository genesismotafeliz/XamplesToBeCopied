﻿namespace Products1.Models
{
    public class UserRequest
    {
        public string Email
        {
            get;
            set;
        }
    }
}
