﻿namespace Products1.Views
{
    using Xamarin.Forms;

	public partial class NewCustomerView : ContentPage
    {
        public NewCustomerView()
        {
            InitializeComponent();
        }
    }
}
