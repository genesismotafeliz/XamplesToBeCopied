﻿namespace Products1.Views
{
    using Xamarin.Forms;

	public partial class EditProductView : ContentPage
    {
        public EditProductView()
        {
            InitializeComponent();
        }
    }
}
