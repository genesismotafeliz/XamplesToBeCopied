﻿namespace Products1.Views
{
    using Xamarin.Forms;

	public partial class NewProductView : ContentPage
    {
        public NewProductView()
        {
            InitializeComponent();
        }
    }
}
