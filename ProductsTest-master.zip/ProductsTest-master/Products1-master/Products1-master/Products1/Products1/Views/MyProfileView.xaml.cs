﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class MyProfileView : ContentPage
    {
        public MyProfileView()
        {
            InitializeComponent();
        }
    }
}
