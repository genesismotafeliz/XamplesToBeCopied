﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class ProductsView : ContentPage
    {
        public ProductsView()
        {
            InitializeComponent();
        }
    }
}
