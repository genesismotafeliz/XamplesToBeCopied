﻿namespace Products1.Views
{
    using Xamarin.Forms;

    public partial class SyncView : ContentPage
    {
        public SyncView()
        {
            InitializeComponent();
        }
    }
}
