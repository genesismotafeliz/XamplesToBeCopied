﻿namespace Products1.Interfaces
{
    public interface IRegisterDevice
    {
        void RegisterDevice();
    }
}
