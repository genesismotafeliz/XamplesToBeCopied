﻿namespace Products1.Backend.Models
{
    using Domain;

    public class DataContextLocal : DataContext
    {
    }
}