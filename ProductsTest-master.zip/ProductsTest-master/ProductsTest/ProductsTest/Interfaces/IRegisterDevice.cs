﻿namespace ProductsTest.Interfaces
{
    public interface IRegisterDevice
    {
        void RegisterDevice();
    }
}
