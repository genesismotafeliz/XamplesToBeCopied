﻿namespace ProductsTest.BackEnd.Models
{
    using ProductsTest.Domain;

    public class DataContextLocal : DataContext
    {
        
    }
}