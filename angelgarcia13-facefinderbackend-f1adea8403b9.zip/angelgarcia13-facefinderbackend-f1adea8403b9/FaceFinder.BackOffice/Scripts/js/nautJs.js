﻿$(document).ready(function () {
    //Check if there is a message to show.
    if ($('#IsError').length > 0) {
        var messageType = "success";
        var messageText = $('#Message').text();
        if ($('#IsError').text() == "True") {
            messageType = "error";
        }
        swal("", messageText, messageType);
    }


});