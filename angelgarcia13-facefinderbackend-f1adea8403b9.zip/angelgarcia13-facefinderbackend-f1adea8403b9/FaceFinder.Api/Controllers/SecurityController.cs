﻿using FaceFinder.Data.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FaceFinder.Api.Controllers
{
    public class SecurityController : Controller
    {
        /*
        // GET: Security/ResetLink
        [HttpGet]
        [Route("ResetLink", Name = "ResetLink")]
        public ActionResult ResetLink(string userId, string code)
        {
            ViewBag.valid = true;
            ViewBag.userId = userId;
            ViewBag.code = code;
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(code))
            {
                ViewBag.valid = false;
            }
            else
            {
                using (var db = new ApplicationDbContext())
                {
                    var userFound = db.Users.Find(userId);
                    if (userFound == null)
                    {
                        ViewBag.valid = false;
                    }
                }

            }

            return View();
        }
        */
    }
}