# Proyecto-final
Proyecto que hace cosas que pidio el profesor en la materia de programacion estructurada C Seccion 0463, grupo: Los Lideres , Integrantes: Yandry Mateo 13-EIIT-1-049, Anyeli Mora 17-EIIN-1-175, Scarlen Jimenez 17-EIIN-1-065
