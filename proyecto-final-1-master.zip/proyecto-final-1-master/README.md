# proyecto-final
Proyecto final, proyecto que hace lo que pidio el profesor, sección: 0463, grupo: los duros, integrantes: Katherine Martinez 17-MIIN-1-116  Celia Trinidad 17-MIINT-1-022  Josue Alix 17-MIIN-1-145 
