# ChatXF
Aplicación de Chat con Xamarin Forms.

Posibles soluciones a problemas de compilación
	- Actualizar Xamarin for Visual Studio (Abrir Visual Studio > Herramientas > Opciones > Xamarin > Other y presionar en Check Now)
	- Actualizar los paquetes NuGet de la solución (Click derecho en la solución, seleccionar Administrar paquetes NuGet para la solución...)
  	- Descarga de archivos android_m2repository_rXX.zip (https://developer.xamarin.com/guides/android/troubleshooting/resolving-library-installation-errors/#Manually_Downloading_and_Installing_m2repository_Files)
  	- Leer el siguiente artículo: http://smstuebe.de/2016/10/29/fix-android-app-compat/