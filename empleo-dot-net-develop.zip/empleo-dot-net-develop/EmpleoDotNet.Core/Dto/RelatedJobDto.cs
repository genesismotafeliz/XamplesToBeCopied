﻿namespace EmpleoDotNet.Core.Dto
{
    public class RelatedJobDto
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }
}