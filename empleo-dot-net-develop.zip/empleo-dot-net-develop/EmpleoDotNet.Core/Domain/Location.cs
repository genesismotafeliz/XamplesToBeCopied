﻿namespace EmpleoDotNet.Core.Domain
{
    public class Location : EntityBase
    {
        public string Name { get; set; }
    }
}