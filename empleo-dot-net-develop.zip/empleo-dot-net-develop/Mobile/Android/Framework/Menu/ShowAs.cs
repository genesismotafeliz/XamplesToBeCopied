using System;

namespace Android
{
	public enum ShowAs
	{
		Hidden,
		Visible
	}
}

