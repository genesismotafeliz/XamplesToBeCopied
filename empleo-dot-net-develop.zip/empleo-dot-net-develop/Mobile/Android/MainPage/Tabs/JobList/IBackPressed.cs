﻿using System;
using Android.Support.V4.App;

namespace Android
{
	public interface IBackPressed
	{
		bool OnBackPressed();
	}
}

