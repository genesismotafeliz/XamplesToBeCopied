﻿using System;

namespace Android
{
	public class SwipeToTabEventHandler
	{
		public Tab Tab { get; set; }
	}
}

