﻿using System;

namespace Android
{
	public enum Tab
	{
		JobSearch,
		Categories,
		Favorite
	}
}

