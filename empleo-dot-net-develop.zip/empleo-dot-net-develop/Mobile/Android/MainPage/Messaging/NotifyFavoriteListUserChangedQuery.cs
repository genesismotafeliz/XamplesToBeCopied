﻿using System;

namespace Android
{
	public class NotifyFavoriteListUserChangedQuery
	{
		public string Query { get; set; }
	}
}

