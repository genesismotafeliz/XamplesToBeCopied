﻿using System;

namespace Android
{
	public class NotifySearchBarPutText
	{
		public string Query { get; set; }
	}
}

