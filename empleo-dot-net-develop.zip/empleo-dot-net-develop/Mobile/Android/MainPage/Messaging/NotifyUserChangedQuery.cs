﻿using System;

namespace Android
{
	public class NotifyUserChangedQuery
	{
		public string Query { get; set; }
	}
}

