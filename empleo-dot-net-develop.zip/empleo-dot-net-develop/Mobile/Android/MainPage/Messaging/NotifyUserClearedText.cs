﻿using System;

namespace Android
{
	public class NotifyUserClearedText
	{
		public NotifyUserClearedText ()
		{
		}
	}
}

