﻿using System;

namespace Android
{
	public class NotifyJobListUserChangedQuery
	{
		public string Query { get; set; }
	}
}

