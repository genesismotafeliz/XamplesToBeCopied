using System;

namespace Android
{
	public interface IContextService
	{
		object GetContext();
	}

}

