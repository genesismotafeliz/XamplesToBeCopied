﻿using System;

namespace Core
{
	public class MobileConfig
	{
		public string GitHubKey { get; set; }

		public string XamarinInsightKey { get; set; }
	}
}