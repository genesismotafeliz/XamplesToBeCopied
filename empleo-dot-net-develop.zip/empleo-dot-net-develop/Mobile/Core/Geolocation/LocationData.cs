﻿using System;

namespace Android
{
	public class LocationData
	{
		public string UserStreet { get; set; }

		public string UserCity { get; set; }

		public string UserCountry { get; set; }

		public string PostalCode { get; set; }
	}
}

