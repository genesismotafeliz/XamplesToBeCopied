﻿using System;

namespace Android
{
	public class LandingPageInfo
	{
		public int Title { get; set; }

		public int Icon { get; set; }

		public int Description { get; set; }
	}
}

