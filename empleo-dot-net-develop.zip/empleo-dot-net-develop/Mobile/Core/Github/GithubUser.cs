using System;
using System.Collections.Generic;

namespace Core
{
	public class GithubUser
	{
		public string UserName { get; set; }

		public int MergedPullRequest { get; set; }
	}

}

