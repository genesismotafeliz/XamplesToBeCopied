﻿using System;

namespace Core
{
	public class Keys
	{
		public static string MobileConfigFileName = "MobileConfig.json";
	}
}

