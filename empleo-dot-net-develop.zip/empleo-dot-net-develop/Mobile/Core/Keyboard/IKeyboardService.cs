﻿using System;

namespace Core
{
	public interface IKeyboardService
	{
		void ShowKeyboard(object toFocusOn);
	}
}

