using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Android
{
	public class CategoriesViewModel
	{
		public string Title { get; set; }

		public int Image { get; set; }

		public string Query { get; set; }
	}
}