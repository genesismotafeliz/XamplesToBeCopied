﻿using System;

namespace Android
{
	public interface ILanguageService
	{
		string GetStringFor(string id);
	}

}

