﻿using System;

namespace APIs
{
	//If you want to test the APi really quick, try: https://www.mockable.io/a/#/
	public class Constants
	{
		public static readonly string Endpoint = "http://demo3199087.mockable.io/";

		public static readonly string JobsEndpoint = "cardJobs";
	}
}

