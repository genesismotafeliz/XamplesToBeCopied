﻿using System;

namespace APIs
{
	public enum Method
	{
		GET,
		POST,
		PUT,
		DELETE
	}
}