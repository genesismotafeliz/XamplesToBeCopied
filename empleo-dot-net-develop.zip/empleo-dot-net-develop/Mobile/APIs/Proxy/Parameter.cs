﻿using System;
using System.Collections;

namespace APIs
{
	public class Parameter
	{
		public string Property { get; set; }

		public string Value { get; set; }
	}
}

