﻿namespace EmpleoDotNet.Repository.Dto
{
    public class NearbyJobOpportunityLocation
    {
        public int Id { get; set; }
        public double DistanceInKm { get; set; } 
    }
}