﻿namespace EmpleoDotNet.ViewModel
{
    public class RelatedJobDto
    {
        public string Title { get; set; }
        public string Url { get; set; } 
    }
}