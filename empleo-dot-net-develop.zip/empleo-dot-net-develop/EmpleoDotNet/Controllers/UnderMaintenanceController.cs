﻿using System.Web.Mvc;

namespace EmpleoDotNet.Controllers
{
    public class UnderMaintenanceController : Controller
    {
        // GET: Maintenance
        public ActionResult Index()
        {
            return View();
        }
    }
}