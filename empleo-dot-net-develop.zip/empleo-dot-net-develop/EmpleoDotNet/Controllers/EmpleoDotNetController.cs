﻿using System.Web.Mvc;

namespace EmpleoDotNet.Controllers
{
    public abstract class EmpleoDotNetController : Controller
    {
    }
}