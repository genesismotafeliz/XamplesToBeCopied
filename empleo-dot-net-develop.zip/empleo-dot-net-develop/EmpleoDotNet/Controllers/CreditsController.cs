﻿using System.Web.Mvc;

namespace EmpleoDotNet.Controllers
{
    public class CreditsController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}