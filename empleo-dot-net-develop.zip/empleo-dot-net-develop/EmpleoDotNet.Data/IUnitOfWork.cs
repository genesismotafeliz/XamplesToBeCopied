﻿namespace EmpleoDotNet.Data
{
    public interface IUnitOfWork
    {
        void SaveChanges();
    }
}