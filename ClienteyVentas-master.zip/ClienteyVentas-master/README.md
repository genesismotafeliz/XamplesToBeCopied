# ClienteyVentas
Este proyecto calcula los clientes y las ventas en una tienda, arrojando al final la cantidad de clientes y cuanto fueron las ventas totales al final del dia, este proyecto creado por el Grupo R... Joel Mendez 16-SIIN-1-107 Claudio Brito 16-EIIN-1-029, Universidad Dominicana O&M, Asignatura: Programacion Estructurada C, Seccion: 0463
