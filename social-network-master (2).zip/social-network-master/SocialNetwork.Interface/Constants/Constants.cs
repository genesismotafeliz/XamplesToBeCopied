﻿namespace SocialNetwork.Interface.Constants
{
    public enum PostEvent
    {
        PostPublished, PostChanged, PostDeleted
    }
}