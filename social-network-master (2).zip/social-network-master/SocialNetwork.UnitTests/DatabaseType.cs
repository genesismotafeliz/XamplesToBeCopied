﻿namespace SocialNetwork.UnitTests
{
    enum DatabaseType
    {
        InMemory, Persistant
    }
}
