﻿namespace SocialNetwork.Web.ViewModels
{
    public class BaseViewModel
    {
        public string Title { get; set; }
        public Page ActivePage { get; set; }
        public string Username { get; set; }
    }
}
