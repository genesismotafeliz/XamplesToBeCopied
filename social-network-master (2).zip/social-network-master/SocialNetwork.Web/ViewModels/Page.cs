﻿namespace SocialNetwork.Web.ViewModels
{
    public enum Page
    {
        Home, Account_Register, Account_Login
    }
}
