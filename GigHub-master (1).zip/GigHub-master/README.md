# GigHub

The real training is using ASP .NET MVC 5 and EF 6. Instead I am using .NET Core 2.0 here.

Please find below if you'd like to also learn more from the same course.<br />
https://app.pluralsight.com/library/courses/full-stack-dot-net-developer-fundamentals/table-of-contents
