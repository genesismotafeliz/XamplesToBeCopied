# Conteo-Electoral
Diseñe un programa que lea los 5,750,250 votos otorgados a 3 candidatos presidenciales e imprima el numero del candidato ganador y su cantidad de votos
