﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentSystem2.Domain.Enums
{
    public enum ContentType
    {
        application=1,
        pdf=2,
        zip=3,
        other=999
        //application/pdf/zip

    }
}
