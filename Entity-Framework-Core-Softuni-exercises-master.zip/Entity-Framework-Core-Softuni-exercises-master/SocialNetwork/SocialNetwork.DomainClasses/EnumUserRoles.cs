﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Social2.DomainClasses
{
    public enum UserRoles
    {
        Owner=1,

        Viewer=2,

        Other=999

    }
}
