﻿namespace FootballBetting.DomainClasses
{
    public enum WinDrawLost
    {
        Win=1,
        Draw=2,
        Lost=3

    }
}