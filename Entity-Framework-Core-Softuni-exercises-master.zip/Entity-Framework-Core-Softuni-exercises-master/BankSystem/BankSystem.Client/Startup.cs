﻿using BankSystem.Data;
using System;

namespace BankSystem.Client
{
    public class Startup
    {
        static void Main()
        {
            Engine.Start();

        }
    }
}
