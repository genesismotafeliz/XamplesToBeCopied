# SocialNetwork
Code from "Making a Social Network in ASP.NET MVC 5" at http://www.livecoding.tv/jmartins
