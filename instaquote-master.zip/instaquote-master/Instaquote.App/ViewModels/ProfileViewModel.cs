﻿using Instaquote.App.Core.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Instaquote.App.ViewModels
{
    public class ProfileViewModel
    {
        public User User { get; set; }

        public IEnumerable<Repost> Reposts { get; set; }
    }

    public class EditProfileViewModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string FullName { get; set; }

        [Required]
        [Display(Name = "Photo URL")]
        public string ProfileImage { get; set; }

        [Required]
        public string Bio { get; set; }
    }
}
