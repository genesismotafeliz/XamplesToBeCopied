﻿using Instaquote.App.Core.Models;
using System.Collections.Generic;

namespace Instaquote.App.ViewModels
{
    public class TimelineViewModel
    {
        public IEnumerable<Post> Posts { get; set; }
    }

    public class CommentViewModel
    {
        public IEnumerable<Comment> Comments { get; set; }

        public System.Guid PostId { get; set; }
    }
}
