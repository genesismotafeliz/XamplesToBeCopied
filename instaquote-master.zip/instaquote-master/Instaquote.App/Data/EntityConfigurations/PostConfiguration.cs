﻿using Instaquote.App.Core.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialNetworkApp.Data;

namespace Instaquote.App.Data.EntityConfigurations
{
    public class PostConfiguration : EntityTypeConfiguration<Post>
    {
        public override void Map(EntityTypeBuilder<Post> builder)
        {
            // Fluent API Relationships.
            builder.Property(p => p.Thought).IsRequired();

            builder.Property(p => p.Username).IsRequired();

            builder.Property(p => p.Thought).HasMaxLength(500);

            builder.HasMany(p => p.Comments).WithOne(c => c.Post).HasForeignKey(c => c.PostId);

            builder.HasMany(p => p.Hearts).WithOne(h => h.Post).HasForeignKey(h => h.PostId);

            builder.HasMany(p => p.Reposts).WithOne(r => r.Post).HasForeignKey(r => r.PostId);
        }
    }
}
