﻿using Instaquote.App.Core.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialNetworkApp.Data;

namespace Instaquote.App.Data.EntityConfigurations
{
    public class UserConfiguration : EntityTypeConfiguration<User>
    {
        public override void Map(EntityTypeBuilder<User> builder)
        {
            //Fluent API Relationships.

            //To avoid user with same usernames.
            builder.HasKey(u => u.Username);

            builder.HasMany(u => u.Comments).WithOne(c => c.User).HasForeignKey(c => c.Username);

            builder.HasMany(u => u.Posts).WithOne(p => p.User).HasForeignKey(p => p.Username);

            builder.HasMany(u => u.Hearts).WithOne(h => h.User).HasForeignKey(h => h.Username);

            builder.HasMany(u => u.Reposts).WithOne(n => n.User).HasForeignKey(n => n.Username);

            builder.HasMany(u => u.Followers).WithOne(f => f.User).HasForeignKey(f => f.Username);

            builder.HasMany(u => u.Following).WithOne(f => f.User).HasForeignKey(f => f.Username);
        }
    }
}
