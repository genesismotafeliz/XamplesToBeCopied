﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Instaquote.App.Core.Models;
using SocialNetworkApp.Data;

namespace Instaquote.App.Data.EntityConfigurations
{
    public class CommentConfiguration : EntityTypeConfiguration<Comment>
    {
        public override void Map(EntityTypeBuilder<Comment> builder)
        {
            builder.Property(c => c.Body).HasMaxLength(50);

            builder.Property(c => c.Body).IsRequired();
        }
    }
}
