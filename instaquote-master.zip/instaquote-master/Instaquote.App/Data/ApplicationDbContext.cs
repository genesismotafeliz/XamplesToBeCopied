﻿using Instaquote.App.Core.Models;
using Instaquote.App.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;
using SocialNetworkApp.Data;

namespace Instaquote.App.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public ApplicationDbContext()
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            // optionsBuilder.UseSqlServer("Server=.;Database=SocialNetworkDB;Trusted_Connection=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Adding Configurations to modelbuilder.
            modelBuilder.AddConfiguration(new UserConfiguration());
            modelBuilder.AddConfiguration(new PostConfiguration());
            modelBuilder.AddConfiguration(new CommentConfiguration());
        }

        //DbSets.
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Post> Posts { get; set; }
        public virtual DbSet<Comment> Comments { get; set; }
        public virtual DbSet<Heart> Hearts { get; set; }
        public virtual DbSet<Repost> Reposts { get; set; }
    }
}
