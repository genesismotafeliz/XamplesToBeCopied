﻿using Instaquote.App.Core.Models;
using System.Collections.Generic;
using System.Linq;

namespace Instaquote.App.Data.Repositories
{
    public class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Users.Any())
            {
                return;
            }

            var users = new User[]
            {
                new User { Username = "melissatorres", Bio = "Mechanical Engineer @ NASA. I love haniging with family and working!", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/black-and-white-1180437_960_720.jpg", FullName = "Melissa Torres" },
                new User { Username = "timmyseaman", Bio = "Coffee Lover & Writer by trade. Doing what you like is freedom, liking what you do is happiness.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/people-852428_960_720.jpg", FullName = "Timmy Seaman" },
                new User { Username = "carolyngrover", Bio = "Fashion stylist. Highly introverted. Always looking to improve in all areas of life.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/Jessica-Anne-Mole-1-2-1140x660.jpg", FullName = "Carolyn Grover" },
                new User { Username = "jimmyclose", Bio = "Startup mentor, executive, blogger, author, tech professional, and Angel investor among other things.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/article-2405475-1B8389EE000005DC-718_634x550.jpg", FullName = "Jimmy Close" },
                new User { Username = "malaika", Bio = "Investor, Author, Dream Chaser, & Speaker! Here to Motivate & Inspire.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/female-471152_960_720.jpg", FullName = "Maliaka Terry" },
                new User { Username = "lorenzo", Bio = "Entrepreneur and connector. I blog about my successes and epic failures for various magazines.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/entrepreneur-593358_960_720.jpg", FullName = "Lorenzo Winters" },
                new User { Username = "angelavaldez", Bio = "Lawyer at Goldman Sachs. Live like you will never see another day.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/beautiful-1274051_960_720.jpg", FullName = "Angela Valdez" },
                new User { Username = "metsephiri", Bio = "Aspiring Fullstack Web Developer. Using popular technogies like .NET & Angular to build sick web apps.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/9FdTWaNb.jpg", Email = "metse.phiri@yahoo.com", FullName = "Metse Phiri" }
            };

            foreach (var user in users)
            {
                context.Add(user);
            }

            context.SaveChanges();

            var posts = new Post[]
            {
                new Post { Thought = "A work of art that contains  theories is like an object on which the price tag has been left.", Username = "malaika", Comments = new List<Comment> { new Comment { Body = "So true...", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "malaika" }, new Repost { Username = "metsephiri" } } },
                new Post { Thought = "Wasted youth is better by far the a wise and productive old age.", Username = "lorenzo", Comments = new List<Comment> { new Comment { Body = "This is one of my favourite quotes.", Username = "carolyngrover" } } },
                new Post { Thought = "Parents can only give good advice or put them on the right paths, but the final forming of a person's character lies in their own hands.", Username = "jimmyclose", Comments = new List<Comment> { new Comment { Body = "Yes!", Username = "malaika" } }, Reposts = new List<Repost> { new Repost { Username = "jimmyclose" }, new Repost { Username = "lorenzo" } }},
                new Post { Thought = "A fanatic is a nut who has something to believe in.", Username = "jacksonmichael", User = new User { Username = "jacksonmichael", Bio = "Singer. Yes, I'm the real Michael Jackson.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/people-516372_960_720.jpg", FullName = "Michael Jackson" }, Comments = new List<Comment> { new Comment { Body = "Like that quote!", Username = "lorenzo" } }, Reposts = new List<Repost> { new Repost { Username = "angelavaldez" }, new Repost { Username = "timmyseaman" } } },
                new Post { Thought = "Creativity is the process of having original ideas that have value. It is a process; it's not random.", Username = "kenrobinson", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "angelavaldez", Body = "Creativity is a lot things..." } }, User = new User { Username = "kenrobinson", Bio = "Architect. Artist & Pro Skater. Yes, I do it all.", ProfileImage = "https://static.pexels.com/photos/78225/pexels-photo-78225.jpeg", FullName = "Ken Robinson" } },
                new Post { Thought = "Carry out a random act of kindness, with no expectation of reward, safe in the knowledge that one day someone might do the same for you.", Username = "angelavaldez", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "carolyngrover", Body = "Heard this one many times. Love it." } } },
                new Post { Thought = "It's a small world, but I wouldn't want to paint it.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "malaika" } }, Comments = new List<Comment> { new Comment { Username = "lorenzo", Body = "Trying to paint it alone is hard enough."} } },
                new Post { Thought = "Never help a child with a task at which he feels he can succeed.", Username = "jacksonmichael", Hearts = new List<Heart> { new Heart { Username = "lorenzo" } }, Comments = new List<Comment> { new Comment { Username = "melissatorres", Body = "Oh, you have kids?" }, new Comment { Username = "jacksonmichael", Body = "Yes, I do!" } } },
                new Post { Thought = "In the business world, the rearview mirror is always clearer than the windshield.", Username = "melissatorres", Hearts = new List<Heart> { new Heart { Username = "jacksonmichael" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "Warren said this right?" }, new Comment { Username = "melissatorres", Body = "Yes, he did." } } },
                new Post { Thought = "You can tell the ideals of a nation by its advertisements.", Username = "kenrobinson", Hearts = new List<Heart> { new Heart { Username = "carolyngrover" }, new Heart { Username = "angelavaldez" } }, Reposts = new List<Repost> { new Repost { Username = "melissatorres" }, new Repost { Username = "carolyngrover" } } },
                new Post { Thought = "Start by doing what's necessary; then do what's possible; and suddenly you are doing the impossible.", Username = "lorenzo", Hearts = new List<Heart> { new Heart { Username = "metsephiri" } }, Comments = new List<Comment> { new Comment { Username = "jimmyclose", Body = "Interesting quote" } } },
                new Post { Thought = "People who think they know everything are a great annoyance to those of us who do.", Username = "timmyseaman", Hearts = new List<Heart> { new Heart { Username = "metsephiri" } }, Comments = new List<Comment> { new Comment { Username = "metsephiri", Body = "One of my favourites." } } },
                new Post { Thought = "Procrastination is the art of keeping up with yesterday.", Username = "lorenzo", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "That's one for the books." }, new Comment { Username = "angelavaldez", Body = "This quote deserves many hearts." } } },
                new Post { Thought = "A day without sunshine is like, you know, night.", Username = "jimmyclose", Hearts = new List<Heart> { new Heart { Username = "lorenzo" } }, Comments = new List<Comment> { new Comment { Username = "metsephiri", Body = "Nice quote." } }, Reposts = new List<Repost> { new Repost { Username = "kenrobinson" }, new Repost { Username = "jacksonmichael" } } },
                new Post { Thought = "Be yourself; everyone else is already taken.", Username = "kenrobinson", Hearts = new List<Heart> { new Heart { Username = "melissatorres" } }, Comments = new List<Comment> { new Comment { Username = "jimmyclose", Body = "Nice quote." }, new Comment { Username = "melissatorres", Body = "Writing this one down." } } },
                new Post { Thought = "Expect problems and eat them for breakfast.", Username = "metsephiri", Hearts = new List<Heart> { new Heart { Username = "angelavaldez" } }, Comments = new List<Comment> { new Comment { Username = "metsephiri", Body = "Not my quote, but very powerful." }, new Comment { Username = "lorenzo", Body = "I saw this on the subway back home." } } },
                new Post { Thought = "Ever tried. Ever failed. No matter. Try Again. Fail again. Fail better.", Username = "angelavaldez", Hearts = new List<Heart> { new Heart { Username = "malaika" } }, Comments = new List<Comment> { new Comment { Username = "jimmyclose", Body = "Nice quote there, Angela." }, new Comment { Username = "angelavaldez", Body = "Thanks!" } } },
                new Post { Thought = "Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.", Username = "malaika", Hearts = new List<Heart> { new Heart { Username = "kenrobinson" } }, Comments = new List<Comment> { new Comment { Username = "lorenzo", Body = "Awesome." }, new Comment { Username = "timmyseaman", Body = "Everyone should heart this." } } },
                new Post { Thought = "A creative man is motivated by the desire to achieve, not by the desire to beat others.", Username = "timmyseaman", Hearts = new List<Heart> { new Heart { Username = "lorenzo" } }, Comments = new List<Comment> { new Comment { Username = "malaika", Body = "Creativity quotes are always good." }, new Comment { Username = "lorenzo", Body = "That sure is one creative man." } } },
                new Post { Thought = "It does not matter how slowly you go as long as you do not stop.", Username = "jimmyclose", Hearts = new List<Heart> { new Heart { Username = "metsephiri" } }, Comments = new List<Comment> { new Comment { Username = "angelavaldez", Body = "Consistency is key." }, new Comment { Username = "carolyngrover", Body = "Persistence and having willpower is important." } } },
                new Post { Thought = "Believe you can and you're halfway there.", Username = "malaika", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "kenrobinson", Body = "Such a good quote" }, new Comment { Username = "melissatorres", Body = "I have to agree with you." } } },
                new Post { Thought = "Do not take life too seriously. You will never get out of it alive.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "carolyngrover", Body = "I say this to myself everyday." }, new Comment { Username = "lorenzo", Body = "Hearted!" } } },
                new Post { Thought = "Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time.", Username = "kenrobinson", Hearts = new List<Heart> { new Heart { Username = "carolyngrover" } }, Comments = new List<Comment> { new Comment { Username = "melissatorres", Body = "Damn, Ken. Where'd you find this?" }, new Comment { Username = "timmyseaman", Body = "You can say that again!" } } },
                new Post { Thought = "Get your facts first, then you can distort them as you please.", Username = "timmyseaman", Hearts = new List<Heart> { new Heart { Username = "lorenzo" } }, Comments = new List<Comment> { new Comment { Username = "metsephiri", Body = "I like the uniquenes of this quote." }, new Comment { Username = "timmyseaman", Body = "Me too." } }, Reposts = new List<Repost> { new Repost { Username = "jimmyclose" }, new Repost { Username = "angelavaldez" } } },
                new Post { Thought = "Don't watch the clock; do what it does. Keep going.", Username = "timmyseaman", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "kenrobinson", Body = "You can say that again." }, new Comment { Username = "melissatorres", Body = "Agreed." } }, Reposts = new List<Repost> { new Repost { Username = "jacksonmichael" }, new Repost { Username = "metsephiri" } } },
                new Post { Thought = "The will to win, the desire to succeed, the urge to reach your full potential... these are the keys that will unlock the door to personal excellence.", Username = "metsephiri", Hearts = new List<Heart> { new Heart { Username = "metsephiri" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "This quote has many memories" }, new Comment { Username = "malaika", Body = "Yay!" } } },
                new Post { Thought = "Don't sweat the petty things and don't pet the sweaty things.", Username = "melissatorres", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "lorenzo", Body = "Clear and distinct" }, new Comment { Username = "kenrobinson", Body = "So much value in one sentence." } } },
                new Post { Thought = "Hapiness is not something ready made. It comes from your own actions.", Username = "angelavaldez", Hearts = new List<Heart> { new Heart { Username = "carolyngrover" } }, Comments = new List<Comment> { new Comment { Username = "angelavaldez", Body = "I like this quote. That's why I shared it." }, new Comment { Username = "timmyseaman", Body = "This quote reminds me of when I was a kid." } } }
            };

            foreach (var post in posts)
            {
                context.Add(post);
            }

            context.SaveChanges();


        }
    }
}
