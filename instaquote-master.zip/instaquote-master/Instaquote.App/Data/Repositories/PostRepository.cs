﻿using Instaquote.App.Core.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Instaquote.App.Data.Repositories
{
    public interface IPostRepository
    {
        Task<IEnumerable<Post>> GetPosts();
        Task<Post> GetPost(Guid postId);
        Task<int> CreatePost(Post post);
        Task<int> DeletePost(Guid postId);
        Task<int> Repost(Repost repost);
        Task<int> AddComment(Comment comment);
        Task<IEnumerable<Comment>> GetComments(Guid postId);
        Task<int> LikePost(Heart heart);
        Task Save();
    }

    public class PostRepository : IPostRepository, IDisposable
    {
        private readonly ApplicationDbContext _context;

        public PostRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> AddComment(Comment comment)
        {
            await _context.Comments.AddAsync(comment);
            return await _context.SaveChangesAsync();
        }

        public async Task<int> CreatePost(Post post)
        {
            await _context.Posts.AddAsync(post);
            return await _context.SaveChangesAsync();
        }

        public async Task<int> DeletePost(Guid postId)
        {
            var post = _context.Posts.First(p => p.PostId == postId);

            _context.Posts.Remove(post);
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }

        public async Task<IEnumerable<Comment>> GetComments(Guid postId)
        {
            return await _context.Comments.Where(c => c.PostId == postId).ToListAsync();
        }

        public async Task<Post> GetPost(Guid postId)
        {
            return await _context.Posts
                     .Include(p => p.User)
                     .Include(p => p.Reposts)
                     .Include(p => p.Comments)
                     .Include(p => p.Hearts)
                     .FirstAsync(p => p.PostId == postId);
        }

        public async Task<IEnumerable<Post>> GetPosts()
        {
            return await _context.Posts
                    .OrderByDescending(p => p.PostDate)
                    .Include(p => p.User)
                    .Include(p => p.Hearts)
                    .Include(p => p.Comments)
                    .Include(p => p.Reposts)
                    .ToListAsync();
        }

        public async Task<int> LikePost(Heart heart)
        {
            await _context.Hearts.AddAsync(heart);
            return await _context.SaveChangesAsync();
        }

        public async Task<int> Repost(Repost repost)
        {
            await _context.Reposts.AddAsync(repost);
            return await _context.SaveChangesAsync();
        }

        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }
    }
}
