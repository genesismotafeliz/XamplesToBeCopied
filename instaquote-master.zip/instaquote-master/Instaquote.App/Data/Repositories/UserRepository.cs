﻿using Instaquote.App.Core.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Instaquote.App.Data.Repositories
{
    public interface IUserRepository
    {
        Task<User> GetUserData(string username);
        Task<IEnumerable<User>> GetOtherUsers(string email);
        Task<User> GetCurrentUser(string email);
        bool VerifyUsername(string username);
        Task CreateUser(User user);
        Task Save();
    }
    public class UserRepository : IUserRepository, IDisposable
    {
        private ApplicationDbContext _context;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User> GetCurrentUser(string email)
        {
            return await _context.Users
                .Include(u => u.Posts)
                .Include(u => u.Hearts)
                .Include(u => u.Reposts)
                .Include(u => u.Comments)
                .FirstAsync(u => u.Email == email);
        }

        public async Task<IEnumerable<User>> GetOtherUsers(string email)
        {
            return await _context.Users.Where(u => u.Email != email).ToListAsync();
        }

        public bool VerifyUsername(string username)
        {
            var user = _context.Users.Find(username);

            if (user == null)
            {
                return true;
            }

            return false;
        }

        public async Task<User> GetUserData(string username)
        {
            return await _context.Users
                .Include(u => u.Posts)
                .Include(u => u.Comments)
                .Include(u => u.Hearts)
                .FirstAsync(u => u.Username == username);
        }

        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }

        public async Task CreateUser(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }
    }
}
