﻿namespace Instaquote.App.Core.Models
{
    public class UserFollower
    {
        public int Id { get; set; }

        public string UserFollowName { get; set; }

        public string FullName { get; set; }

        public string ProfileImage { get; set; }

        public User User { get; set; }

        public string Username { get; set; }
    }
}
