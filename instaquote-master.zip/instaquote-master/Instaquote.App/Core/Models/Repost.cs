﻿using System;

namespace Instaquote.App.Core.Models
{
    public class Repost
    {
        public int Id { get; set; }

        public virtual Post Post { get; set; }

        public string Username { get; set; }

        public virtual User User { get; set; }

        public Guid PostId { get; set; }
    }
}
