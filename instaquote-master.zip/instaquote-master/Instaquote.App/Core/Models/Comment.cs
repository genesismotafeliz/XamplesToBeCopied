﻿using System;

namespace Instaquote.App.Core.Models
{
    public class Comment
    {
        public int CommentId { get; set; }

        public DateTime CommentDate { get; set; }

        public virtual User User { get; set; }

        public string Username { get; set; }

        public virtual Post Post { get; set; }

        public Guid PostId { get; set; }

        public string Body { get; set; }

        public Comment()
        {
            CommentDate = DateTime.Now;
        }
    }
}