﻿using System;
using System.Collections.Generic;

namespace Instaquote.App.Core.Models
{
    public class Post
    {
        public Guid PostId { get; set; }

        public string Thought { get; set; }

        public virtual User User { get; set; }

        public string Username { get; set; }

        public DateTime PostDate { get; set; }

        public virtual ICollection<Repost> Reposts { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }

        public virtual ICollection<Heart> Hearts { get; set; }

        public Post()
        {
            PostDate = DateTime.Now;
            Hearts = new List<Heart>();
            Reposts = new List<Repost>();
            Comments = new List<Comment>();
        }

    }
}