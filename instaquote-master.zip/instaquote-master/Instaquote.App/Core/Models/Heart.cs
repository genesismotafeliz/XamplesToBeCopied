﻿using System;

namespace Instaquote.App.Core.Models
{
    public class Heart
    {
        public int HeartId { get; set; }

        public virtual Post Post { get; set; }

        public Guid PostId { get; set; }

        public virtual User User { get; set; }

        public string Username { get; set; }
    }
}