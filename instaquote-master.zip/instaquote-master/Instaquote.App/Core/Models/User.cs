﻿using System.Collections.Generic;

namespace Instaquote.App.Core.Models
{
    public class User
    {
        public string Username { get; set; }

        public string ProfileImage { get; set; }

        public string Email { get; set; }

        public string Bio { get; set; }

        public string FullName { get; set; }

        public virtual ICollection<UserFollower> Followers { get; set; }

        public virtual ICollection<UserFollowing> Following { get; set; }

        public virtual ICollection<Repost> Reposts { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }

        public virtual ICollection<Heart> Hearts { get; set; }

        public virtual ICollection<Post> Posts { get; set; }

        public User()
        {
            Reposts = new List<Repost>();
            Comments = new List<Comment>();
            Hearts = new List<Heart>();
            Posts = new List<Post>();
            Followers = new List<UserFollower>();
            Following = new List<UserFollowing>();
        }

    }
}
