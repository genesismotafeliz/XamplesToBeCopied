﻿using Auth0.AuthenticationApi;
using Auth0.AuthenticationApi.Models;
using Instaquote.App.Core.Options;
using Instaquote.App.Data.Repositories;
using Instaquote.App.ViewModels;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Security.Claims;
using System.Threading.Tasks;


namespace Instaquote.App.Controllers
{
    public class AccountController : Controller
    {
        private readonly Auth0Settings _auth0Settings;
        private readonly IUserRepository _repository;

        public AccountController(IOptions<Auth0Settings> auth0Settings, IUserRepository repository)
        {
            _auth0Settings = auth0Settings.Value;
            _repository = repository;
        }

        [HttpGet]
        public IActionResult Register(string returnUrl = "/")
        {
            ViewData["ReturnUrl"] = returnUrl;

            return View();
        }

        [HttpPost]
        [ActionName("Register")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterAsync(RegisterViewModel vm, string returnUrl = null)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    AuthenticationApiClient client = new AuthenticationApiClient(new Uri($"https://{_auth0Settings.Domain}/"));

                    var signupUserResponse = await client.SignupUserAsync(new SignupUserRequest
                    {
                        ClientId = _auth0Settings.ClientId,
                        Connection = "Username-Password-Authentication",
                        Email = vm.EmailAddress,
                        Password = vm.Password
                    });


                    var tokenResponse = await client.GetTokenAsync(new ResourceOwnerTokenRequest
                    {
                        ClientId = _auth0Settings.ClientId,
                        ClientSecret = _auth0Settings.ClientSecret,
                        Scope = "openid profile",
                        Realm = "Username-Password-Authentication",
                        Username = vm.EmailAddress,
                        Password = vm.Password
                    });

                    var user = await client.GetUserInfoAsync(tokenResponse.AccessToken);

                    // Create claims principal.
                    var claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, user.UserId),
                        new Claim(ClaimTypes.Name, user.FirstName)

                    }, CookieAuthenticationDefaults.AuthenticationScheme));

                    await HttpContext.Authentication.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);

                    string avatar = string.Format("https://ui-avatars.com/api/?name={0}background=0D8ABC&color=fff", vm.EmailAddress);

                    await _repository.CreateUser(new Core.Models.User { Email = vm.EmailAddress, ProfileImage = avatar, Username = vm.Username, FullName = vm.Name });

                    return RedirectToLocal(returnUrl);
                }
                catch (Exception exc)
                {

                    ModelState.AddModelError("", exc.Message);
                }
            }

            return View(vm);
        }

        [HttpGet]
        public IActionResult Login(string returnUrl = "/")
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ActionName("Login")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LoginAsync(LoginViewModel vm, string returnUrl = null)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    AuthenticationApiClient client = new AuthenticationApiClient(new Uri($"https://{_auth0Settings.Domain}/"));

                    var result = await client.GetTokenAsync(new ResourceOwnerTokenRequest
                    {
                        ClientId = _auth0Settings.ClientId,
                        ClientSecret = _auth0Settings.ClientSecret,
                        Scope = "openid profile",
                        Realm = "Username-Password-Authentication",
                        Username = vm.EmailAddress,
                        Password = vm.Password
                    });

                    var user = await client.GetUserInfoAsync(result.AccessToken);


                    // Create claims principal.
                    var claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity(new[]
                    {
                      new Claim(ClaimTypes.NameIdentifier, user.UserId),
                      new Claim(ClaimTypes.Name, user.FullName),
                      new Claim(ClaimTypes.Uri, user.Picture)

                    }, CookieAuthenticationDefaults.AuthenticationScheme));

                    await HttpContext.Authentication.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);

                    return RedirectToLocal(returnUrl);
                }
                catch (Exception e)
                {
                    ModelState.AddModelError("", e.Message);
                }
            }

            return View(vm);
        }

        [HttpPost]
        [Authorize]
        public async Task Logout()
        {
            await HttpContext.Authentication.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme, new AuthenticationProperties
            {
                RedirectUri = Url.Action("Login", "Account")
            });

            await HttpContext.Authentication.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(HomeController.Timeline), "Home");
            }
        }

        [AcceptVerbs("Get", "Post")]
        public IActionResult ValidateUsername(string username)
        {
            if (!_repository.VerifyUsername(username))
            {
                return Json($"Username {username} has already been taken.");
            }

            return Json(true);
        }
    }
}
