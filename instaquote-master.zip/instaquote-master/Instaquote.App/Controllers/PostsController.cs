using Instaquote.App.Core.Models;
using Instaquote.App.Data.Repositories;
using Instaquote.App.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Instaquote.App.Controllers
{
    [Authorize]
    public class PostsController : Controller
    {
        private IPostRepository _postRepository;
        private IUserRepository _userRepository;

        public PostsController(IPostRepository postRepository, IUserRepository userRepository)
        {
            _postRepository = postRepository;
            _userRepository = userRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Detail(Guid guid)
        {
            if (guid == null)
            {
                return NotFound();
            }

            Post post = await _postRepository.GetPost(guid);

            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string thought)
        {
            var user = await _userRepository.GetCurrentUser(User.Identity.Name);

            if (!String.IsNullOrWhiteSpace(thought))
            {

                Post post = new Post
                {
                    PostId = Guid.NewGuid(),
                    Username = user.Username,
                    Thought = thought
                };

                await _postRepository.CreatePost(post);

                return RedirectToAction(nameof(HomeController.Profile), "Home");
            }

            return RedirectToAction("Timeline", "Home");
        }

        [HttpGet("posts/update/{guid}")]
        public async Task<IActionResult> Update(Guid guid)
        {
            if (guid == null)
            {
                return NotFound();
            }

            Post post = await _postRepository.GetPost(guid);


            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update([Bind("PostId,Thought")] Guid postId, string thought)
        {
            if (!String.IsNullOrWhiteSpace(thought))
            {
                Post post = await _postRepository.GetPost(postId);


                if (post == null)
                {
                    return NotFound();
                }

                post.Thought = thought;

                await _postRepository.Save();

                return RedirectToAction("Profile", "Home");
            }

            return View(thought);
        }

        [HttpPost]
        public async Task<IActionResult> Repost(Guid postId)
        {
            if (postId == null)
            {
                return BadRequest();
            }

            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            await _postRepository.Repost(new Repost { PostId = postId, Username = user.Username });

            return RedirectToAction("Timeline", "Home");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete([Bind("PostId")] Guid postId)
        {
            if (postId == null)
            {
                return NotFound();
            }

            Post post = await _postRepository.GetPost(postId);

            if (post == null)
            {
                return NotFound();
            }

            await _postRepository.DeletePost(post.PostId);

            return RedirectToAction("Profile", "Home");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddComment(string body, Guid postId)
        {
            if (String.IsNullOrWhiteSpace(body))
            {
                return RedirectToAction("Detail", "Posts", new { guid = postId });
            }

            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            if (user == null || String.IsNullOrWhiteSpace(body))
            {
                return RedirectToAction("Detail", "Posts", new { guid = postId });
            }

            Comment comment = new Comment
            {
                Body = body,
                PostId = postId,
                Username = user.Username
            };

            await _postRepository.AddComment(comment);

            CommentViewModel model = new CommentViewModel
            {
                Comments = await _postRepository.GetComments(postId)
            };

            return PartialView("_CommentPartial", model);
        }

        [HttpPost]
        public async Task<IActionResult> HeartPost(Guid postId)
        {
            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            if (user == null)
            {
                return RedirectToAction("Detail", "Posts", new { guid = postId });
            }

            Heart heart = new Heart
            {
                Username = user.Username,
                PostId = postId
            };

            await _postRepository.LikePost(heart);

            return RedirectToAction("Detail", "Posts", new { guid = postId });
        }
    }
}
