﻿using Instaquote.App.Core.Models;
using Instaquote.App.Data.Repositories;
using Instaquote.App.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Instaquote.App.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private IPostRepository _postRepository;
        private IUserRepository _userRepository;

        public HomeController(IPostRepository postRepository, IUserRepository userRepository)
        {
            _postRepository = postRepository;
            _userRepository = userRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Timeline()
        {
            IEnumerable<Post> posts = await _postRepository.GetPosts();

            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            return View(new TimelineViewModel { Posts = posts });
        }

        [HttpGet("{username}")]
        public async Task<IActionResult> UserProfile(string username)
        {
            User user = await _userRepository.GetUserData(username);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            if (user == null)
            {
                RedirectToAction("ProfileSetup");
            }

            return View(new ProfileViewModel
            {
                User = user,
                Reposts = user.Reposts
            });
        }

        [HttpGet]
        public async Task<IActionResult> EditProfile()
        {
            User user = await _userRepository.GetCurrentUser(User.Identity.Name);
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProfile(EditProfileViewModel viewModel)
        {
            User user = await _userRepository.GetCurrentUser(User.Identity.Name);

            user.Bio = viewModel.Bio;
            user.FullName = viewModel.FullName;
            user.ProfileImage = viewModel.ProfileImage;

            await _userRepository.Save();

            return RedirectToAction("Profile");
        }

        public IActionResult Error()
        {
            return View();
        }

    }
}
