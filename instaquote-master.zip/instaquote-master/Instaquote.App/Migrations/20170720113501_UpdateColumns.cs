﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Instaquote.App.Migrations
{
    public partial class UpdateColumns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comments_Users_Handle",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_Hearts_Users_Handle",
                table: "Hearts");

            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_Users_Handle",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Posts_Users_Handle",
                table: "Posts");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_UserEmailAddress",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_UserEmailAddress1",
                table: "Users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Users",
                table: "Users");

            migrationBuilder.RenameColumn(
                name: "UserEmailAddress1",
                table: "Users",
                newName: "Username2");

            migrationBuilder.RenameColumn(
                name: "UserEmailAddress",
                table: "Users",
                newName: "Username1");

            migrationBuilder.RenameColumn(
                name: "PorfileImage",
                table: "Users",
                newName: "ProfileImage");

            migrationBuilder.RenameIndex(
                name: "IX_Users_UserEmailAddress1",
                table: "Users",
                newName: "IX_Users_Username2");

            migrationBuilder.RenameIndex(
                name: "IX_Users_UserEmailAddress",
                table: "Users",
                newName: "IX_Users_Username1");

            migrationBuilder.RenameColumn(
                name: "Handle",
                table: "Posts",
                newName: "Username");

            migrationBuilder.RenameIndex(
                name: "IX_Posts_Handle",
                table: "Posts",
                newName: "IX_Posts_Username");

            migrationBuilder.RenameColumn(
                name: "Handle",
                table: "Notifications",
                newName: "Username");

            migrationBuilder.RenameIndex(
                name: "IX_Notifications_Handle",
                table: "Notifications",
                newName: "IX_Notifications_Username");

            migrationBuilder.RenameColumn(
                name: "Handle",
                table: "Hearts",
                newName: "Username");

            migrationBuilder.RenameIndex(
                name: "IX_Hearts_Handle",
                table: "Hearts",
                newName: "IX_Hearts_Username");

            migrationBuilder.RenameColumn(
                name: "Handle",
                table: "Comments",
                newName: "Username");

            migrationBuilder.RenameIndex(
                name: "IX_Comments_Handle",
                table: "Comments",
                newName: "IX_Comments_Username");

            migrationBuilder.AlterColumn<string>(
                name: "Username",
                table: "Users",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EmailAddress",
                table: "Users",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddPrimaryKey(
                name: "PK_Users",
                table: "Users",
                column: "Username");

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_Users_Username",
                table: "Comments",
                column: "Username",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Hearts_Users_Username",
                table: "Hearts",
                column: "Username",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_Users_Username",
                table: "Notifications",
                column: "Username",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Posts_Users_Username",
                table: "Posts",
                column: "Username",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_Username1",
                table: "Users",
                column: "Username1",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_Username2",
                table: "Users",
                column: "Username2",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comments_Users_Username",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_Hearts_Users_Username",
                table: "Hearts");

            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_Users_Username",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_Posts_Users_Username",
                table: "Posts");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_Username1",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_Username2",
                table: "Users");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Users",
                table: "Users");

            migrationBuilder.RenameColumn(
                name: "Username2",
                table: "Users",
                newName: "UserEmailAddress1");

            migrationBuilder.RenameColumn(
                name: "Username1",
                table: "Users",
                newName: "UserEmailAddress");

            migrationBuilder.RenameColumn(
                name: "ProfileImage",
                table: "Users",
                newName: "PorfileImage");

            migrationBuilder.RenameIndex(
                name: "IX_Users_Username2",
                table: "Users",
                newName: "IX_Users_UserEmailAddress1");

            migrationBuilder.RenameIndex(
                name: "IX_Users_Username1",
                table: "Users",
                newName: "IX_Users_UserEmailAddress");

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "Posts",
                newName: "Handle");

            migrationBuilder.RenameIndex(
                name: "IX_Posts_Username",
                table: "Posts",
                newName: "IX_Posts_Handle");

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "Notifications",
                newName: "Handle");

            migrationBuilder.RenameIndex(
                name: "IX_Notifications_Username",
                table: "Notifications",
                newName: "IX_Notifications_Handle");

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "Hearts",
                newName: "Handle");

            migrationBuilder.RenameIndex(
                name: "IX_Hearts_Username",
                table: "Hearts",
                newName: "IX_Hearts_Handle");

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "Comments",
                newName: "Handle");

            migrationBuilder.RenameIndex(
                name: "IX_Comments_Username",
                table: "Comments",
                newName: "IX_Comments_Handle");

            migrationBuilder.AlterColumn<string>(
                name: "EmailAddress",
                table: "Users",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Username",
                table: "Users",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddPrimaryKey(
                name: "PK_Users",
                table: "Users",
                column: "EmailAddress");

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_Users_Handle",
                table: "Comments",
                column: "Handle",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Hearts_Users_Handle",
                table: "Hearts",
                column: "Handle",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_Users_Handle",
                table: "Notifications",
                column: "Handle",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Posts_Users_Handle",
                table: "Posts",
                column: "Handle",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_UserEmailAddress",
                table: "Users",
                column: "UserEmailAddress",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_UserEmailAddress1",
                table: "Users",
                column: "UserEmailAddress1",
                principalTable: "Users",
                principalColumn: "EmailAddress",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
