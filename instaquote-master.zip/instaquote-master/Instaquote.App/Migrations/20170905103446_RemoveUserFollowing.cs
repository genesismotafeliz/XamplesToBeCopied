﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Instaquote.App.Migrations
{
    public partial class RemoveUserFollowing : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_Username1",
                table: "Users");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_Users_Username2",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_Username1",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_Username2",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Username1",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Username2",
                table: "Users");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Username1",
                table: "Users",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Username2",
                table: "Users",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Username1",
                table: "Users",
                column: "Username1");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Username2",
                table: "Users",
                column: "Username2");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_Username1",
                table: "Users",
                column: "Username1",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Users_Username2",
                table: "Users",
                column: "Username2",
                principalTable: "Users",
                principalColumn: "Username",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
