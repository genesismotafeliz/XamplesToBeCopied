﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Instaquote.App.Data;

namespace Instaquote.App.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20170719112856_InitialModel")]
    partial class InitialModel
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Comment", b =>
                {
                    b.Property<int>("CommentId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Body")
                        .IsRequired()
                        .HasMaxLength(50);

                    b.Property<DateTime>("CommentDate");

                    b.Property<string>("Handle");

                    b.Property<Guid>("PostId");

                    b.HasKey("CommentId");

                    b.HasIndex("Handle");

                    b.HasIndex("PostId");

                    b.ToTable("Comments");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Heart", b =>
                {
                    b.Property<int>("HeartId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Handle");

                    b.Property<Guid>("PostId");

                    b.HasKey("HeartId");

                    b.HasIndex("Handle");

                    b.HasIndex("PostId");

                    b.ToTable("Hearts");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Notification", b =>
                {
                    b.Property<int>("NotificationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Handle");

                    b.Property<string>("Text");

                    b.HasKey("NotificationId");

                    b.HasIndex("Handle");

                    b.ToTable("Notifications");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Post", b =>
                {
                    b.Property<Guid>("PostId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Caption")
                        .IsRequired()
                        .HasMaxLength(200);

                    b.Property<string>("Handle")
                        .IsRequired();

                    b.Property<DateTime>("PostDate");

                    b.HasKey("PostId");

                    b.HasIndex("Handle");

                    b.ToTable("Posts");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Tag", b =>
                {
                    b.Property<int>("TagId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasMaxLength(25);

                    b.Property<Guid>("PostId");

                    b.HasKey("TagId");

                    b.HasIndex("PostId");

                    b.ToTable("Tags");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.User", b =>
                {
                    b.Property<string>("EmailAddress")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("PorfileImage");

                    b.Property<string>("UserEmailAddress");

                    b.Property<string>("UserEmailAddress1");

                    b.Property<string>("Username");

                    b.HasKey("EmailAddress");

                    b.HasIndex("UserEmailAddress");

                    b.HasIndex("UserEmailAddress1");

                    b.ToTable("Users");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Comment", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Comments")
                        .HasForeignKey("Handle");

                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Comments")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Heart", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Hearts")
                        .HasForeignKey("Handle");

                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Hearts")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Notification", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Notifications")
                        .HasForeignKey("Handle");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Post", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Posts")
                        .HasForeignKey("Handle")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Tag", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Tags")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.User", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User")
                        .WithMany("Followers")
                        .HasForeignKey("UserEmailAddress");

                    b.HasOne("SocialNetwork.App.Core.Models.User")
                        .WithMany("Following")
                        .HasForeignKey("UserEmailAddress1");
                });
        }
    }
}
