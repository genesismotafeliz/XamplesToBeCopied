﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Instaquote.App.Data;

namespace Instaquote.App.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20171027192337_FollowerFollowingTables")]
    partial class FollowerFollowingTables
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("Instaquote.App.Core.Models.Comment", b =>
                {
                    b.Property<int>("CommentId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Body")
                        .IsRequired()
                        .HasMaxLength(50);

                    b.Property<DateTime>("CommentDate");

                    b.Property<Guid>("PostId");

                    b.Property<string>("Username");

                    b.HasKey("CommentId");

                    b.HasIndex("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Comments");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Heart", b =>
                {
                    b.Property<int>("HeartId")
                        .ValueGeneratedOnAdd();

                    b.Property<Guid>("PostId");

                    b.Property<string>("Username");

                    b.HasKey("HeartId");

                    b.HasIndex("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Hearts");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Post", b =>
                {
                    b.Property<Guid>("PostId")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("PostDate");

                    b.Property<string>("Thought")
                        .IsRequired()
                        .HasMaxLength(500);

                    b.Property<string>("Username")
                        .IsRequired();

                    b.HasKey("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Posts");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Repost", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<Guid>("PostId");

                    b.Property<string>("Username");

                    b.HasKey("Id");

                    b.HasIndex("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Reposts");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.User", b =>
                {
                    b.Property<string>("Username")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Bio");

                    b.Property<string>("Email");

                    b.Property<string>("FullName");

                    b.Property<string>("ProfileImage");

                    b.HasKey("Username");

                    b.ToTable("Users");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.UserFollower", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("FullName");

                    b.Property<string>("ProfileImage");

                    b.Property<string>("UserFollowName");

                    b.Property<string>("Username");

                    b.HasKey("Id");

                    b.HasIndex("Username");

                    b.ToTable("UserFollower");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.UserFollowing", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("FullName");

                    b.Property<string>("ProfileImage");

                    b.Property<string>("UserFollowName");

                    b.Property<string>("Username");

                    b.HasKey("Id");

                    b.HasIndex("Username");

                    b.ToTable("UserFollowing");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Comment", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.Post", "Post")
                        .WithMany("Comments")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Comments")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Heart", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.Post", "Post")
                        .WithMany("Hearts")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Hearts")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Post", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Posts")
                        .HasForeignKey("Username")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.Repost", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.Post", "Post")
                        .WithMany("Reposts")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Reposts")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.UserFollower", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Followers")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("Instaquote.App.Core.Models.UserFollowing", b =>
                {
                    b.HasOne("Instaquote.App.Core.Models.User", "User")
                        .WithMany("Following")
                        .HasForeignKey("Username");
                });
        }
    }
}
