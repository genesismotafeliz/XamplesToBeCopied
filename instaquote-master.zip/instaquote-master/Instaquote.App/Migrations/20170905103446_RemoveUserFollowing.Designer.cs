﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Instaquote.App.Data;

namespace Instaquote.App.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20170905103446_RemoveUserFollowing")]
    partial class RemoveUserFollowing
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Comment", b =>
                {
                    b.Property<int>("CommentId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Body")
                        .IsRequired()
                        .HasMaxLength(50);

                    b.Property<DateTime>("CommentDate");

                    b.Property<Guid>("PostId");

                    b.Property<string>("Username");

                    b.HasKey("CommentId");

                    b.HasIndex("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Comments");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Heart", b =>
                {
                    b.Property<int>("HeartId")
                        .ValueGeneratedOnAdd();

                    b.Property<Guid>("PostId");

                    b.Property<string>("Username");

                    b.HasKey("HeartId");

                    b.HasIndex("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Hearts");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Notification", b =>
                {
                    b.Property<int>("NotificationId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Text");

                    b.Property<string>("Username");

                    b.HasKey("NotificationId");

                    b.HasIndex("Username");

                    b.ToTable("Notifications");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Post", b =>
                {
                    b.Property<Guid>("PostId")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("PostDate");

                    b.Property<string>("Thought")
                        .IsRequired()
                        .HasMaxLength(500);

                    b.Property<string>("Username")
                        .IsRequired();

                    b.HasKey("PostId");

                    b.HasIndex("Username");

                    b.ToTable("Posts");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Tag", b =>
                {
                    b.Property<int>("TagId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasMaxLength(25);

                    b.Property<Guid>("PostId");

                    b.HasKey("TagId");

                    b.HasIndex("PostId");

                    b.ToTable("Tags");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.User", b =>
                {
                    b.Property<string>("Username")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Bio");

                    b.Property<string>("Email");

                    b.Property<string>("FullName");

                    b.Property<string>("ProfileImage");

                    b.HasKey("Username");

                    b.ToTable("Users");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Comment", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Comments")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Comments")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Heart", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Hearts")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Hearts")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Notification", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Notifications")
                        .HasForeignKey("Username");
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Post", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.User", "User")
                        .WithMany("Posts")
                        .HasForeignKey("Username")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("SocialNetwork.App.Core.Models.Tag", b =>
                {
                    b.HasOne("SocialNetwork.App.Core.Models.Post", "Post")
                        .WithMany("Tags")
                        .HasForeignKey("PostId")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
