using Instaquote.App.Controllers;
using Instaquote.App.Core.Models;
using Instaquote.App.Data;
using Instaquote.App.Data.Repositories;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Instaquote.Tests
{
    [TestClass]
    public class PostControllerTests
    {
        private ApplicationDbContext _context;
        private IPostRepository _postRepository;
        private IUserRepository _userRepository;

        public PostControllerTests()
        {
            _context = CreateAndSeedContext();
            _userRepository = new UserRepository(_context);
            _postRepository = new PostRepository(_context);
        }

        [TestMethod]
        public async Task CanCreatePost()
        {
            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                controller.ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                        {
                           new Claim(ClaimTypes.Name, "metse.phiri@yahoo.com")
                        }, CookieAuthenticationDefaults.AuthenticationScheme))
                    }
                };

                // Act
                var result = await controller.Create("A new thought!");

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Home", redirectResult.ControllerName);
                Assert.AreEqual("Profile", redirectResult.ActionName);
            }
        }

        [TestMethod]
        public async Task CanUpdatePost()
        {

            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                SetCurrentUser(controller);

                // Act
                var result = await controller.Update(new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"), "This post has been updated!");

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Home", redirectResult.ControllerName);
                Assert.AreEqual("Profile", redirectResult.ActionName);
            }
        }

        [TestMethod]
        public async Task CanDeletePost()
        {

            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                SetCurrentUser(controller);

                // Act
                var result = await controller.Delete(new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"));

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Home", redirectResult.ControllerName);
                Assert.AreEqual("Profile", redirectResult.ActionName);
            }
        }

        [TestMethod]
        public async Task CanRepost()
        {
            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                SetCurrentUser(controller);

                // Act
                var result = await controller.Repost(new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"));

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Home", redirectResult.ControllerName);
                Assert.AreEqual("Timeline", redirectResult.ActionName);
            }
        }

        [TestMethod]
        public async Task CanGetPost()
        {
            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                // Act
                var result = await controller.Detail(new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"));

                // Assert
                Assert.IsInstanceOfType(result, typeof(ViewResult));
                ViewResult viewResult = (ViewResult)result;

                Assert.IsInstanceOfType(viewResult.Model, typeof(Post));
                Post model = (Post)viewResult.Model;

                Assert.AreEqual("melissatorres", model.Username);
            }
        }

        [TestMethod]
        public async Task CanHeartPost()
        {
            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                controller.ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                        {
                           new Claim(ClaimTypes.Name, "metse.phiri@yahoo.com")
                        }, CookieAuthenticationDefaults.AuthenticationScheme))
                    }
                };

                // Act
                var result = await controller.HeartPost(new System.Guid("3d3739b5-29e5-4c82-b169-c689993f6360"));

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Posts", redirectResult.ControllerName);
                Assert.AreEqual("Detail", redirectResult.ActionName);
            }
        }

        [TestMethod]
        public async Task CanAddComment()
        {
            using (var controller = new PostsController(_postRepository, _userRepository))
            {
                controller.ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                        {
                               new Claim(ClaimTypes.Name, "metse.phiri@yahoo.com")
                        }, CookieAuthenticationDefaults.AuthenticationScheme))
                    }
                };

                // Act
                var result = await controller.AddComment("I just added a new comment!", new System.Guid("6dae7097-1a62-4dda-b46e-cfdfdec94e68"));

                // Assert
                Assert.IsInstanceOfType(result, typeof(RedirectToActionResult));
                RedirectToActionResult redirectResult = (RedirectToActionResult)result;

                Assert.AreEqual("Posts", redirectResult.ControllerName);
                Assert.AreEqual("Detail", redirectResult.ActionName);
            }
        }

        private ApplicationDbContext CreateAndSeedContext()
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseInMemoryDatabase();

            var context = new ApplicationDbContext(optionsBuilder.Options);

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Posts.AddRange(SeedPosts());
            context.SaveChanges();

            context.Users.AddRange(SeedUsers());
            context.SaveChanges();

            return context;
        }

        private List<User> SeedUsers()
        {
            return new List<User>
            {
                new User { Username = "melissatorres", Bio = "Mechanical Engineer @ NASA. I love haniging with family and working!", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/black-and-white-1180437_960_720.jpg", FullName = "Melissa Torres" },
                new User { Username = "timmyseaman", Bio = "Coffee Lover & Writer by trade. Doing what you like is freedom, liking what you do is happiness.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/people-852428_960_720.jpg", FullName = "Timmy Seaman" },
                new User { Username = "carolyngrover", Bio = "Fashion stylist. Highly introverted. Always looking to improve in all areas of life.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/Jessica-Anne-Mole-1-2-1140x660.jpg", FullName = "Carolyn Grover" },
                new User { Username = "jimmyclose", Bio = "Startup mentor, executive, blogger, author, tech professional, and Angel investor among other things.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/article-2405475-1B8389EE000005DC-718_634x550.jpg", FullName = "Jimmy Close" },
                new User { Username = "metsephiri", Bio = "Aspiring Fullstack Web Developer. Using popular technogies like .NET & Angular to build sick web apps.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/9FdTWaNb.jpg", Email = "metse.phiri@yahoo.com", FullName = "Metse Phiri" }
            };
        }

        private List<Post> SeedPosts()
        {
            return new List<Post>
            {
                new Post { PostId = new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"), Thought = "A work of art that contains  theories is like an object on which the price tag has been left.", Username = "melissatorres", Comments = new List<Comment> { new Comment { Body = "So true...", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "carolyngrover" }, new Repost { Username = "timmyseaman" } } },
                new Post { PostId = new System.Guid("3d3739b5-29e5-4c82-b169-c689993f6360"),Thought = "Wasted youth is better by far the a wise and productive old age.", Username = "timmyseaman", Comments = new List<Comment> { new Comment { Body = "This is one of my favourite quotes.", Username = "carolyngrover" } } },
                new Post { PostId = new System.Guid("6dae7097-1a62-4dda-b46e-cfdfdec94e68"), Thought = "Parents can only give good advice or put them on the right paths, but the final forming of a person's character lies in their own hands.", Username = "jimmyclose", Comments = new List<Comment> { new Comment { Body = "Yes!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "jimmyclose" }, new Repost { Username = "melissatorres" } }},
                new Post { Thought = "A fanatic is a nut who has something to believe in.", Username = "carolyngrover", Comments = new List<Comment> { new Comment { Body = "Like that quote!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "timmyseaman" }, new Repost { Username = "melissatorres" } } },
                new Post { Thought = "Creativity is the process of having original ideas that have value. It is a process; it's not random.", Username = "jimmyclose", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "melissatorres", Body = "Creativity is a lot things..." } } },
                new Post { Thought = "Carry out a random act of kindness, with no expectation of reward, safe in the knowledge that one day someone might do the same for you.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "carolyngrover", Body = "Heard this one many times. Love it." } } },
                new Post { Thought = "It's a small world, but I wouldn't want to paint it.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "melissatorres" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "Trying to paint it alone is hard enough."} } }
            };
        }

        private void SetCurrentUser(Controller controller)
        {
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                    {
                       new Claim(ClaimTypes.Name, "metse.phiri@yahoo.com")
                    }, CookieAuthenticationDefaults.AuthenticationScheme))
                }
            };
        }
    }
}
