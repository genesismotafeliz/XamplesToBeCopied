﻿using Instaquote.App.Controllers;
using Instaquote.App.Core.Models;
using Instaquote.App.Data;
using Instaquote.App.Data.Repositories;
using Instaquote.App.ViewModels;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Instaquote.Tests
{
    [TestClass]
    public class HomeControllerTests
    {
        private ApplicationDbContext _context;
        private IUserRepository _userRepository;
        private IPostRepository _postRepository;

        public HomeControllerTests()
        {
            _context = CreateAndSeedContext();
            _userRepository = new UserRepository(_context);
            _postRepository = new PostRepository(_context);
        }

        [TestMethod]
        public async Task CanGetUserProfile()
        {
            using (var controller = new HomeController(_postRepository, _userRepository))
            {
                // Act
                var result = await controller.UserProfile("melissatorres");

                // Assert
                Assert.IsInstanceOfType(result, typeof(ViewResult));
                ViewResult viewResult = (ViewResult)result;

                Assert.IsInstanceOfType(viewResult.Model, typeof(User));
                User model = (User)viewResult.Model;

                Assert.AreEqual("Melissa Torres", model.FullName);
            }
        }

        [TestMethod]
        public async Task CanGetTimeline()
        {
            using (var controller = new HomeController(_postRepository, _userRepository))
            {
                controller.ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                        {
                               new Claim(ClaimTypes.Name, "metse.phiri@yahoo.com")
                        }, CookieAuthenticationDefaults.AuthenticationScheme))
                    }
                };

                // Act 
                var result = await controller.Timeline();

                // Assert
                Assert.IsInstanceOfType(result, typeof(ViewResult));
                ViewResult viewResult = (ViewResult)result;

                Assert.IsInstanceOfType(viewResult.Model, typeof(TimelineViewModel));
                TimelineViewModel model = (TimelineViewModel)viewResult.Model;
                List<Post> posts = (List<Post>)model.Posts;

                Assert.AreEqual(7, posts.Count);
            }
        }

        private ApplicationDbContext CreateAndSeedContext()
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseInMemoryDatabase();

            var context = new ApplicationDbContext(optionsBuilder.Options);

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Posts.AddRange(SeedPosts());
            context.SaveChanges();

            context.Users.AddRange(SeedUsers());
            context.SaveChanges();

            return context;
        }

        private List<User> SeedUsers()
        {
            return new List<User>
            {
                new User { Username = "melissatorres", Bio = "Mechanical Engineer @ NASA. I love haniging with family and working!", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/black-and-white-1180437_960_720.jpg", FullName = "Melissa Torres" },
                new User { Username = "timmyseaman", Bio = "Coffee Lover & Writer by trade. Doing what you like is freedom, liking what you do is happiness.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/people-852428_960_720.jpg", FullName = "Timmy Seaman" },
                new User { Username = "carolyngrover", Bio = "Fashion stylist. Highly introverted. Always looking to improve in all areas of life.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/Jessica-Anne-Mole-1-2-1140x660.jpg", FullName = "Carolyn Grover" },
                new User { Username = "jimmyclose", Bio = "Startup mentor, executive, blogger, author, tech professional, and Angel investor among other things.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/article-2405475-1B8389EE000005DC-718_634x550.jpg", FullName = "Jimmy Close" },
                new User { Username = "metsephiri", Bio = "Aspiring Fullstack Web Developer. Using popular technogies like .NET & Angular to build sick web apps.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/9FdTWaNb.jpg", Email = "metse.phiri@yahoo.com", FullName = "Metse Phiri" }
            };
        }

        private List<Post> SeedPosts()
        {
            return new List<Post>
            {
                new Post { Thought = "A work of art that contains  theories is like an object on which the price tag has been left.", Username = "melissatorres", Comments = new List<Comment> { new Comment { Body = "So true...", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "carolyngrover" }, new Repost { Username = "timmyseaman" } } },
                new Post { Thought = "Wasted youth is better by far the a wise and productive old age.", Username = "timmyseaman", Comments = new List<Comment> { new Comment { Body = "This is one of my favourite quotes.", Username = "carolyngrover" } } },
                new Post { Thought = "Parents can only give good advice or put them on the right paths, but the final forming of a person's character lies in their own hands.", Username = "jimmyclose", Comments = new List<Comment> { new Comment { Body = "Yes!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "jimmyclose" }, new Repost { Username = "melissatorres" } }},
                new Post { Thought = "A fanatic is a nut who has something to believe in.", Username = "carolyngrover", Comments = new List<Comment> { new Comment { Body = "Like that quote!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "timmyseaman" }, new Repost { Username = "melissatorres" } } },
                new Post { Thought = "Creativity is the process of having original ideas that have value. It is a process; it's not random.", Username = "jimmyclose", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "melissatorres", Body = "Creativity is a lot things..." } } },
                new Post { Thought = "Carry out a random act of kindness, with no expectation of reward, safe in the knowledge that one day someone might do the same for you.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "carolyngrover", Body = "Heard this one many times. Love it." } } },
                new Post { Thought = "It's a small world, but I wouldn't want to paint it.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "melissatorres" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "Trying to paint it alone is hard enough."} } }
            };
        }
    }
}
