﻿using Instaquote.App.Core.Models;
using Instaquote.App.Data;
using Instaquote.App.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Instaquote.Tests.RepositoryTests
{
    [TestClass]
    [TestCategory("Users")]
    public class UserRepositoryTests
    {
        private IUserRepository sut;
        private ApplicationDbContext _context;

        [TestMethod]
        public async Task CanGetUserData()
        {
            _context = CreateAndSeedContext();
            sut = new UserRepository(_context);

            var user = await sut.GetUserData("melissatorres");

            Assert.AreEqual("melissatorres", user.Username);
            Assert.IsNotNull(user.Posts);
        }

        [TestMethod]
        public async Task CanGetOtherUsers()
        {
            _context = CreateAndSeedContext();
            sut = new UserRepository(_context);

            IEnumerable<User> users = await sut.GetOtherUsers("timmyseaman@email.com");

            Assert.AreEqual(4, users.Count());
            Assert.AreNotSame(users, _context.Users);
        }

        [TestMethod]
        public async Task CanGetCurrentUser()
        {
            _context = CreateAndSeedContext();
            sut = new UserRepository(_context);

            User user = await sut.GetCurrentUser("metse.phiri@yahoo.com");

            Assert.AreEqual("Metse Phiri", user.FullName);
        }

        private ApplicationDbContext CreateAndSeedContext()
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseInMemoryDatabase();

            var context = new ApplicationDbContext(optionsBuilder.Options);

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Posts.AddRange(SeedPosts());
            context.Users.AddRange(SeedUsers());

            context.SaveChanges();

            return context;
        }

        private List<User> SeedUsers()
        {
            return new List<User>
            {
                new User { Username = "melissatorres", Bio = "Mechanical Engineer @ NASA. I love haniging with family and working!", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/black-and-white-1180437_960_720.jpg", FullName = "Melissa Torres" },
                new User { Username = "timmyseaman", Bio = "Coffee Lover & Writer by trade. Doing what you like is freedom, liking what you do is happiness.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/people-852428_960_720.jpg", FullName = "Timmy Seaman", Email = "timmyseaman@email.com" },
                new User { Username = "carolyngrover", Bio = "Fashion stylist. Highly introverted. Always looking to improve in all areas of life.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/Jessica-Anne-Mole-1-2-1140x660.jpg", FullName = "Carolyn Grover" },
                new User { Username = "jimmyclose", Bio = "Startup mentor, executive, blogger, author, tech professional, and Angel investor among other things.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/article-2405475-1B8389EE000005DC-718_634x550.jpg", FullName = "Jimmy Close" },
                new User { Username = "metsephiri", Bio = "Aspiring Fullstack Web Developer. Using popular technogies like .NET & Angular to build sick web apps.", ProfileImage = "https://metseworkspace.blob.core.windows.net/instaquote/9FdTWaNb.jpg", Email = "metse.phiri@yahoo.com", FullName = "Metse Phiri" }
            };
        }

        private List<Post> SeedPosts()
        {
            return new List<Post>
            {
                new Post { PostId = new System.Guid("a68c076f-6399-49b7-8665-4e74eb902a32"), Thought = "A work of art that contains  theories is like an object on which the price tag has been left.", Username = "melissatorres", Comments = new List<Comment> { new Comment { Body = "So true...", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "carolyngrover" }, new Repost { Username = "timmyseaman" } } },
                new Post { PostId = new System.Guid("3d3739b5-29e5-4c82-b169-c689993f6360"),Thought = "Wasted youth is better by far the a wise and productive old age.", Username = "timmyseaman", Comments = new List<Comment> { new Comment { Body = "This is one of my favourite quotes.", Username = "carolyngrover" } } },
                new Post { PostId = new System.Guid("6dae7097-1a62-4dda-b46e-cfdfdec94e68"), Thought = "Parents can only give good advice or put them on the right paths, but the final forming of a person's character lies in their own hands.", Username = "jimmyclose", Comments = new List<Comment> { new Comment { Body = "Yes!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "jimmyclose" }, new Repost { Username = "melissatorres" } }},
                new Post { Thought = "A fanatic is a nut who has something to believe in.", Username = "carolyngrover", Comments = new List<Comment> { new Comment { Body = "Like that quote!", Username = "jimmyclose" } }, Reposts = new List<Repost> { new Repost { Username = "timmyseaman" }, new Repost { Username = "melissatorres" } } },
                new Post { Thought = "Creativity is the process of having original ideas that have value. It is a process; it's not random.", Username = "jimmyclose", Hearts = new List<Heart> { new Heart { Username = "jimmyclose" } }, Comments = new List<Comment> { new Comment { Username = "melissatorres", Body = "Creativity is a lot things..." } } },
                new Post { Thought = "Carry out a random act of kindness, with no expectation of reward, safe in the knowledge that one day someone might do the same for you.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "timmyseaman" } }, Comments = new List<Comment> { new Comment { Username = "carolyngrover", Body = "Heard this one many times. Love it." } } },
                new Post { Thought = "It's a small world, but I wouldn't want to paint it.", Username = "carolyngrover", Hearts = new List<Heart> { new Heart { Username = "melissatorres" } }, Comments = new List<Comment> { new Comment { Username = "timmyseaman", Body = "Trying to paint it alone is hard enough."} } }
            };
        }
    }
}
