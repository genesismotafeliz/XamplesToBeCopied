# Instaquote
Instaquote is a simple social network that allows users to post quotes & view other's quotes. 

## Getting Started
These instructions will get you a copy of the project up and running on your local machine for development.

### Prerequisites
* .NET Core tooling
* Update the connection string to your own database

## Built With
* Authentication: Auth0
* ASP.NET Core MVC
* Entity Framework Core
* Bootstrap 4
* Unit Tests: MSTest (& In-Memory Database)

## Authors
* Metse Phiri

## LICENSE
MIT
