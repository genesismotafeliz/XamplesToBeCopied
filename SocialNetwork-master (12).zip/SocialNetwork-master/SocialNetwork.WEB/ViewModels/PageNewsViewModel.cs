﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialNetwork.WEB.ViewModels
{
    public class PageNewsViewModel
    {
        public List<PostViewModel> Posts { get; set; }
    }
}