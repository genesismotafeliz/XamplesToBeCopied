using System.Web.Mvc;

namespace Coombu.Areas.RouteDebugger.Controllers
{
    public class RouteDebuggerController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
