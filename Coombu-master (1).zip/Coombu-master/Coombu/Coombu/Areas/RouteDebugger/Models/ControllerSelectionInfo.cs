namespace Coombu.Areas.RouteDebugger.Models
{
    public class ControllerSelectionInfo
    {
        public string ControllerName { get; set; }

        public string ControllerType { get; set; }
    }
}
