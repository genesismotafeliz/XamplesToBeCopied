﻿namespace Coombu.Models
{
    public enum SearchScope
    {
        UserScope,
        StatusScope,
        AllScope
    }
}
