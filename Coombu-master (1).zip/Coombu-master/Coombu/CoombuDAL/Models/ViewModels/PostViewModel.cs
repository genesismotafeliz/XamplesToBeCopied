﻿using System;

namespace Coombu.Models.ViewModels
{
    public class PostViewModel
    {
        public Post Post { get; set; }
        public Boolean IsLiked { get; set; }
    }
}
