﻿using System;

namespace Coombu.Models.ViewModels
{
    public class Credentials
    {
        public String Username { get; set; }
        public String Password { get; set; }
    }
}
