﻿namespace Coombu.Models.ViewModels
{
    public class DetailGroupViewModel
    {
        public PostViewModelCreate CreatePostModel { get; set; }
        public GroupViewModel GroupViewModel { get; set; }
    }
}
