Cöombu
======

ASP.NET MVC Social Business Enterprise Network application

Coming soon... 

Sujets:
 - [Partie 1](https://dl.dropbox.com/u/5552535/Supinfo/Projects/MS%20Dev/MP-4NETS1-C%C3%B6ombu.pdf)
 - [Partie 2](https://dl.dropbox.com/u/5552535/Supinfo/Projects/MS%20Dev/MP-4NETS2.pdf)

Supinfo, Montréal &copy;2013 Guillaume Maka
