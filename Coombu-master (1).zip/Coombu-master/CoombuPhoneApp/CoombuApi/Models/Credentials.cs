﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coombu.Models
{
    public class Credentials
    {
        public String Username { get; set; }
        public String Password { get; set; }
    }
}
