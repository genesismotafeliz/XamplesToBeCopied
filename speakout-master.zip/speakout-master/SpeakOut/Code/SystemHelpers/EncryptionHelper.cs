﻿
namespace SpeakYourMind.SystemHelpers
{
    public class EncryptionHelper
    {
        public static string Encrypt(string clearText)
        {
            return clearText;
        }

        public static string Decrypt(string encryptedText)
        {
            return encryptedText;
        }
    }
}
