XuzzleRand
==========

This app is a modified version of the example of Xamarin called Xuzzle.
https://github.com/xamarin/xamarin-forms-samples/tree/master/Xuzzle

It was tested only on Android.

Differences
-----------

- A "new game" button.
- Random texts in every new game.
- Colors and larger font.

You can find the list of bad words here: 
https://gist.github.com/ryanlewis/a37739d710ccdb4b406d
