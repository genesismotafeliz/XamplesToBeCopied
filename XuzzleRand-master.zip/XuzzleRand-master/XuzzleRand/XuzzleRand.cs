﻿using System;
using Xamarin.Forms;

namespace XuzzleRand
{
	public class App : Application
	{
		public App ()
		{
			MainPage = new XuzzleRandPage();
		}
	}
}
