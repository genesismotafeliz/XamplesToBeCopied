﻿
namespace SocialGoal.Data.Infrastructure
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}
