﻿
using System;
namespace SocialGoal.Model.Models
{
    public class GroupCommentUser
    {
        public int GroupCommentUserId { get; set; }

        public int GroupCommentId { get; set; }

        public string UserId { get; set; }

    }
}
