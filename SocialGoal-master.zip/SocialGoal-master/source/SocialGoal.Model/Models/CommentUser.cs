﻿
using System;
namespace SocialGoal.Model.Models
{
    public class CommentUser
    {
        public int CommentUserId { get; set; }

        public int CommentId { get; set; }

        public string UserId { get; set; }

    }
}
