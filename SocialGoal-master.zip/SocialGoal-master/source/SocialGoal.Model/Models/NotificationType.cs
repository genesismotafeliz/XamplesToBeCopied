﻿
namespace SocialGoal.Model.Models
{
    public enum NotificationType
    {
        createdGoal = 0, updatedGoal, commentedOnUpdate, createGroup, supportGoal, joinGroup, updatedGroupgoal, commentedonGroupUdate, followUser
    }
}
