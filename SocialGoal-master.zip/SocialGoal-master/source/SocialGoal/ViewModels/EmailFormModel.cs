﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialGoal.Web.ViewModels
{
    public class EmailFormModel
    {
        public string Email { get; set; }

    }
}