# SocialNetworkDemo
 A demonestration of a Social Networking site with ASP.NET MVC &amp; Entity Framework
