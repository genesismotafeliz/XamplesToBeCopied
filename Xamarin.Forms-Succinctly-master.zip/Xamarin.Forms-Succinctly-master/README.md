# Xamarin.Forms Succinctly

This is the companion repo for [*Xamarin.Forms Succinctly*](https://www.syncfusion.com/ebooks/Xamarin_Forms_Succinctly) by Alessandro Del Sole. Published by Syncfusion.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/Xamarin.Forms-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/Xamarin_Forms_Succinctly)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).
