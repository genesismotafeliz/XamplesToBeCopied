# Libraries

This layer is responsible for working with IO, providing utilities, working with database and processing information.