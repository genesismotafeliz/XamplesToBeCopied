# Green.Data

Database Access Layer `Green.Data` builds the query based on received parameters from the `Green.Services` layer and passes it to the data base to execute. And simple return results from the database to `Green.Services`.
