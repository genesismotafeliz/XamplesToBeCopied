# Green.Web.Framework

This layer provide some utilities for `Green.Web` layer.