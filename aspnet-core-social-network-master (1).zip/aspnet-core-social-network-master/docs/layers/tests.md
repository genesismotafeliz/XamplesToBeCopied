# Tests

We write test for each layer to know everything works as expected.

## API

Test API.

## Services

Test services.

## Controllers

Test Controllers.