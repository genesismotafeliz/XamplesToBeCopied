# Green.Core

Core layer provides `Domain` and some utilities for all layers. This layer has common tools for all layers and it's completely independent of other layers.