# Green.Web

This layer provide REST API and transfer information to user interface.