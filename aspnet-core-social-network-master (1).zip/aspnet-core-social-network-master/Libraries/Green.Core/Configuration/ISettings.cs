﻿
namespace Green.Core.Configuration
{
    /// <summary>
    /// Setting interface
    /// </summary>
    public interface ISettings
    {
    }
}
