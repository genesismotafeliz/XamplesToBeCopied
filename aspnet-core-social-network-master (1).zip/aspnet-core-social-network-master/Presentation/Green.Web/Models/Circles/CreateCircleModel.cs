﻿using System;
namespace Green.Web.Models.Circles
{
    public class CreateCircleModel
    {
        public CreateCircleModel()
        {

        }
        public string CircleName
        {
            get;
            set;
        }
    }
}
