# DonationSocialNetwork

To-do List:

	1. Make expense dynamic from hard-code (Akash done)
	2. Pay page (Akash done)
	3. Approval page (Aditya done)
		a. Pending (imp)
		b. Complete
	4. Login page (Aditya done)
	5. See donations (Akash)
	6. See self needs (Akash)
	7. See approved needs (Aditya done)
	8. Fetch user list from DB (Aditya done)
	9. Payment form
           Resources:
           http://www.flipkart.com/help/savedcard_how
