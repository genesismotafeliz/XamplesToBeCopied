﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSN.Controllers
{
    public static class Constants
    {
        public static string UserId = "Id";
    }
}
