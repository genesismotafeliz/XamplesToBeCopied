﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSN.Models
{
    public class RecDonationViewModel
    {
        public int expenseId;

        public string expenseName;

        public int donorId;

        public string donorName;

        public DateTime donationTime;

        public int donationAmt;
    }
}
