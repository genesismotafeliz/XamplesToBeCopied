﻿CREATE TABLE [dbo].[Individual]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(MAX) NOT NULL, 
    [Title] VARCHAR(MAX) NULL, 
    [Organization] VARCHAR(MAX) NULL
)
