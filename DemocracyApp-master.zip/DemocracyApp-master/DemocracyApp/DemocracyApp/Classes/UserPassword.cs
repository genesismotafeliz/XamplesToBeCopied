﻿namespace DemocracyApp.Classes
{
    public class UserPassword : User    
    {
        public string CurrentPassword { get; set; }
    }
}
