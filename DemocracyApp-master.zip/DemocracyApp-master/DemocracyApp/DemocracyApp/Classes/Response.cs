﻿namespace DemocracyApp.Classes
{
    public class Response
    {
        public string Message { get; set; }
    }
}
