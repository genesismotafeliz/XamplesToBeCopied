﻿using System.Web;
using System.Web.Mvc;

namespace John.Doyle.Mediocore.Developer
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
