# The Medicore Developer
Blogging and social network for Developers.