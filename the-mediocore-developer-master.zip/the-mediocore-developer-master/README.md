# the-mediocre-developer
An Angular 4 Web App for fun 
