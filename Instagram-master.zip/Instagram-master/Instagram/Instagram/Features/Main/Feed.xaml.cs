﻿using Xamarin.Forms.Xaml;

namespace Instagram.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Feed
	{
		public Feed ()
		{
			InitializeComponent ();
		}
	}
}