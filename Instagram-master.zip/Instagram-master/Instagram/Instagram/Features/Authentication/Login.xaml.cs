﻿using Xamarin.Forms.Xaml;

namespace Instagram.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Login
	{
		public Login ()
		{
			InitializeComponent ();
		}
	}
}