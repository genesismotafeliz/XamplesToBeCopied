﻿
namespace StudentsHandbook.Domain.Models
{
    using System;

    public class Comment : Entity
    {
        public int CreatorId { get; set; }

        public int GroupId { get; set; }

        public string Text { get; set; }

        public DateTime CreationTime { get; set; }
    }
}
