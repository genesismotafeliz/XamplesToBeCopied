﻿
namespace StudentsHandbook.Domain.Models
{
    public class Teacher : Entity
    {
        public string Name { get; set; }

        public string Surname { get; set; }

        public string LastName { get; set; }

        public string FileNamePathToPhoto { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public string Pulpit { get; set; }

        public string AdditionalInfo { get; set; } 

        public string Degree { get; set; }
    }
}
