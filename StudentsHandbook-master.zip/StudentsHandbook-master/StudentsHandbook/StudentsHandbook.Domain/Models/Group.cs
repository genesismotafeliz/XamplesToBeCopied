﻿
namespace StudentsHandbook.Domain.Models
{
    public class Group : Entity
    {
        public string Name { get; set; }

        public string NameShortened { get; set; }
    }
}
