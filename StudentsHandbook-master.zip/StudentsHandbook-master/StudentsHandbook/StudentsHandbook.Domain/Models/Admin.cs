
namespace StudentsHandbook.Domain.Models
{
    public class Admin : Entity
    {
        public string PasswordHash { get; set; }
    }
}
