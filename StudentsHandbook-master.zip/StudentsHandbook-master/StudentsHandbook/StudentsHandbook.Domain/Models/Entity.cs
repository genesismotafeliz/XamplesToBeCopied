﻿
namespace StudentsHandbook.Domain.Models
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }
}
