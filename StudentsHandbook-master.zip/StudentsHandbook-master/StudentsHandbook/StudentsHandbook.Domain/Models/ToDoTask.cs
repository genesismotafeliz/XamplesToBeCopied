﻿
namespace StudentsHandbook.Domain.Models
{
    using System;

    public class ToDoTask : Entity
    {
        public int CreatorId { get; set; }

        public string TaskTitle { get; set; }

        public string Text { get; set; }

        public DateTime DateOfCreation { get; set; }

        public DateTime DateOfDeadline { get; set; }
    }
}
