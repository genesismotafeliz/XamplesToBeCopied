﻿
namespace StudentsHandbook.Domain.Models
{
    using System;

    public class Lesson : Entity
    {
        public int GroupId { get; set; }

        public string LessonSubject { get; set; }

        public string DeptBuilding { get; set; }

        public int RoomNumber { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        public int TeacherId { get; set; }
    }
}
