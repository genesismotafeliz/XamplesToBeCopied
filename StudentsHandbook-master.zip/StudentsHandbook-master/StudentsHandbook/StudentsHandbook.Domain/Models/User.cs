﻿
namespace StudentsHandbook.Domain.Models
{
    using System.ComponentModel.DataAnnotations;

    public class User : Entity
    {
        public bool IsOnline { get; set; }

        [StringLength(64)]
        public string FirstName { get; set; }

        [StringLength(64)]
        public string LastName { get; set; }

        public int GroupId { get; set; }
        
        public int Course { get; set; }

        public string FileNamePathToPhoto { get; set; }

        [StringLength(32)]
        public string Phone { get; set; }

        [StringLength(64)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [StringLength(64)]
        public string Login { get; set; }

        [StringLength(256)]
        [DataType(DataType.Password)]
        public string PasswordHash { get; set; }
    }
}
