﻿
namespace StudentsHandbook.ViewModels.Home
{
    using System.Collections.Generic;

    using StudentsHandbook.Domain.Models;

    public class IndexViewModel
    {
        public User User { get; set; }

        public Group Group { get; set; }

        public List<ToDoTask> ToDoTasks { get; set; } // first 3 closest to deadline tasks

        public List<Lesson> TodaySchedule { get; set; }

        public List<Lesson> TomorrowSchedule { get; set; }

        public List<User> GroupMatesOnline { get; set; }

        public List<Teacher> TeachersForSchedule { get; set; }
    }
}
