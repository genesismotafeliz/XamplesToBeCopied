﻿
namespace StudentsHandbook.ViewModels.Home
{
    using System.Collections.Generic;

    using StudentsHandbook.Domain.Models;

    public class ScheduleViewModel
    {
        public List<List<Lesson>> Lessons { get; set; }

        public List<Teacher> Teachers { get; set; }
    }
}
