﻿
namespace StudentsHandbook.ViewModels.Home
{
    public class SettingsViewModel
    {
        // todo add logic to change/add initial info of the user;
    }
}
