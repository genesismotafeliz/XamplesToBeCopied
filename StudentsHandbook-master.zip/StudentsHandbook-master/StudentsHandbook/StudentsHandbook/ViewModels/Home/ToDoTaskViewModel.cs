﻿
namespace StudentsHandbook.ViewModels.Home
{
    using System.Collections.Generic;
    using StudentsHandbook.Domain.Models;

    public class ToDoTaskViewModel
    {
        public readonly Group Group;

        public readonly List<User> GroupMates;

        public ToDoTaskViewModel(Group group, List<User> groupMates)
        {
            this.Group = group;
            this.GroupMates = groupMates;
        }
    }
}
