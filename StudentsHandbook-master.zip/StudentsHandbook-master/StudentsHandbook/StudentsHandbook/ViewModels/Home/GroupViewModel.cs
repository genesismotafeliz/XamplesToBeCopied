﻿
namespace StudentsHandbook.ViewModels.Home
{
    using System.Collections.Generic;
    using StudentsHandbook.Domain.Models;

    public class GroupViewModel
    {
        public Group Group { get; set; }

        public List<User> AllGroupMates { get; set; }
    }
}
