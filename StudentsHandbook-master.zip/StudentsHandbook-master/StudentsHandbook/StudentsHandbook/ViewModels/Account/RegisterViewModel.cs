﻿
namespace StudentsHandbook.ViewModels.Account
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using StudentsHandbook.Domain.Models;

    public class RegisterViewModel
    {
        public List<Group> GroupList { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Surname is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Group is required")]
        public int GroupId { get; set; }

        [Required(ErrorMessage = "Course is required")]
        [Range(1, 5, ErrorMessage = "A number between 1 and 5")]
        public int Course { get; set; }

        [Required(ErrorMessage = "Email address is required")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password was not specified")]
        [StringLength(64, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords don't match")]
        public string ConfirmPassword { get; set; }
    }
}
