﻿
namespace StudentsHandbook.ViewModels.Account
{
    using System.ComponentModel.DataAnnotations;

    public class LoginViewModel
    {
        [Required(ErrorMessage = "Email was not specified")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password was not specified")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
