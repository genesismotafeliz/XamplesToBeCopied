﻿
namespace StudentsHandbook.ViewModels.Users
{
    using StudentsHandbook.Domain.Models;

    public class UsersIndexViewModel
    {
        public User User { get; set; }

        public Group Group { get; set; }
    }
}
