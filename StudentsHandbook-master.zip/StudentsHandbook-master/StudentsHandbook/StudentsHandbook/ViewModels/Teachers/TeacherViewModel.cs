﻿
namespace StudentsHandbook.ViewModels.Teachers
{
    using System.Collections.Generic;
    using StudentsHandbook.Domain.Models;

    public class TeacherViewModel
    {
        public List<Group> Groups { get; set; }

        public List<Teacher> Teachers { get; set; }
    }
}
