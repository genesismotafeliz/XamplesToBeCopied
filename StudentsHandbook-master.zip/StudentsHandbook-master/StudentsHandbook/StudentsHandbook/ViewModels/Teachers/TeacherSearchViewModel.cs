﻿
namespace StudentsHandbook.ViewModels.Teachers
{
    using System.Collections.Generic;
    using StudentsHandbook.Domain.Models;

    public class TeacherSearchViewModel
    {
        public string TeacherSurname { get; set; }

        public List<Teacher> AllTeachers { get; set; }

        public List<Teacher> FoundTeachers { get; set; }
    }
}
