﻿
namespace StudentsHandbook.ViewModels.Teachers
{
    using System.Collections.Generic;
    using StudentsHandbook.Domain.Models;

    public class TeacherInfoViewModel
    {
        public Teacher Teacher { get; set; }

        public List<Group> Groups { get; set; }

        public List<List<Lesson>> TeacherSchedule { get; set; }
    }
}
