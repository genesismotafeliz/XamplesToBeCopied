﻿
namespace StudentsHandbook.ViewModels.Teachers
{
    using System.Collections.Generic;

    using StudentsHandbook.Domain.Models;

    public class TeacherIndexViewModel
    {
        public List<Teacher> Teachers { get; set; }

        public Teacher TeacherSurname { get; set; }
    }
}
