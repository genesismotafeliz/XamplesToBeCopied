﻿
namespace StudentsHandbook.Controllers
{
    using System;
    using System.Diagnostics;
    using System.Linq;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.Services.Services;
    using StudentsHandbook.ViewModels.Home;

    public class HomeController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly IGroupRepository groupRepository;
        private readonly IToDoTasksRepository toDoTasksRepository;
        private readonly ILessonRepository lessonRepository;
        private readonly ITeacherRepository teacherRepository;
        private readonly ScheduleService scheduleService;

        public HomeController(
            IUserRepository userRepo, 
            IGroupRepository groupRepo, 
            IToDoTasksRepository todoRepo, 
            ILessonRepository lessonRepo, 
            ITeacherRepository teacherRepo,
            ScheduleService scheduleService)
        {
            this.userRepository = userRepo;
            this.groupRepository = groupRepo;
            this.toDoTasksRepository = todoRepo;
            this.lessonRepository = lessonRepo;
            this.teacherRepository = teacherRepo;
            this.scheduleService = scheduleService;
            }

        [Authorize]
        public IActionResult Index()
        {
            var user = this.userRepository.GetUserByEmail(this.HttpContext.User.Identity.Name);
            var index = new IndexViewModel();
            index.User = user;
            index.Group = this.groupRepository.Get(index.User.GroupId);
            index.GroupMatesOnline = this.userRepository.GetGroupMatesOnline(index.User.GroupId, index.User.Id, index.User.Course);
            index.ToDoTasks = this.toDoTasksRepository.GetTopThreeSoonExpiringTasks(index.User.Id);
            var lessons = this.lessonRepository.GetLessonsOfGroupForPeriod(
                index.User.GroupId,
                DateTime.Today,
                DateTime.Today.AddDays(1));

            index.TodaySchedule = lessons.Where(l => l.StartTime.Date == DateTime.Today.AddDays(1)).ToList();
            index.TomorrowSchedule = lessons.Where(l => l.StartTime.Date == DateTime.Today).ToList();
            index.TeachersForSchedule = this.teacherRepository.FindTeachersForSchedule(lessons);
            return this.View(index);
        }

        [Authorize]
        public IActionResult Schedule()
        {
            var usersGroupId = this.userRepository.GetUserByEmail(this.HttpContext.User.Identity.Name).GroupId;
            var schedules = this.scheduleService.GetCurrentWeekLessonsOfGroup(usersGroupId, DateTime.Now.Date);
            var teachers = this.teacherRepository.GetAllTeachers();
            return this.View(new ScheduleViewModel() { Teachers = teachers, Lessons = schedules }); 
        }

        [Authorize]
        public IActionResult ToDoTasks()
        {
            var userId = this.userRepository.GetUserByEmail(this.HttpContext.User.Identity.Name).Id;
            var tasks = this.toDoTasksRepository.GetAllUsersTasks(userId);
            return this.View(tasks);
        }

        [Authorize]
        public IActionResult Group()
        {
            var user = this.userRepository.GetUserByEmail(this.HttpContext.User.Identity.Name);
            var group = this.groupRepository.Get(user.GroupId);
            var groupMates = this.userRepository.GetAllGroupMates(user.GroupId, user.Id, user.Course);
            return this.View(new GroupViewModel() { Group = group, AllGroupMates = groupMates });
        }

        public IActionResult Error()
        {
            return this.View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? this.HttpContext.TraceIdentifier });
        }
    }
}
