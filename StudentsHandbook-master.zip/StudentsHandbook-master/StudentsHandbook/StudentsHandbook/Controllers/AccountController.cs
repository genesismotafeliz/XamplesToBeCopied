﻿
namespace StudentsHandbook.Controllers
{
    using System.Collections.Generic;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Authentication.Cookies;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.Domain.Models;
    using StudentsHandbook.ViewModels.Account;


    public class AccountController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly IGroupRepository groupRepository;

        public AccountController(IUserRepository userRepo, IGroupRepository groupRepo)
        {
            this.userRepository = userRepo;
            this.groupRepository = groupRepo;
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult Login()
        {
            return this.View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (this.ModelState.IsValid)
            {
                var user = await this.userRepository.GetUserAsync(model.Email);
                if (user != null)
                {
                    await this.Authenticate(model.Email);

                    return this.RedirectToAction("Index", "Home");
                }

                this.ModelState.AddModelError("Error", "Login or password is incorrect.");
            }

            return this.View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register()
        {
            return this.View(new RegisterViewModel() { GroupList = this.groupRepository.GetGroups() });
        }

        [HttpPost] 
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            model.GroupList = this.groupRepository.GetGroups();
            if (!this.ModelState.IsValid)
            {
                return this.View(model);
            }

            var user = await this.userRepository.GetUserAsync(model.Email);
            if (user == null)
            {
                var newUser = new User()
                                  {
                                      FirstName = model.FirstName,
                                      LastName = model.LastName,
                                      Email = model.Email,
                                      PasswordHash = model.Password,
                                      IsOnline = true,
                                      GroupId = model.GroupId,
                                      Course = model.Course
                                  };

                this.userRepository.Create(newUser);
                await this.userRepository.SaveAsync();

                await this.Authenticate(newUser.Email);

                return this.RedirectToAction("Index", "Home");
            }

            this.ModelState.AddModelError("Error", "Email is already taken.");
            return this.View(model);
        }

        public async Task<IActionResult> Logout()
        {
            await this.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return this.RedirectToAction("Login", "Account");
        }

        private async Task Authenticate(string email)
        {
            var claims = new List<Claim>
                             {
                                 new Claim(ClaimsIdentity.DefaultNameClaimType, email)
                             };

            var id = new ClaimsIdentity(claims, "ApplicationCookie", ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);

            await this.HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(id));
        }
    }
}