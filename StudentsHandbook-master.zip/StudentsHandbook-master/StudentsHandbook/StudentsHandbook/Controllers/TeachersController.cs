﻿
namespace StudentsHandbook.Controllers
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.Services.Services;
    using StudentsHandbook.ViewModels.Teachers;

    public class TeachersController : Controller
    {
        private readonly IGroupRepository groupRepository;
        private readonly ITeacherRepository teacherRepository;
        private readonly ScheduleService scheduleService;

        public TeachersController(
            IGroupRepository groupRepo,
            ILessonRepository lessonRepo,
            ITeacherRepository teacherRepo,
            ScheduleService scheduleService)
        {
            this.groupRepository = groupRepo;
            this.teacherRepository = teacherRepo;
            this.scheduleService = scheduleService;
        }

        public IActionResult Index()
        {
            var teachers = this.teacherRepository.GetAllTeachers();
            return this.View(new TeacherIndexViewModel() { Teachers = teachers});
        }

        [HttpGet]
        public IActionResult Search()
        {
            var searchViewModel = new TeacherSearchViewModel() { AllTeachers = this.teacherRepository.GetAllTeachers() };
            return this.View(searchViewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Search(TeacherSearchViewModel searchViewModel)
        {
            var foundTeachers = await this.teacherRepository.FindTeachersBySurnameAsync(searchViewModel.TeacherSurname);
            return this.View(
                new TeacherSearchViewModel()
                    {
                        FoundTeachers = foundTeachers,
                        TeacherSurname = searchViewModel.TeacherSurname,
                        AllTeachers = searchViewModel.AllTeachers // todo: look at the result;
                    });
        }

        public IActionResult TeacherInfo(int id)
        {
            var teacher = this.teacherRepository.Get(id);
            var groups = this.groupRepository.GetGroups();
            var schedule = this.scheduleService.GetCurrentWeekLessonsOfTeacher(id, DateTime.Today);
            return this.View(
                new TeacherInfoViewModel() { Teacher = teacher, Groups = groups, TeacherSchedule = schedule });
        }
    }
}