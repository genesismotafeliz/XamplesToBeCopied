﻿
namespace StudentsHandbook.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.ViewModels.Users;

    public class UsersController : Controller
    {
        private readonly IUserRepository userRepository;

        private readonly IGroupRepository groupRepository;

        public UsersController(IUserRepository userRepo, IGroupRepository groupRepo)
        {
            this.userRepository = userRepo;
            this.groupRepository = groupRepo;
        }

        [Authorize]
        public IActionResult Index(int id)
        {
            var user = this.userRepository.Get(id);
            var group = this.groupRepository.Get(user.GroupId);

            return this.View(new UsersIndexViewModel() { User = user, Group = group });
        }
    }
}