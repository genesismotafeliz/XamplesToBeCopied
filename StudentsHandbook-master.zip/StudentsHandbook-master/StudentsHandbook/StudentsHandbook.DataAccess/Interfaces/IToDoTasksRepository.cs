﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using System.Collections.Generic;

    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface IToDoTasksRepository : IGenericRepository<ToDoTask>
    {
        List<ToDoTask> GetAllUsersTasks(int userId);

        List<ToDoTask> GetTopThreeSoonExpiringTasks(int userId);

        void CreateTask(ToDoTask task);

        void CloseTask(int id);

        void RenewTask(int id);
    }
}