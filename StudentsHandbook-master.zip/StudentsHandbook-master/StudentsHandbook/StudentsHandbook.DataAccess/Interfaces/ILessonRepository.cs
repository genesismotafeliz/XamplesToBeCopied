﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using System;
    using System.Collections.Generic;
    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface ILessonRepository : IGenericRepository<Lesson>
    {
        List<Lesson> GetAllLessons();

        List<Lesson> GetLessonsOfGroup(int groupId);

        List<Lesson> GetLessonsOfTeacherForPeriod(int teacherId, DateTime startOfPeriod, DateTime endOfPeriod);

        List<Lesson> GetScheduleForDay(int groupId, DateTime day);

        List<Lesson> GetLessonsOfGroupForPeriod(int groupId, DateTime startOfPeriod, DateTime endOfPeriod);
    }
}