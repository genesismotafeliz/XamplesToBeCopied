﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface IUserRepository : IGenericRepository<User>
    {
        List<User> GetAllGroupMates(int groupId, int userId, int userCourse);

        List<User> GetGroupMatesOnline(int groupId, int userId, int userCourse);

        List<User> GetAllUsers();

        Task<User> GetUserAsync(string email);

        User GetUserByEmail(string email);
    }
}
