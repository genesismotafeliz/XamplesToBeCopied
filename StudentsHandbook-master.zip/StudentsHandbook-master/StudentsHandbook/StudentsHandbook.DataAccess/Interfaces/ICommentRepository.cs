﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using System;
    using System.Collections.Generic;

    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface ICommentRepository : IGenericRepository<Comment>
    {
        List<Comment> GetAllGroupComments(int groupId);

        List<Comment> GetAllGroupCommentsOnDate(int groupId, DateTime day);
    }
}