﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using System.Collections.Generic;

    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface IGroupRepository : IGenericRepository<Group>
    {
        List<Group> GetGroups();
    }
}