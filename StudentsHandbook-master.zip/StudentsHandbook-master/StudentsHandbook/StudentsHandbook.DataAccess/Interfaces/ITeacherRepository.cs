namespace StudentsHandbook.DataAccess.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface ITeacherRepository : IGenericRepository<Teacher>
    {
        List<Teacher> GetAllTeachers();

        List<Teacher> FindTeachersBySurname(string surname);

        Task<List<Teacher>> FindTeachersBySurnameAsync(string surname);

        List<Teacher> FindTeachersForSchedule(List<Lesson> schedule);
    }
}