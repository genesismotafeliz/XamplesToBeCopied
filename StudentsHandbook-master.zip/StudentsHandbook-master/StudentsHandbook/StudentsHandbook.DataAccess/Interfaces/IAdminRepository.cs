﻿
namespace StudentsHandbook.DataAccess.Interfaces
{
    using StudentsHandbook.DataAccess.Interfaces.Generic;
    using StudentsHandbook.Domain.Models;

    public interface IAdminRepository : IGenericRepository<Admin>
    {
    }
}