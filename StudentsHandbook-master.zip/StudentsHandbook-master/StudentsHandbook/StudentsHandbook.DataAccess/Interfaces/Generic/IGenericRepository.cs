﻿
namespace StudentsHandbook.DataAccess.Interfaces.Generic
{
    using System;
    using System.Threading.Tasks;

    public interface IGenericRepository<T> : IDisposable
        where T : class
    {
        T Get(int id); 

        void Create(T item); 

        void Update(T item); 

        void Delete(int id); 

        void Save();

        Task SaveAsync();
    }
}
