﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class CommentRepository : GenericRepository<Comment>, ICommentRepository
    {
        public CommentRepository(UserContext context)
            : base(context)
        {
        }

        public List<Comment> GetAllGroupComments(int groupId)
        {
            var allComments = this.GetQueryable();
            var groupComents = from comment in allComments
                               where comment.GroupId == groupId
                               select comment;
            return groupComents.ToList();
        }

        public List<Comment> GetAllGroupCommentsOnDate(int groupId, DateTime day)
        {
            var groupComments = this.GetAllGroupComments(groupId);
            var commentsOnDate = from comment in groupComments
                                 where comment.CreationTime == day
                                 select comment;
            return commentsOnDate.ToList();
        }
    }
}
