﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Extensions.Internal;

    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class TeacherRepository : GenericRepository<Teacher>, ITeacherRepository
    {
        public TeacherRepository(UserContext context)
            : base(context)
        {
        }

        public List<Teacher> GetAllTeachers() => this.GetQueryable().ToList();

        public List<Teacher> FindTeachersBySurname(string surname) => 
            this.GetQueryable()
                .Where(teacher => teacher.Surname.Contains(surname))
                .ToList();

        public async Task<List<Teacher>> FindTeachersBySurnameAsync(string surname) => 
            await this.DataContext.Teachers
            .Where(teacher => teacher.Surname == surname)
            .ToListAsync();
        
        public List<Teacher> FindTeachersForSchedule(List<Lesson> schedule)
        {
            var allTeachers = this.GetQueryable();
            return (from teacher in allTeachers
                    join lesson in schedule 
                    on teacher.Id equals lesson.TeacherId
                    where lesson.TeacherId == teacher.Id
                    select teacher)
                    .ToList();
        }
    }
}
