﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.EntityFrameworkCore;
    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class UserRepository : GenericRepository<User>, IUserRepository
    {
        public UserRepository(UserContext context)
            : base(context)
        {
        }

        public List<User> GetAllGroupMates(int groupId, int userId, int userCourse) => 
            this.GetQueryable()
            .Where(usr => usr.GroupId == groupId 
                && usr.Id != userId
                && usr.Course == userCourse)
            .ToList();

        public List<User> GetGroupMatesOnline(int groupId, int userId, int userCourse) =>
            this.GetQueryable()
            .Where(mate => mate.IsOnline 
                && mate.Id != userId 
                && mate.GroupId == groupId
                && mate.Course == userCourse)
            .ToList();


        public List<User> GetAllUsers() => 
            this.GetQueryable()
            .ToList();

        public User GetUserByEmail(string email) => 
            this.GetQueryable()
            .FirstOrDefault(usr => usr.Email == email);

        public async Task<User> GetUserAsync(string email) =>
            await this.GetQueryable().FirstOrDefaultAsync(usr => usr.Email == email);
    }
}
