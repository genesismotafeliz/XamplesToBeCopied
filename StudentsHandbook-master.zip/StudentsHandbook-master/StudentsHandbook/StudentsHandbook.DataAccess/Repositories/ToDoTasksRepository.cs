﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class ToDoTasksRepository : GenericRepository<ToDoTask>, IToDoTasksRepository
    {
        public ToDoTasksRepository(UserContext context)
            : base(context)
        {
        }

        public List<ToDoTask> GetAllUsersTasks(int userId) => 
            this.GetQueryable()
            .Where(task => task.CreatorId == userId)
            .ToList();

        public List<ToDoTask> GetTopThreeSoonExpiringTasks(int userId) => 
            this.GetAllUsersTasks(userId)
                .Where(task => (task.DateOfDeadline - DateTime.Now).TotalDays < 1)
                .OrderByDescending(t => t.DateOfDeadline)
                .Take(3)
                .ToList();

        public void CreateTask(ToDoTask task) // todo: implement proper creation if this one is incorrect;
        {
            this.Create(task);
        }

        public void CloseTask(int id)
        {
            var task = this.Get(id); // is this approach better vs. this.Delete(this.Get(id).Id) ?
            this.Delete(task.Id);
        }

        public void RenewTask(int id)
        {
            var task = this.Get(id);
            if (task != null )
            {
                this.Update(task);
            }
        }
    }
}
