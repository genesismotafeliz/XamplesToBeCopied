﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System.Collections.Generic;
    using System.Linq;

    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class GroupRepository : GenericRepository<Group>, IGroupRepository
    {
        public GroupRepository(UserContext context)
            : base(context)
        {
        }

        public List<Group> GetGroups() =>
            this.GetQueryable().ToList();
    }
}
