﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class AdminRepository : GenericRepository<Admin>, IAdminRepository
    {
        public AdminRepository(UserContext context)
            : base(context)
        {
        }
    }
}
