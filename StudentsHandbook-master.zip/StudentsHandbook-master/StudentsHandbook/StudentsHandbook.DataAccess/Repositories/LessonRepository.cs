﻿
namespace StudentsHandbook.DataAccess.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.DataAccess.Repositories.Generic;
    using StudentsHandbook.Domain.Models;

    public class LessonRepository : GenericRepository<Lesson>, ILessonRepository
    {
        public LessonRepository(UserContext context)
            : base(context)
        {
        }

        public List<Lesson> GetAllLessons() => 
            this.GetQueryable()
            .ToList();

        public List<Lesson> GetLessonsOfGroup(int groupId) =>
            this.GetQueryable()
            .Where(lesson => lesson.GroupId == groupId)
            .ToList();

        public List<Lesson> GetLessonsOfTeacherForPeriod(int teacherId, DateTime startOfPeriod, DateTime endOfPeriod) =>
            this.GetQueryable()
            .Where(lesson => lesson.TeacherId == teacherId 
            && lesson.StartTime.Date >= startOfPeriod.Date
            && lesson.EndTime.Date <= endOfPeriod.Date)
            .ToList();


        public List<Lesson> GetScheduleForDay(int groupId, DateTime day) =>
            this.GetQueryable()
                .Where(lesson => lesson.StartTime.Date == day.Date && lesson.GroupId == groupId)
                .ToList();

        public List<Lesson> GetLessonsOfGroupForPeriod(int groupId, DateTime startOfPeriod, DateTime endOfPeriod) =>
            this.GetQueryable()
                .Where(lesson => lesson.GroupId == groupId 
                    && lesson.StartTime.Date >= startOfPeriod.Date 
                    && lesson.EndTime.Date <= endOfPeriod.Date)
                .ToList();
    }
}
