﻿
namespace StudentsHandbook.DataAccess.Repositories.Generic
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.DataAccess.Interfaces.Generic;

    public abstract class GenericRepository<T> : IGenericRepository<T>
        where T : class
    {
        protected readonly UserContext DataContext;

        protected GenericRepository(UserContext context)
        {
            this.DataContext = context;
        }

        public T Get(int id)
        {
            return this.DataContext.Set<T>().Find(id);
        }

        public virtual void Create(T item)
        {
            this.DataContext.Set<T>().Add(item);
        }

        public virtual void Update(T item)
        {
            this.DataContext.Update(item);
        }

        public void Delete(int id)
        {
            var item = this.DataContext.Set<T>().Find(id);
            if (item != null)
            {
                this.DataContext.Set<T>().Remove(item);
            }
        }

        public void Save()
        {
            this.DataContext.SaveChanges();
        }

        public async Task SaveAsync()
        {
            await this.DataContext.SaveChangesAsync();
        }

        protected IQueryable<T> GetQueryable() =>
            this.DataContext.GetQueryable<T>();

        private bool isDisposed;

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.isDisposed)
            {
                if (disposing)
                {
                    this.DataContext.Dispose();
                }
            }

            this.isDisposed = true;
        }
    }
}
