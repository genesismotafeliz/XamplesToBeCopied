﻿
namespace StudentsHandbook.DataAccess.Context
{
    using System.Linq;

    using Microsoft.EntityFrameworkCore;

    using StudentsHandbook.Domain.Models;

    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Group> Groups { get; set; }

        public DbSet<Lesson> Schedules { get; set; }

        public DbSet<Comment> Comments { get; set; }

        public DbSet<Teacher> Teachers { get; set; }

        public DbSet<ToDoTask> ToDoTasks { get; set; }

        public DbSet<Admin> Admins { get; set; }

        public IQueryable<T> GetQueryable<T>() where T : class
        {
            return this.Set<T>().AsQueryable();
        }
    }
}
