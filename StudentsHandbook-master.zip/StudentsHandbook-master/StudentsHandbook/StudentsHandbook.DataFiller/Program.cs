﻿using System;

namespace StudentsHandbook.DataFiller
{
    using System.Collections.Generic;
    using System.Data.SqlTypes;
    using System.Linq;
    using System.Threading;

    using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Http;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Extensions.Internal;

    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.Domain.Models;

    public class Program
    {
        public static void Main(string[] args)
        {

            var dbOptions = 
                new DbContextOptionsBuilder()
                .UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=studentsdb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            var userContext = new UserContext(dbOptions.Options);
            var filler = new Filler(userContext);

            filler.ClearDatabase();
            Console.WriteLine("Flushing database...");
            filler.Context.SaveChanges();
            Thread.Sleep(1000);
            Console.WriteLine("Done!");
            


            for (var i = 0; i < 2; i++)
            {
                filler.CreateGroup();
            }

            filler.Context.SaveChanges();
           
            for (var i = 0; i < 4; i++)
            {
                filler.CreateTeacher();
            }

            filler.Context.SaveChanges();
          
            for (var i = 0; i < 50; i++)
            {
                filler.CreateLesson();
            }

            filler.Context.SaveChanges();
            
            for (var i = 0; i < 35; i++)
            {
                filler.CreateUser();
            }

            filler.Context.SaveChanges();

            for (var i = 0; i < 35 * 4; i++)
            {
                filler.CreateComment();
            }

            filler.Context.SaveChanges();
           
            for (var i = 0; i < 35 * 2; i++)
            {
                filler.CreateTask();
            }

            filler.Context.SaveChanges();

    
            Console.WriteLine("\n------------ GROUPS ------------");
            foreach (var item in filler.Context.GetQueryable<Group>().ToList())
            {
                Console.WriteLine($"{item.Name} {item.NameShortened} {item.Id}");
            }
            Console.WriteLine("\n------------ TEACHERS ------------");
            foreach (var item in filler.Context.GetQueryable<Teacher>().ToList())
            {
                Console.WriteLine($"{item.Name} {item.Surname} {item.Email} id ~ {item.Id} {item.Pulpit}");
            }
            Console.WriteLine("\n------------ LESSONS ------------");
            foreach (var item in filler.Context.GetQueryable<Lesson>().ToList())
            {
                Console.WriteLine(
                    $"{item.TeacherId} {item.LessonSubject} {item.StartTime} ~ {item.EndTime} {item.GroupId}");
            }
            Console.WriteLine("\n------------ USERS ------------");
            foreach (var item in filler.Context.GetQueryable<User>().ToList())
            {
                Console.WriteLine($"{item.FirstName} {item.LastName} grID {item.GroupId} ~ {item.Email} online? {item.IsOnline} [{item.Login} : {item.PasswordHash}]");
            }
            Console.WriteLine("\n------------ COMMENTS ------------");
            foreach (var item in filler.Context.GetQueryable<Comment>().ToList())
            {
                Console.WriteLine($"creator {item.CreatorId} group {item.GroupId} {item.CreationTime}");
            }
            Console.WriteLine("\n------------ TASKS ------------");
            foreach (var item in filler.Context.GetQueryable<ToDoTask>().ToList())
            {
                Console.WriteLine($"creator {item.CreatorId} start {item.DateOfCreation} expires at {item.DateOfDeadline}");
            }
            Console.WriteLine("------------ ALL DONE ------------\nPress any key to exit app...\n");
            Console.ReadKey();

            Console.WriteLine(3);
            Thread.Sleep(999);
            Console.WriteLine(2);
            Thread.Sleep(999);
            Console.WriteLine(1);
            Thread.Sleep(1200);
        }
    }
}
