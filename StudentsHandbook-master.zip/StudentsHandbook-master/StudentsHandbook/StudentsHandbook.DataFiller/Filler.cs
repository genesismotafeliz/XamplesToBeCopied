﻿
namespace StudentsHandbook.DataFiller
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using StudentsHandbook.DataAccess.Context;
    using StudentsHandbook.Domain.Models;

    public class Filler
    { 
        // TODO: Add this to configuration & clean up code;
        private static readonly List<string> MaleNames = File.ReadAllLines(@"Utils\MaleNames.txt").ToList();
        private static readonly List<string> FemaleNames = File.ReadAllLines(@"Utils\FemaleNames.txt").ToList();
        private static readonly List<string> Surnames = File.ReadAllLines(@"Utils\Surnames.txt").ToList();
        private static readonly List<string> TextLessons = File.ReadAllLines(@"Utils\Lessons.txt").ToList();
        private static readonly List<string> GroupNames = File.ReadAllLines(@"Utils\Groups.txt").ToList();
        private static readonly List<string> GroupNamesShort = File.ReadAllLines(@"Utils\GroupsShort.txt").ToList();

        private static readonly Random Rng = new Random();

        public Filler(UserContext context)
        {
            this.Context = context;
        }

        public UserContext Context { get; }

        public void CreateGroup()
        {
            var group = new Group();
            var num = Rng.Next(0, GroupNames.Count);
            group.Name = GroupNames[num];
            group.NameShortened = GroupNamesShort[num];
            GroupNames.Remove(group.Name);
            GroupNamesShort.Remove(group.Name);
            this.Context.Groups.Add(group);
        }


        public void CreateTeacher()
        {
            var teacher = new Teacher();
            if (Rng.Next(0, 11) % 2 == 0)
            {
                teacher.Name = MaleNames[Rng.Next(0, MaleNames.Count)];
                teacher.LastName = MaleNames[Rng.Next(0, MaleNames.Count)];
            }
            else
            {
                teacher.Name = FemaleNames[Rng.Next(0, FemaleNames.Count)];
                teacher.LastName = FemaleNames[Rng.Next(0, FemaleNames.Count)];
            }

            teacher.Surname = Surnames[Rng.Next(0, Surnames.Count)];
            teacher.AdditionalInfo = GetRandomString(35);
            teacher.Degree = GetRandomString(5);
            teacher.Email = $"{teacher.Surname}_{teacher.Name.ToCharArray()[0]}@somemail.com".ToLower();
            teacher.Phone = $"+78{Rng.Next(900, 995)}{Rng.Next(1000000, 9999999)}";
            teacher.Pulpit = GroupNamesShort[Rng.Next(0, GroupNamesShort.Count)];

            this.Context.Teachers.Add(teacher);
        }

        public void CreateLesson()
        {
            var lesson = new Lesson();
            var groups = this.Context.GetQueryable<Group>().ToList();
            lesson.GroupId = groups[Rng.Next(0, groups.Count)].Id;
            lesson.StartTime = new DateTime(
                2018,
                Rng.Next(1, 6),
                Rng.Next(1, 28),
                Rng.Next(9, 19),
                Rng.Next(0, 60),
                Rng.Next(0, 60));
            lesson.EndTime = lesson.StartTime.AddHours(1.5);
            lesson.LessonSubject = TextLessons[Rng.Next(0, TextLessons.Count)];
            var teachers = this.Context.GetQueryable<Teacher>().ToList();
            lesson.TeacherId = teachers[Rng.Next(0, teachers.Count)].Id;
            lesson.DeptBuilding = teachers.Find(t => t.Id == lesson.TeacherId).Pulpit;
            lesson.RoomNumber = Rng.Next(15, 350);
            this.Context.Schedules.Add(lesson);
        }
        

        public void CreateUser()
        {
            var user = new User();
            if (Rng.Next(0, 10) % 2 == 0)
            {
                user.FirstName = MaleNames[Rng.Next(0, MaleNames.Count)];
                user.LastName = Surnames[Rng.Next(0, Surnames.Count)];
            }
            else
            {
                user.FirstName = FemaleNames[Rng.Next(0, FemaleNames.Count)];
                user.LastName = Surnames[Rng.Next(0, Surnames.Count)];
            }

            user.Email = $"{user.LastName}_{user.FirstName.ToCharArray()[0]}@somemail.com".ToLower();
            user.Course = Rng.Next(1, 5);

            var groups = this.Context.GetQueryable<Group>().ToList();
            user.GroupId = groups[Rng.Next(1, groups.Count)].Id;
            user.IsOnline = Rng.Next(0, 25) % 2 == 0;
            user.Phone = $"+78{Rng.Next(900, 995)}{Rng.Next(1000000, 9999999)}";
            user.Login = $"{user.LastName}";
            user.PasswordHash = $"{user.LastName}123";
            this.Context.Users.Add(user);
        }
        
        public void CreateComment()
        {
            var comment = new Comment();
            var users = this.Context.GetQueryable<User>().ToList();
            var creator = users[Rng.Next(0, users.Count)];
            if (creator == null)
            {
                throw new Exception("no such user");
            }

            comment.CreatorId = creator.Id;
            comment.GroupId = creator.GroupId;
            comment.CreationTime = new DateTime(
                Rng.Next(2017, 2018),
                Rng.Next(1, 12),
                Rng.Next(1, 28),
                Rng.Next(0, 24),
                Rng.Next(0, 60),
                Rng.Next(0, 60));
            comment.Text = GetRandomString(Rng.Next(10, 100));
            this.Context.Comments.Add(comment);
        }

        public void CreateTask()
        {
            var task = new ToDoTask();
            task.DateOfCreation = new DateTime(
                2018,
                Rng.Next(1, 6),
                Rng.Next(1, 28),
                Rng.Next(9, 19),
                Rng.Next(0, 60),
                Rng.Next(0, 60));
            task.DateOfDeadline = task.DateOfCreation.AddDays(Rng.Next(1, 120));
            task.TaskTitle = $"TODO{GetRandomString(15)}";
            var users = this.Context.GetQueryable<User>().ToList();
            task.CreatorId = users[Rng.Next(0, users.Count)].Id;
            task.Text = GetRandomString(Rng.Next(25, 65));
            this.Context.ToDoTasks.Add(task);
        }

        public void ClearDatabase()
        {
            foreach (var item in this.Context.Groups)
            {
                this.Context.Groups.Remove(item);
            }
            foreach (var item in this.Context.Comments)
            {
                this.Context.Comments.Remove(item);
            }
            foreach (var item in this.Context.Schedules)
            {
                this.Context.Schedules.Remove(item);
            }
            foreach (var item in this.Context.Teachers)
            {
                this.Context.Teachers.Remove(item);
            }
            foreach (var item in this.Context.ToDoTasks)
            {
                this.Context.ToDoTasks.Remove(item);
            }
            foreach (var item in this.Context.Users)
            {
                this.Context.Users.Remove(item);
            }
        }

        private static string GetRandomString(int size)
        {
            var builder = new StringBuilder();
            for (var i = 0; i < size; i++)
            {
                var ch = Convert.ToChar(Convert.ToInt32(Math.Floor((26 * Rng.NextDouble()) + 65)));
                builder.Append(ch);
            }

            return builder.ToString();
        }
    }
}
