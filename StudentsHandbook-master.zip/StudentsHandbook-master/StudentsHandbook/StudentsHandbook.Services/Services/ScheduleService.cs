﻿
namespace StudentsHandbook.Services.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using StudentsHandbook.DataAccess.Interfaces;
    using StudentsHandbook.Domain.Models;

    public class ScheduleService
    {
        private readonly ILessonRepository lessonRepository;

        public ScheduleService(ILessonRepository lessonRepo)
        {
            this.lessonRepository = lessonRepo;
        }

        public List<List<Lesson>> GetCurrentWeekLessonsOfGroup(int groupId, DateTime dayOfWeek)
        {
            var currentWeek = this.GetCurrentWeek(dayOfWeek);

            var groupSchedule = this.lessonRepository
                .GetLessonsOfGroupForPeriod(
                    groupId,
                    currentWeek.First().Date,
                    currentWeek.Last().Date);

            return this.GetCurrentWeekLessons(groupSchedule, dayOfWeek);
        }

        public List<List<Lesson>> GetCurrentWeekLessonsOfTeacher(int teacherId, DateTime dayOfWeek)
        {
            var currentWeek = this.GetCurrentWeek(dayOfWeek);

            var teacherSchedule = this.lessonRepository
                .GetLessonsOfTeacherForPeriod(
                    teacherId,
                    currentWeek.First().Date,
                    currentWeek.Last().Date);

            return this.GetCurrentWeekLessons(teacherSchedule, dayOfWeek);
        }

        private List<List<Lesson>> GetCurrentWeekLessons(List<Lesson> schedule, DateTime dayOfWeek)
        {
            var currentWeek = this.GetCurrentWeek(dayOfWeek);

            var currentWeekLessons = new List<List<Lesson>>();
            foreach (var day in currentWeek)
            {
                var lessonSet = schedule.Where(lesson => lesson.StartTime.Date == day.Date);
                currentWeekLessons.Add(lessonSet.ToList());
            }

            return currentWeekLessons;
        }

        private List<DateTime> GetCurrentWeek(DateTime dayOfWeek)
        {
            var today = dayOfWeek.Date;
            var currentDayOfWeek = (int)today.DayOfWeek;
            var sunday = today.AddDays(-currentDayOfWeek);
            var monday = sunday.AddDays(1);
            if (currentDayOfWeek == 0)
            {
                monday = monday.AddDays(-7);
            }

            var currentWeek = Enumerable
                .Range(0, 7)
                .Select(days => monday.AddDays(days))
                .ToList();

            return currentWeek;
        }
    }
}
