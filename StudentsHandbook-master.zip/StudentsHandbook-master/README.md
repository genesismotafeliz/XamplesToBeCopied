﻿# About

❗ **Work is still in progress!**

Students-Handbook is a Social-network/Digest app, on ASP .NET Core 2.0. 
That's abviously mean that it is cross-platform and may be hosted at any OS .NET Core supports.

The idea was to create an application, that *(in theory)* would be useful for students in everyday study life.
***
# Gettings started
 * First, take a look at **DataFiller**. It generates data about users, teachers, schedules etc. into Database.
 Entities can be created in any quantity *( Except 'Groups'. Those can't be more than 8 or there will be duplicates)*.
 Make is as a startup, modify your path to db and run. After filling database, console will output all the info about what app did. Output can be modified.
 * After that, make the main app a startup again (dont forget to modify db path) run it, and try to login/register a new user. 
* ???
* PROFIT!
 
***
# Implemented features:
* Login / Registration w/ cookies;
* User pages;
* Group / Schedule pages;
* Teacher pages w/ their schedules & search option;

# Soon implemented features:
* Password hashing;
* User settings & photo displaying;
* Admin panel & features (e.g. getting data from json, xls etc.);
* Advanced email validation & password recovery via email;
* Group and private chats *(using signalR)*;
* A slightly better UI;