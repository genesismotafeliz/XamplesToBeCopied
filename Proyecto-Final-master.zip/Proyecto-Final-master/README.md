# Proyecto-Final
proyecto que calcula el promedio ponderado de los estudiantes de la universidad O&amp;M, de la materia de programacion estructurada, seccion: 463, integrante: Kasandra Diaz, matricula: 17-SIIN-1-040
