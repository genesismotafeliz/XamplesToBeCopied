# Social-networking-service
This is prototype of social networking service. Database - MS SQL. User can only log in/log out, watch his friends and information about it.
Redis is used as cache. Search engine - Sphinx.
