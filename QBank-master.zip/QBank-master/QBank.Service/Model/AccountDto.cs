namespace QBank.Service.Model
{
    public class AccountDto
    {
        public double Balance { get; set; }
        public string AccountHolder { get; set; }
        public string AccountType { get; set; }
    }
}