using Microsoft.Practices.Prism.Events;

namespace QBank.BasicAccountModule
{
    public class AccountBalanceChangedEvent:CompositePresentationEvent<double>
    {
        
    }
}