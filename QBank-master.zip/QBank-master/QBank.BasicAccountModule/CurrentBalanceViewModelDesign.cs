namespace QBank.BasicAccountModule
{
    //TODO: Use this model for design time support, or use Design Time Data. 
    public class CurrentBalanceViewModelDesign: CurrentBalanceViewModel
    {
        public CurrentBalanceViewModelDesign()
        {
            Balance = 785.50;
        }
    }
}