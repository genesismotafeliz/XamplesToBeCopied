namespace QBank.Infrastructure.Web.WCF
{
    /// <summary>
    /// 
    /// </summary>
    public enum PreferredBinding
    {
        NoPreference,
        NetTcp,
        Http,
    }
}