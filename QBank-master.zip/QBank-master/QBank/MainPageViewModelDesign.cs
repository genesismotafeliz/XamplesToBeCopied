namespace QBank
{
    public class MainPageViewModelDesign : MainPageViewModel
    {
        public MainPageViewModelDesign()
        {
            ApplicationName = "QBank";
        }
    }
}