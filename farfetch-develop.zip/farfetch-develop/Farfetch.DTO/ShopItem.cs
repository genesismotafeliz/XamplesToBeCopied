﻿namespace Farfetch.DTO
{
	public class ShopItem
	{
		public Item LeftItem { get; set; }
		public Item RightItem { get; set; }
	}
}
