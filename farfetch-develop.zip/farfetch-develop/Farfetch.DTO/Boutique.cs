﻿namespace Farfetch.DTO
{
	public class Boutique
	{
		public int Id { get; set; }
		public string ImageUri { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }
		public string Description { get; set; }
	}
}
