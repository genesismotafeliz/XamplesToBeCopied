﻿using System;
namespace Farfetch.DTO
{
	public class BoutiqueItem
	{
	    public int Id { get; set; }	
		public string ImageUri { get; set; }
		public string Name { get; set; }
		public string ShortAddress { get; set; }
	}
}
