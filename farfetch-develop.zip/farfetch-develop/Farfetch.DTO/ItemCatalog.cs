﻿namespace Farfetch.DTO
{
	public class ItemCatalog
	{
		public string ImageUri { get; set; }
		public string Name { get; set; }
		public decimal Price { get; set; }
	}
}
