﻿namespace Farfetch
{
	public class Offer
	{
		public string Title { get; set; }
		public string ImageUri { get; set; }
		public string Category { get; set; }
	}
}
