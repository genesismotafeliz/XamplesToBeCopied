﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class ShopTabPage : ContentPage
	{
		public ShopTabPage()
		{
			InitializeComponent();
		}
	}
}

