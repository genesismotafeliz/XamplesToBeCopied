﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class HomeTabPage : ContentPage
	{
		public HomeTabPage()
		{
			InitializeComponent();
		}
	}
}

