﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class BoutiqueTabPage : ContentPage
	{
		public BoutiqueTabPage()
		{
			InitializeComponent();
		}
	}
}

