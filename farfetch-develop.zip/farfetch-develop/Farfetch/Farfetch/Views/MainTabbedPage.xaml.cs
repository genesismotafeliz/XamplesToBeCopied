﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class MainTabbedPage : TabbedPage
	{
		public MainTabbedPage()
		{
			InitializeComponent();
		}
	}
}

