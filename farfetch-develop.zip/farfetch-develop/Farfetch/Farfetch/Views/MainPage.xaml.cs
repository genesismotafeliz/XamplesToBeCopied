﻿using Xamarin.Forms;

namespace Farfetch.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
