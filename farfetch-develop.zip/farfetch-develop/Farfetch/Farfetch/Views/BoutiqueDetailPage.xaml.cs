﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class BoutiqueDetailPage : ContentPage
	{
		public BoutiqueDetailPage()
		{
			InitializeComponent();
		}
	}
}

