﻿using Xamarin.Forms;

namespace Farfetch.Views
{
	public partial class ItemDetailPage : ContentPage
	{
		public ItemDetailPage()
		{
			InitializeComponent();
		}
	}
}

