﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Farfetch
{
	public partial class DefaultMiniCatalogViewCell : ViewCell
	{
		public DefaultMiniCatalogViewCell()
		{
			InitializeComponent();
		}
	}
}
