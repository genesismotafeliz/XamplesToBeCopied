﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Farfetch
{
	public partial class ItemCatalogView : ContentView
	{
		public ItemCatalogView()
		{
			InitializeComponent();
		}
	}
}
