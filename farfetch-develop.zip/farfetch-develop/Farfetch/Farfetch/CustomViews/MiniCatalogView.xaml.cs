﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Farfetch
{
	public partial class MiniCatalogView : ContentView
	{
		public MiniCatalogView()
		{
			InitializeComponent();
		}

	}
}
