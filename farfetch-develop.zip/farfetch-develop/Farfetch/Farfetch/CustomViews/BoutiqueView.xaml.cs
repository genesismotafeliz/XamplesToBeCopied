﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Farfetch
{
	public partial class BoutiqueView : ContentView
	{
		public BoutiqueView()
		{
			InitializeComponent();
		}
	}
}
