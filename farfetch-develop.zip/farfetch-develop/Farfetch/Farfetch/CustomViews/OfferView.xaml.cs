﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Farfetch
{
	public partial class OfferView : ContentView
	{
		public OfferView()
		{
			InitializeComponent();
		}
	}
}
