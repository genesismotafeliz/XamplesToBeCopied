﻿namespace SocialNetwork.Core
{
    public enum CommandType
    {
        Post,
        Follow,
        Timeline,
        Wall
    }
}
