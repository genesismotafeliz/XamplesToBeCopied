﻿using System.Reflection;

[assembly: AssemblyTitle("SocialNetwork")]
[assembly: AssemblyProduct("SocialNetwork")]
[assembly: AssemblyVersion("1.0.0.0")]
