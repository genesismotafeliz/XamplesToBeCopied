﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocialNet.ViewModels.Users
{
    public class SubscriptionViewModel
    {
        public string PublisherId { get; set; }

        public string SubscriberId { get; set; }
    }
}
