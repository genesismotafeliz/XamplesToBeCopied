module GalleriesHelper
end
