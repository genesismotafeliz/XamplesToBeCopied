﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MvvmCross.Plugins.Fingerprint.iOS")]
[assembly: AssemblyDescription("Authenticate a user via fingerprint from a cross platform API.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("MvvmCross.Plugins.Fingerprint.iOS")]
[assembly: AssemblyCopyright("Copyright 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.4.6")]
[assembly: AssemblyInformationalVersion("1.4.6")]
[assembly: AssemblyFileVersion("1.4.6")]
