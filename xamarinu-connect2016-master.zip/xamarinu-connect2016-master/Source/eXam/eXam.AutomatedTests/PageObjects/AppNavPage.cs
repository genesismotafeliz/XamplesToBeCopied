using System;
using System.Linq;
using Xamarin.UITest;

namespace eXam.AutomatedTests
{
	public enum AppNavPage
	{
		Home,
		Question,
		Review
	}
}
