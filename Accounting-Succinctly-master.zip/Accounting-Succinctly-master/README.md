# Accounting Succinctly
This is the companion repo for [*Accounting Succinctly*](https://www.syncfusion.com/ebooks/accounting) by Joe Booth. Published by Syncfusion.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/Accounting-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/accounting)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).
