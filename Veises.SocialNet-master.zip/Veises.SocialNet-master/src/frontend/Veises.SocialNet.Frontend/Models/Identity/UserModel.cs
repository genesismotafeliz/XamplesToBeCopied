﻿namespace Veises.SocialNet.Frontend.Models.Identity
{
	public sealed class UserModel
	{
		public string DisplauName { get; set; }
	}
}