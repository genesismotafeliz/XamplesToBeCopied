﻿namespace Veises.SocialNet.Frontend.Services
{
	public interface ISessionProvider
	{
		UserSession GetSession();
	}
}