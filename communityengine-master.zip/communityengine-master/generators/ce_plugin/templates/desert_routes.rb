# Plugin routes go here
# app this to your app's routes file to make these routes active:
# map.from_plugin :community_engine_<%= file_name %>
