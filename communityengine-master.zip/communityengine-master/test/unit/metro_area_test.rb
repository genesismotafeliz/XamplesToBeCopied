require 'test_helper'

class MetroAreaTest < ActiveSupport::TestCase
  fixtures :metro_areas

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
