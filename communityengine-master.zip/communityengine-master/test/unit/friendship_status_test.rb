require 'test_helper'

class FriendshipStatusTest < ActiveSupport::TestCase
  fixtures :friendship_statuses

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
