require 'test_helper'

class HomepageFeatureTest < ActiveSupport::TestCase
  fixtures :homepage_features

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
