Dummy::Application.routes.draw do
  mount CommunityEngine::Engine => "/"
end
