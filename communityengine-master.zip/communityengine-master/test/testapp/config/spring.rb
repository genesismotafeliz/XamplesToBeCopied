Spring.application_root = ''
