# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = 'd3602686e46c4552c3da68af512580e4c99a1b0de01de0e8e5463247f1574d901036a03f71c499452492f20f85688243c21a9d5433d2027014c4c9b2dbea2041'
Dummy::Application.config.secret_key_base = 'd3602686e46c4552c3da68af512580e4c99a1b0de01de0e8e5463247f1574d901036a03f71c499452492f20f85688243c21a9d5433d2027014c4c9b2dbea2041'
