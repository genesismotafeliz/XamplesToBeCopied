require 'acts_as_publishable/acts_as_publishable'
ActiveRecord::Base.send(:include, Acts::As::Publishable)

