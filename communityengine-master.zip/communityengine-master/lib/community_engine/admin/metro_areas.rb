ActiveAdmin.register MetroArea do
  permit_params :name, :state, :country_id, :state_id
end

