/// <reference path="globals/angular/index.d.ts" />
/// <reference path="modules/debug/index.d.ts" />
