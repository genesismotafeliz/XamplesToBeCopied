require('./dialogs-app/app.module');
require('./static/css/messages.scss');