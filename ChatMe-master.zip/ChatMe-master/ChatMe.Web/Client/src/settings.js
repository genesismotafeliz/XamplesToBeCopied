require('./static/js/push-messages');
require('./static/js/settings');