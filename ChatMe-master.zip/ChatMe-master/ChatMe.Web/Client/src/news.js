require('./static/js/push-messages');
require('./posts-app/app.module.js');
