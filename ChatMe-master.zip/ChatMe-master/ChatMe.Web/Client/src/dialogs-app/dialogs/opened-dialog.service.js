/* @ngInject */
export default function openedDialogService() {
    this.id = null;
}