﻿namespace ChatMe.Web.Areas.Admin.Models
{
    public class NewUserViewModel : UserViewModel
    {
        public string Password { get; set; }
    }
}