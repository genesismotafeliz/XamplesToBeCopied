﻿namespace ChatMe.BussinessLogic.DTO
{
    public class RegistrationInfoDTO
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string Password { get; set; }
    }
}