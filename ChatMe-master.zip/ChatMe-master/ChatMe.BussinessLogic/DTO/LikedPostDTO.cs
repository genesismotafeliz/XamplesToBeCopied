﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatMe.BussinessLogic.DTO
{
    public class LikedPostDTO
    {
        public int PostId { get; set; }
        public string UserId { get; set; }
    }
}
