﻿namespace SocialNetwork.AccountService.Logout
{
    public interface ILogoutService
    {
        void Logout();
    }
}