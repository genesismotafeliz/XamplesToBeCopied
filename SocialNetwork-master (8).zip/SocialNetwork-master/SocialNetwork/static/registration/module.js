var RegistrationModule = angular.module('RegistrationModule', []);
