﻿namespace SocialNetwork.Logging
{
    public enum EventSeverity
    {
        Info,
        Debug,
        Warning,
        Error,
        Fatal
    }
}