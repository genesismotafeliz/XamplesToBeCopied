﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SocialNetwork.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
