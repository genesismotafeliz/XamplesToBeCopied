﻿$(document).ready(function () {
    
    // fades out the generic message after 3 seconds
    setTimeout(function () {
        $('#genericmessage').fadeOut('fast');
    }, 3000);
});