﻿The folder "~/Files" is required for the File Manager to function.

Please do not remove this folder from your website. 

Thanks,
The DigiOz Multimedia Development Team