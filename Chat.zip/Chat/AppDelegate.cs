﻿using Foundation;
using UIKit;

namespace Chat
{
	[Register ("AppDelegate")]
	public class AppDelegate : UIApplicationDelegate
	{
		public override UIWindow Window { get; set; }
	}
}