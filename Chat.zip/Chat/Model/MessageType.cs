﻿namespace Chat
{
	public enum MessageType
	{
		Incoming,
		Outgoing,
	}
}

