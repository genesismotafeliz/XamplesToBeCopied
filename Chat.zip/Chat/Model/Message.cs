﻿namespace Chat
{
	public class Message
	{
		public MessageType Type { get; set; }
		public string Text { get; set; }
	}
}

