<?php

$attributemap = array(
    'mobile' => 'urn:mace:dir:attribute-def:mobile'
);
