﻿namespace SocialNetwork.ConsoleApplication.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}