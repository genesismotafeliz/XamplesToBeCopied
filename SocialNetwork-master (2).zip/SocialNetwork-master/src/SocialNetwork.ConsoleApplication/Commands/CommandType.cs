﻿namespace SocialNetwork.ConsoleApplication
{
    public enum CommandType
    {
        Post,

        Read,

        Follow,

        Wall
    }
}