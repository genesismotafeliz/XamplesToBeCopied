﻿namespace Crosschat.Server.Application.Contracts
{
    public interface IInfrastructureInitializator
    {
        void Init();
    }
}
