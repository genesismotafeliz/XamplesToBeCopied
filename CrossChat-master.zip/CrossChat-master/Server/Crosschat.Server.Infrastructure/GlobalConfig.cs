﻿namespace Crosschat.Server.Infrastructure
{
    public static class GlobalConfig
    {
        public const string IpAddress = "ABOT.cloudapp.net"; //"23.97.209.133"
        public const int Port = 3452;
    }
}
