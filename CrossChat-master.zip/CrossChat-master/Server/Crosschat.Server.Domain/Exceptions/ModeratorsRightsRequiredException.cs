﻿using System;

namespace Crosschat.Server.Domain.Exceptions
{
    public class ModeratorsRightsRequiredException : Exception
    {
    }
}
