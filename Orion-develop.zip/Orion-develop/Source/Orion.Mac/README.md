﻿Orion for macOS
----

## Requirements

* macOS Sierra 10.12
* Visual Studio for Mac Preview (7.0)
