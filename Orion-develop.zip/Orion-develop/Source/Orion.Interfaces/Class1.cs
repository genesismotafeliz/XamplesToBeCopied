﻿using System;

namespace Orion.Interfaces
{
    public class Class1
    {
    }
}
