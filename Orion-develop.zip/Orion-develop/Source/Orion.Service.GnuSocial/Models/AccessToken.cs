﻿namespace Orion.Service.GnuSocial.Models
{
    public class AccessToken
    {
        public string OAuthToken { get; set; }

        public string OAuthTokenSecret { get; set; }
    }
}