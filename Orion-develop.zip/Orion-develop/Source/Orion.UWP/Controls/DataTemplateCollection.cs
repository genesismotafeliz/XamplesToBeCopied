﻿using System.Collections.Generic;

using Windows.UI.Xaml;

namespace Orion.UWP.Controls
{
    public class DataTemplateCollection : List<DataTemplate> { }
}