﻿using Orion.UWP.Mvvm;

namespace Orion.UWP.ViewModels.Timelines
{
    internal class UserTimelineViewModel : ViewModel { }
}