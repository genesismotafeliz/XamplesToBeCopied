﻿using Windows.UI.Xaml.Controls;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Orion.UWP.Views.Timelines
{
    public sealed partial class StatusesTimeline : UserControl
    {
        public StatusesTimeline()
        {
            InitializeComponent();
        }
    }
}