﻿namespace Orion.Service.Mastodon.Enum
{
    public enum NotificationType
    {
        Mention,

        Reblog,

        Favourite,

        Follow
    }
}