﻿namespace Orion.Service.Mastodon.Enum
{
    public enum AttachmentType
    {
        Image,

        Video,

        Gifv,

        Unknown
    }
}