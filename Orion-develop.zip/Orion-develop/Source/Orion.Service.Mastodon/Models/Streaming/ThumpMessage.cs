﻿namespace Orion.Service.Mastodon.Models.Streaming
{
    public class ThumpMessage : MessageBase { }
}