﻿namespace Orion.Scripting
{
    public abstract class FilterSourceBase
    {
        public abstract string Key { get; }
    }
}