﻿namespace Orion.Shared.Emoji
{
    public class Emoji
    {
        public string Shortname { get; set; }
        public string Unicode { get; set; }
    }
}