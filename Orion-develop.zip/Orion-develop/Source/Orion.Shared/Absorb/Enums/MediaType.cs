﻿namespace Orion.Shared.Absorb.Enums
{
    public enum MediaType
    {
        Image,

        Video
    }
}