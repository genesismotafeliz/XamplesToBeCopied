﻿namespace Orion.Shared.Absorb.Enums
{
    public enum EventType
    {
        Delete,

        Favorite,

        Follow,

        Reblog
    }
}