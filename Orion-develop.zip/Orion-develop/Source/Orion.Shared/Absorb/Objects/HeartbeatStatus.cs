﻿namespace Orion.Shared.Absorb.Objects
{
    public class HeartbeatStatus : StatusBase
    {
        public HeartbeatStatus()
        {
            IsBroadcastStatus = true;
        }
    }
}