Orion
----
[![GitHub license](https://img.shields.io/github/license/fuyuno/Orion.svg?style=flat-square)](LICENSE)
![Build status](https://build.mobile.azure.com/v0.1/apps/bfcc272e-51fa-492f-8e5d-f95057107b68/branches/develop/badge)

Generic microblogging and social networking services application for Windows and macOS.  
Supported services are:  

* Twitter
* Croudia
* GNU social instances (Original API only)
* Mastodon instances (Original API only)


### Screenshot

#### Orion for Windows
<img alt="default" src="https://user-images.githubusercontent.com/10832834/27251532-ddedb384-5383-11e7-8a3c-7e12d9cc5c31.PNG">


### Donate
* Donate via Bitcoin: `1NFcYczriqTEzVgzfurTMJNbhxPY1vyki9`
