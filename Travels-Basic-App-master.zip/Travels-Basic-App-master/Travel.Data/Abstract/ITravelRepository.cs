﻿

namespace Travel.Data.Abstract
{
    public interface ITravelRepository : IRepository<Travel.Models.Registration.Travel>
    {

    }
}
