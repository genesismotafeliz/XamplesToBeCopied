namespace SeminarsHub.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class AddForiegnKeysInSeminarModel : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Seminars", name: "Speaker_Id", newName: "SpeakerId");
            RenameColumn(table: "dbo.Seminars", name: "Type_Id", newName: "TypeId");
            RenameIndex(table: "dbo.Seminars", name: "IX_Speaker_Id", newName: "IX_SpeakerId");
            RenameIndex(table: "dbo.Seminars", name: "IX_Type_Id", newName: "IX_TypeId");
        }

        public override void Down()
        {
            RenameIndex(table: "dbo.Seminars", name: "IX_TypeId", newName: "IX_Type_Id");
            RenameIndex(table: "dbo.Seminars", name: "IX_SpeakerId", newName: "IX_Speaker_Id");
            RenameColumn(table: "dbo.Seminars", name: "TypeId", newName: "Type_Id");
            RenameColumn(table: "dbo.Seminars", name: "SpeakerId", newName: "Speaker_Id");
        }
    }
}
