namespace SeminarsHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CorrectTheSpellingOfOriginalInNotificationModel : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Notifications", "Type", c => c.Int(nullable: false));
            AddColumn("dbo.Notifications", "OriginalDateTime", c => c.DateTime());
            AddColumn("dbo.Notifications", "OriginalVenue", c => c.String());
            DropColumn("dbo.Notifications", "NotificationType");
            DropColumn("dbo.Notifications", "OrginalDateTime");
            DropColumn("dbo.Notifications", "OrginalVenue");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Notifications", "OrginalVenue", c => c.String());
            AddColumn("dbo.Notifications", "OrginalDateTime", c => c.DateTime());
            AddColumn("dbo.Notifications", "NotificationType", c => c.Int(nullable: false));
            DropColumn("dbo.Notifications", "OriginalVenue");
            DropColumn("dbo.Notifications", "OriginalDateTime");
            DropColumn("dbo.Notifications", "Type");
        }
    }
}
