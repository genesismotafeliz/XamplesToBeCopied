namespace SeminarsHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddIsCanceledPropertyInSeminarModel : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Seminars", "IsCanceled", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Seminars", "IsCanceled");
        }
    }
}
