namespace SeminarsHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateSeminarSeminarTypeTables : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Seminars",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Venue = c.String(),
                        DateTime = c.DateTime(nullable: false),
                        Speaker_Id = c.String(maxLength: 128),
                        Type_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.Speaker_Id)
                .ForeignKey("dbo.SeminarTypes", t => t.Type_Id)
                .Index(t => t.Speaker_Id)
                .Index(t => t.Type_Id);
            
            CreateTable(
                "dbo.SeminarTypes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Type = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Seminars", "Type_Id", "dbo.SeminarTypes");
            DropForeignKey("dbo.Seminars", "Speaker_Id", "dbo.AspNetUsers");
            DropIndex("dbo.Seminars", new[] { "Type_Id" });
            DropIndex("dbo.Seminars", new[] { "Speaker_Id" });
            DropTable("dbo.SeminarTypes");
            DropTable("dbo.Seminars");
        }
    }
}
