namespace SeminarsHub.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class PopulateSeminarTypeTable : DbMigration
    {
        public override void Up()
        {
            Sql("INSERT INTO SeminarTypes(Type) VALUES ('General')");
            Sql("INSERT INTO SeminarTypes(Type) VALUES ('Educational')");
            Sql("INSERT INTO SeminarTypes(Type) VALUES ('Motivational')");
            Sql("INSERT INTO SeminarTypes(Type) VALUES ('Religious')");
        }
        
        public override void Down()
        {
            Sql("DELETE FROM SeminarTypes WHERE id IN (1,2,3,4)");
        }
    }
}
