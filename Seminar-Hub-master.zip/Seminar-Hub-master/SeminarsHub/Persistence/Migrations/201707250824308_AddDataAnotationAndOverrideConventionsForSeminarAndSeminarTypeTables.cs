namespace SeminarsHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddDataAnotationAndOverrideConventionsForSeminarAndSeminarTypeTables : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Seminars", "Speaker_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Seminars", "Type_Id", "dbo.SeminarTypes");
            DropIndex("dbo.Seminars", new[] { "Speaker_Id" });
            DropIndex("dbo.Seminars", new[] { "Type_Id" });
            AlterColumn("dbo.Seminars", "Venue", c => c.String(nullable: false, maxLength: 355));
            AlterColumn("dbo.Seminars", "Speaker_Id", c => c.String(nullable: false, maxLength: 128));
            AlterColumn("dbo.Seminars", "Type_Id", c => c.Int(nullable: false));
            AlterColumn("dbo.SeminarTypes", "Type", c => c.String(nullable: false, maxLength: 255));
            CreateIndex("dbo.Seminars", "Speaker_Id");
            CreateIndex("dbo.Seminars", "Type_Id");
            AddForeignKey("dbo.Seminars", "Speaker_Id", "dbo.AspNetUsers", "Id", cascadeDelete: true);
            AddForeignKey("dbo.Seminars", "Type_Id", "dbo.SeminarTypes", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Seminars", "Type_Id", "dbo.SeminarTypes");
            DropForeignKey("dbo.Seminars", "Speaker_Id", "dbo.AspNetUsers");
            DropIndex("dbo.Seminars", new[] { "Type_Id" });
            DropIndex("dbo.Seminars", new[] { "Speaker_Id" });
            AlterColumn("dbo.SeminarTypes", "Type", c => c.String());
            AlterColumn("dbo.Seminars", "Type_Id", c => c.Int());
            AlterColumn("dbo.Seminars", "Speaker_Id", c => c.String(maxLength: 128));
            AlterColumn("dbo.Seminars", "Venue", c => c.String());
            CreateIndex("dbo.Seminars", "Type_Id");
            CreateIndex("dbo.Seminars", "Speaker_Id");
            AddForeignKey("dbo.Seminars", "Type_Id", "dbo.SeminarTypes", "Id");
            AddForeignKey("dbo.Seminars", "Speaker_Id", "dbo.AspNetUsers", "Id");
        }
    }
}
