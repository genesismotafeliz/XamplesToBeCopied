namespace SeminarsHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddAttendanceModelAndAlsoReNameTypeToTypeNameInSeminarTypeClass : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Attendances",
                c => new
                    {
                        SeminarId = c.Int(nullable: false),
                        AttendeeId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.SeminarId, t.AttendeeId })
                .ForeignKey("dbo.AspNetUsers", t => t.AttendeeId, cascadeDelete: true)
                .ForeignKey("dbo.Seminars", t => t.SeminarId)
                .Index(t => t.SeminarId)
                .Index(t => t.AttendeeId);
            
            AddColumn("dbo.SeminarTypes", "TypeName", c => c.String(nullable: false, maxLength: 255));
            DropColumn("dbo.SeminarTypes", "Type");
        }
        
        public override void Down()
        {
            AddColumn("dbo.SeminarTypes", "Type", c => c.String(nullable: false, maxLength: 255));
            DropForeignKey("dbo.Attendances", "SeminarId", "dbo.Seminars");
            DropForeignKey("dbo.Attendances", "AttendeeId", "dbo.AspNetUsers");
            DropIndex("dbo.Attendances", new[] { "AttendeeId" });
            DropIndex("dbo.Attendances", new[] { "SeminarId" });
            DropColumn("dbo.SeminarTypes", "TypeName");
            DropTable("dbo.Attendances");
        }
    }
}
