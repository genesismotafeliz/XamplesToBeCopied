﻿using SeminarsHub.Core;
using SeminarsHub.Core.Repositories;
using SeminarsHub.Persistence;
using SeminarsHub.Persistence.Repositories;

namespace SeminarsHub.Persistance
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _context;
        public ISeminarRepository Seminars { get; private set; }
        public IAttendanceRepository Attendances { get; private set; }
        public IFollowingRepository Followings { get; private set; }
        public ITypeRepository Types { get; private set; }
        public IApplicationUserRepository Users { get; private set; }
        public INotificationRepository Notifications { get; private set; }
        public IUserNotificationRepository UserNotifications { get; private set; }

        public UnitOfWork(ApplicationDbContext context)
        {
            _context = context;
            Seminars = new SeminarRepository(_context);
            Attendances = new AttendanceRepository(_context);
            Followings = new FollowingRepository(_context);
            Types = new TypeRepository(_context);
            Users = new ApplicationUserRepositroy();
            Notifications = new NotificationRepository();
            UserNotifications = new UserNotificationRepository();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}