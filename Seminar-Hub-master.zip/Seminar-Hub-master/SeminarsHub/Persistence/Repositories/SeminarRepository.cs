﻿using SeminarsHub.Core.Models;
using SeminarsHub.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace SeminarsHub.Persistence.Repositories
{
    public class SeminarRepository : ISeminarRepository
    {
        private readonly ApplicationDbContext _context;

        public SeminarRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public Seminar GetSeminar(int seminarId)
        {
            return _context.Seminars
                    .Include(s => s.Speaker)
                    .Include(t => t.Type)
                    .SingleOrDefault(s => s.Id == seminarId);
        }

        public IEnumerable<Seminar> GetUpcomingSeminars(string query)
        {
            var upcomingSeminars = _context.Seminars
                .Include(s => s.Speaker)
                .Include(s => s.Type)
                .Where(s => s.DateTime > DateTime.Now && !s.IsCanceled); //displays only upcoming seminars

            if (!String.IsNullOrEmpty(query))
            {
                upcomingSeminars = upcomingSeminars
                    .Where(s => s.Speaker.Name.Contains(query) ||
                                s.Type.TypeName.Contains(query) ||
                                s.Venue.Contains(query));
            }

            return upcomingSeminars.ToList();
        }


        public Seminar GetSeminarWithAttendees(int seminarId)
        {
            return _context.Seminars
                  .Include(s => s.Attendances.Select(a => a.Attendee)) //select the Attendee(user) otherwise will get null exception
                  .SingleOrDefault(s => s.Id == seminarId);

        }

        public IEnumerable<Seminar> GetSeminarsUserAttending(string userId)
        {
            return _context.Attendances
                .Where(a => a.AttendeeId == userId)
                .Select(a => a.Seminar)
                .Include(s => s.Speaker)
                .Include(s => s.Type)
                .ToList();
        }

        public IEnumerable<Seminar> GetUpcomingSeminarsBySpeaker(string userId)
        {
            return _context.Seminars
                 .Where(
                     s => s.SpeakerId == userId
                          && s.DateTime > DateTime.Now
                          && !s.IsCanceled) //Filter Only future seminars
                 .Include(t => t.Type)
                 .ToList();
        }

        public void Add(Seminar seminar)
        {
            _context.Seminars.Add(seminar);
        }

        public void Remove(Seminar seminar)
        {
            _context.Seminars.Remove(seminar);
        }
    }
}