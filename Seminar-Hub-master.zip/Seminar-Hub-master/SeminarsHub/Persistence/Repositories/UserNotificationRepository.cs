﻿using SeminarsHub.Core.Models;
using SeminarsHub.Core.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace SeminarsHub.Persistence.Repositories
{
    public class UserNotificationRepository : IUserNotificationRepository
    {
        private readonly ApplicationDbContext _context;

        public UserNotificationRepository()
        {
            _context = new ApplicationDbContext();
        }

        public IEnumerable<UserNotification> GetUserNotificationsFor(string userId)
        {
            return _context.UserNotifications
                .Where(un => un.UserId == userId && !un.IsRead)
                .ToList();
        }
    }
}