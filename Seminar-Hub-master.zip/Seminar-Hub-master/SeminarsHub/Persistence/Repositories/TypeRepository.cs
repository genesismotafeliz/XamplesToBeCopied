﻿using System.Collections.Generic;
using System.Linq;
using SeminarsHub.Core.Models;
using SeminarsHub.Core.Repositories;

namespace SeminarsHub.Persistence.Repositories
{
    public class TypeRepository : ITypeRepository
    {
        private readonly ApplicationDbContext _context;

        public TypeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<SeminarType> GetTypes()
        {
            return _context.SeminarTypes.ToList();
        }
    }
}