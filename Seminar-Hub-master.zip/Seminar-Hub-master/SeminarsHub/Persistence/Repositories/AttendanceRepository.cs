﻿using SeminarsHub.Core.Models;
using SeminarsHub.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SeminarsHub.Persistence.Repositories
{
    public class AttendanceRepository : IAttendanceRepository
    {
        private readonly ApplicationDbContext _context;

        public AttendanceRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Attendance> GetFutureAttendances(string userId)
        {
            return _context.Attendances
                .Where(a => a.AttendeeId == userId && a.Seminar.DateTime > DateTime.Now)
                .ToList();
        }

        public Attendance GetAttendance(int seminarId, string userId)
        {
            return _context.Attendances
                 .SingleOrDefault(a => a.AttendeeId == userId && a.SeminarId == seminarId);

        }

        public void Add(Attendance attendance)
        {
            _context.Attendances.Add(attendance);
        }

        public void Remove(Attendance attendance)
        {
            _context.Attendances.Remove(attendance);
        }
    }
}