﻿using SeminarsHub.Core.Models;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using SeminarsHub.Core.Repositories;

namespace SeminarsHub.Persistence.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly ApplicationDbContext _context;

        public NotificationRepository()
        {
            _context = new ApplicationDbContext();
        }

        public IEnumerable<Notification> GetNewNotificationsFor(string userId)
        {
            return _context.UserNotifications
                .Where(un => un.UserId == userId && !un.IsRead)
                .Select(un => un.Notification)
                .Include(n => n.Seminar.Speaker)
                .ToList();
        }
    }
}