﻿using SeminarsHub.Core.Models;
using System.Collections.Generic;
using System.Linq;
using SeminarsHub.Core.Repositories;

namespace SeminarsHub.Persistence.Repositories
{
    public class ApplicationUserRepositroy : IApplicationUserRepository
    {
        private readonly ApplicationDbContext _context;

        public ApplicationUserRepositroy()
        {
            _context = new ApplicationDbContext();
        }

        public IEnumerable<ApplicationUser> GetSpeakersFollowedBy(string userId)
        {
            return _context.Followings
                .Where(f => f.FollowerId == userId)
                .Select(f => f.Followee)
                .ToList();
        }
    }
}