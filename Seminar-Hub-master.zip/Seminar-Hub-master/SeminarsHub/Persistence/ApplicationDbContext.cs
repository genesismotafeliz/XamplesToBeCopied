﻿using System.Data.Entity;
using Microsoft.AspNet.Identity.EntityFramework;
using SeminarsHub.Core.Models;

namespace SeminarsHub.Persistence
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {

        public DbSet<Seminar> Seminars { get; set; }
        public DbSet<SeminarType> SeminarTypes { get; set; }
        public DbSet<Attendance> Attendances { get; set; }
        public DbSet<Following> Followings { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<UserNotification> UserNotifications { get; set; }

        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }


        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Attendance>()
                        .HasRequired(a => a.Seminar)
                        .WithMany(s => s.Attendances)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<ApplicationUser>()
                        .HasMany(u => u.Followers)
                        .WithRequired(f => f.Followee)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<ApplicationUser>()
                        .HasMany(u => u.Followees)
                        .WithRequired(f => f.Follower)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<UserNotification>()
                        .HasRequired(n => n.User)
                        .WithMany(u => u.UserNotifications)
                        .WillCascadeOnDelete(false);

            base.OnModelCreating(modelBuilder);
        }
    }
}