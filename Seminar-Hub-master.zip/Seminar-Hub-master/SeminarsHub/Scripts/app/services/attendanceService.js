﻿var AttendanceService = function () {

    var createAttendance = function (seminarId, done, fail) {

        $.post("/api/attendances", { seminarId: seminarId })
            .done(done)
            .fail(fail);

    };

    var deleteAttendance = function (seminarId, done, fail) {

        $.ajax({
            url: "/api/attendances/" + seminarId,
            method: "DELETE"
            })
           .done(done)
           .fail(fail);
    };

    return {
        createAttendance: createAttendance,
        deleteAttendance: deleteAttendance
    }
}();