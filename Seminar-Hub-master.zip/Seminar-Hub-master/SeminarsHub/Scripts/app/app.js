﻿/*
 Implementing Revealing pattern (IIFE) and creating client side Controllers and Services
 */
