﻿var SeminarDetailsController = function(followingService) {

    var followButton;

    var initDetails = function() {
        $(".js-toggle-follow").click(toggleFollowing);
    };

    var toggleFollowing = function() {

        $(".js-toggle-follow").click(function (e) {

            followButton = $(e.target);
            var followeeId = followButton.attr("data-user-id");

            if (followButton.hasClass("btn-default"))
                followingService.createFollowing(followeeId, onCreateDone, onCreateFail);
            else
                followingService.deleteFollowing(followeeId , onDeleteDone , onDeleteFail);
        });
    };

//    var onDone = function() {
//        var text = (followButton.text() === "Follow") ? "Following" : "Follow";
//        followButton.toggleClass("btn-info").toggleClass("btn-default").text(text);
    //    };

        var onCreateDone = function() {
            followButton
                .removeClass("btn-default")
                .addClass("btn-info")
                .text("Following");
        };

        var onDeleteDone = function () {
            followButton
                .removeClass("btn-info")
                .addClass("btn-default")
                .text("Follow");
        };

    var onCreateFail = function () {
        //alert("Something went wrong in CreateApi");
    };

    var onDeleteFail = function () {
        //alert("Something went wrong in DeleteApi");
    };

    return{
        
        initDetails: initDetails
    }

}(FollowingService);