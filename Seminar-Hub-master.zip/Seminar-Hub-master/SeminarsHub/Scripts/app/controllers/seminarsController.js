﻿var SeminarsController = function (attendanceService) { //passing attendanceService as parameter

    var button;

    var initSeminars = function (container) {
        $(container).on("click", ".js-toggle-attendance", toggleAttendance);
    };

    var toggleAttendance = function (e) {

        button = $(e.target);
        var seminarId = button.attr("data-seminar-id");

        if (button.hasClass("btn-default"))
            attendanceService.createAttendance(seminarId, onCreateDone, onFail);
        else
            attendanceService.deleteAttendance(seminarId, onDeleteDone, onFail);
    };

//    var onDone = function () {
//        var text = (button.text() == "Going") ? "Going ?" : "Going";
//        button.toggleClass("btn-info").toggleClass("btn-default").text(text);
//    };

    var onCreateDone = function () {
        button
            .removeClass("btn-default")
            .addClass("btn-info")
            .text("Going");
    };

    var onDeleteDone = function () {
        button
            .removeClass("btn-info")
            .addClass("btn-default")
            .text("Going ?");
    };


    var onFail = function () {
        alert("something went wrong");
    };



    return {
        initSeminars: initSeminars
    }
}(AttendanceService); //passing AttendanceService Module as reference


