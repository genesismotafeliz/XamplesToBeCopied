namespace SeminarsHub.Core.Dtos
{
    public class SeminarTypeDto
    {
        public int Id { get; set; }
        public string TypeName { get; set; }
    }
}