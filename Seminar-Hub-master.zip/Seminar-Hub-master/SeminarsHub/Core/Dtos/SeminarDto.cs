using System;

namespace SeminarsHub.Core.Dtos
{
    public class SeminarDto
    {
        public int Id { get; set; }
        public string Venue { get; set; }
        public DateTime DateTime { get; set; }
        public bool IsCanceled { get; set; }
        public ApplicationUserDto Speaker { get; set; }
        public SeminarTypeDto Type { get; set; }
    }
}