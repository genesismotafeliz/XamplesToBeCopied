﻿namespace SeminarsHub.Core.Dtos
{
    public class FollowingDto
    {
        public string FolloweeId { get; set; }
    }
}