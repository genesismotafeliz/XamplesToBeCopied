namespace SeminarsHub.Core.Dtos
{
    public class ApplicationUserDto
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }
}