﻿namespace SeminarsHub.Core.Dtos
{
    public class AttendanceDto
    {
        public int SeminarId { get; set; }
    }
}