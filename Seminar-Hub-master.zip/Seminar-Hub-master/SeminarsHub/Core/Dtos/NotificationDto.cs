using System;
using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.Dtos
{
    public class NotificationDto
    {

        public NotificationType Type { get; set; }
        public DateTime DateTime { get; set; }
        public DateTime? OriginalDateTime { get; set; } // OriginalDateTime/Venue is for update scenario
        public string OriginalVenue { get; set; }
        public SeminarDto Seminar { get; set; }

    }
}