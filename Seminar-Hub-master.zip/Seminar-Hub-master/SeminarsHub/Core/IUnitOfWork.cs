using SeminarsHub.Core.Repositories;

namespace SeminarsHub.Core
{
    public interface IUnitOfWork
    {
        ISeminarRepository Seminars { get; }
        IAttendanceRepository Attendances { get; }
        IFollowingRepository Followings { get; }
        ITypeRepository Types { get; }
        IApplicationUserRepository Users { get; }
        INotificationRepository Notifications { get; }
        IUserNotificationRepository UserNotifications { get; }
        void SaveChanges();
    }
}