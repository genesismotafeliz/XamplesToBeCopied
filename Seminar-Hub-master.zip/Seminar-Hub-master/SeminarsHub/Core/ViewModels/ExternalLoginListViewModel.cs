﻿namespace SeminarsHub.Core.ViewModels
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}