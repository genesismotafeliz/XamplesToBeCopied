﻿using SeminarsHub.Core.Models;
using System.Collections.Generic;
using System.Linq;

namespace SeminarsHub.Core.ViewModels
{
    public class SeminarsViewModel
    {
        public IEnumerable<Seminar> UpcomingSeminars { get; set; }
        public bool ShowActions { get; set; }
        public string Heading { get; set; }
        public string SearchTerm { get; set; }
        public ILookup<int, Attendance> Attendances { get; set; }


    }
}