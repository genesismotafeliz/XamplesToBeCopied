﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace SeminarsHub.Core.ViewModels.CustomValidations
{
    public class FutureDate : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            DateTime dateTime;
            var isDateValid = DateTime.TryParseExact(Convert.ToString(value),
                "d MMM yyyy",
                CultureInfo.CurrentCulture,
                DateTimeStyles.None, out dateTime);
            return (isDateValid && dateTime > DateTime.Now);
        }
    }
}