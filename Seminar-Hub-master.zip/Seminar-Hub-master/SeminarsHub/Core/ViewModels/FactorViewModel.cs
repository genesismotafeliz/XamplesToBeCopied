namespace SeminarsHub.Core.ViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}