﻿using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.ViewModels
{
    public class SeminarDetailsViewModel
    {
        public Seminar Seminar { get; set; }
        public bool IsAttending { get; set; }
        public bool IsFollowing { get; set; }
    }
}