using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeminarsHub.Core.Models
{
    public class UserNotification //Association class b/w applicationUser(User) and notification
    {

        public bool IsRead { get; private set; }

        [Key]
        [Column(Order = 1)]
        public string UserId { get; private set; }

        [Key]
        [Column(Order = 2)]
        public int NotificationId { get; private set; }

        /*Navigation Properties*/
        public ApplicationUser User { get; private set; }
        public Notification Notification { get; private set; }



        protected UserNotification()
        {
            //This constructor is for EF without default constructor EF wont able
            //to create the instance of this class on run time

        }

        public UserNotification(ApplicationUser user, Notification notification)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            if (notification == null)
                throw new ArgumentNullException(nameof(notification));

            User = user;
            Notification = notification;
        }

        public void Read()
        {
            IsRead = true;
        }
    }
}