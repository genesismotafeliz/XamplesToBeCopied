﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeminarsHub.Core.Models
{
    public class Attendance //Association class b/w seminar and applicationUser(attendee)
    {

        [Key]
        [Column(Order = 1)]
        public int SeminarId { get; set; }

        [Key]
        [Column(Order = 2)]
        public string AttendeeId { get; set; } //DataType is string b/c of ApplicationUser class


        /*Navigation Properties*/
        public Seminar Seminar { get; set; }
        public ApplicationUser Attendee { get; set; }

    }
}