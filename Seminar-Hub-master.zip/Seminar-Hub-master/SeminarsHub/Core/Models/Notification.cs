using System;
using System.ComponentModel.DataAnnotations;

namespace SeminarsHub.Core.Models
{
    public class Notification
    {
        public int Id { get; private set; }

        public NotificationType Type { get; private set; }

        public DateTime DateTime { get; private set; }

        public DateTime? OriginalDateTime { get; private set; } // OriginalDateTime/Venue is for update scenario

        public string OriginalVenue { get; private set; }

        [Required]
        public Seminar Seminar { get; private set; }

        protected Notification()
        {
            //This one is for EF
        }

        private Notification(NotificationType type, Seminar seminar)
        {
            if (seminar == null)
                throw new ArgumentNullException(nameof(seminar));

            Type = type;
            Seminar = seminar;
            DateTime = DateTime.Now;
        }


        /* Simple Factory Methods */

        public static Notification SeminarCreated(Seminar seminar)
        {
            return new Notification(NotificationType.SeminarCreated, seminar);
        }

        public static Notification SeminarUpdated(Seminar newSeminar, DateTime originalDateTime, string originalVenue)
        {
            var notification = new Notification(NotificationType.SeminarUpdated, newSeminar);
            notification.OriginalDateTime = originalDateTime;
            notification.OriginalVenue = originalVenue;

            return notification;
        }

        public static Notification SeminarCanceled(Seminar seminar)
        {
            return new Notification(NotificationType.SeminarCanceled, seminar);
        }
    }
}