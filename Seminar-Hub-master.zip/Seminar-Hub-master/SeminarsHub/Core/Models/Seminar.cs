﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace SeminarsHub.Core.Models
{
    public class Seminar
    {
        public int Id { get; set; }

        [Required]
        [StringLength(355)]
        public string Venue { get; set; }

        public DateTime DateTime { get; set; }

        public bool IsCanceled { get; private set; }

        /*Navigation Properties*/
        public ApplicationUser Speaker { get; set; }
        public SeminarType Type { get; set; }
        public ICollection<Attendance> Attendances { get; private set; }

        /*Foreign Keys*/
        [Required]
        public string SpeakerId { get; set; }   //DataType is string because of ApplicationUser class 

        [Required]
        public int TypeId { get; set; }




        public Seminar()
        {
            Attendances = new Collection<Attendance>();
        }

        public void Cancel()
        {
            IsCanceled = true;
            var notification = Notification.SeminarCanceled(this);
            foreach (var attendee in Attendances.Select(a => a.Attendee))
            {
                attendee.Notify(notification); //Notification for each user i.e attendee(User)
            }

        }



        public void Update(DateTime dateTime, int typeId, string venue)
        {

            var notification = Notification.SeminarUpdated(this, DateTime, Venue);

            Venue = venue;
            DateTime = dateTime;
            TypeId = typeId;

            foreach (var attendee in Attendances.Select(a => a.Attendee))
            {
                attendee.Notify(notification);
            }

        }
    }
}