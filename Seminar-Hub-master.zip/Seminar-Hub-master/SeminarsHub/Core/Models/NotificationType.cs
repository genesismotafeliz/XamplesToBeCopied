﻿namespace SeminarsHub.Core.Models
{
    public enum NotificationType
    {
        SeminarCreated = 1,
        SeminarUpdated = 2,
        SeminarCanceled = 3

    }
}