﻿using System.ComponentModel.DataAnnotations;

namespace SeminarsHub.Core.Models
{
    public class SeminarType
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public string TypeName { get; set; }
    }
}