﻿using System.Collections.Generic;
using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.Repositories
{
    public interface ITypeRepository
    {
        IEnumerable<SeminarType> GetTypes();
    }
}