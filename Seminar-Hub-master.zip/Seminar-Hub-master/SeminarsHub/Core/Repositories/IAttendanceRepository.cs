﻿using SeminarsHub.Core.Models;
using System.Collections.Generic;

namespace SeminarsHub.Core.Repositories
{
    public interface IAttendanceRepository
    {
        IEnumerable<Attendance> GetFutureAttendances(string userId);
        Attendance GetAttendance(int seminarId, string userId);
        void Add(Attendance attendance);
        void Remove(Attendance attendance);

    }
}