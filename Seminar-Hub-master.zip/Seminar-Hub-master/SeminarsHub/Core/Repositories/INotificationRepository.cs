﻿using System.Collections.Generic;
using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.Repositories
{
    public interface INotificationRepository
    {
        IEnumerable<Notification> GetNewNotificationsFor(string userId);
    }
}