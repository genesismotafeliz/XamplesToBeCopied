﻿using System.Collections.Generic;
using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.Repositories
{
    public interface IUserNotificationRepository
    {
        IEnumerable<UserNotification> GetUserNotificationsFor(string userId);
    }
}