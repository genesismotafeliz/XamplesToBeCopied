﻿using SeminarsHub.Core.Models;
using System.Collections.Generic;

namespace SeminarsHub.Core.Repositories
{
    public interface IApplicationUserRepository
    {
        IEnumerable<ApplicationUser> GetSpeakersFollowedBy(string userId);
    }
}