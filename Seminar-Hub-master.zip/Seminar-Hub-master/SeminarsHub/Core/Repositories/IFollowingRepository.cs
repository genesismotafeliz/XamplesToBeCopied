﻿using SeminarsHub.Core.Models;

namespace SeminarsHub.Core.Repositories
{
    public interface IFollowingRepository
    {
        Following GetFollowing(string userId, string seminarSpeakerId);
        void Add(Following following);
        void Remove(Following following);

    }
}