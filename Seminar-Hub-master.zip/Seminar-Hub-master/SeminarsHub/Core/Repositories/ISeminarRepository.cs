using SeminarsHub.Core.Models;
using System.Collections.Generic;

namespace SeminarsHub.Core.Repositories
{
    public interface ISeminarRepository
    {
        Seminar GetSeminar(int seminarId);
        Seminar GetSeminarWithAttendees(int seminarId);
        IEnumerable<Seminar> GetSeminarsUserAttending(string userId);
        IEnumerable<Seminar> GetUpcomingSeminarsBySpeaker(string userId);
        IEnumerable<Seminar> GetUpcomingSeminars(string query);
        void Add(Seminar seminar);
        void Remove(Seminar seminar);
    }
}