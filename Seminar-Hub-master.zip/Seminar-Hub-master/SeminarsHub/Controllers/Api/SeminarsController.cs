﻿using Microsoft.AspNet.Identity;
using SeminarsHub.Core;
using System.Web.Http;

namespace SeminarsHub.Controllers.Api
{
    [Authorize]
    public class SeminarsController : ApiController
    {
        private readonly IUnitOfWork _unitOfWork;

        public SeminarsController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpDelete]
        public IHttpActionResult Cancel(int id)
        {
            var userId = User.Identity.GetUserId();
            var seminar = _unitOfWork.Seminars.GetSeminarWithAttendees(id);

            if (seminar == null || seminar.IsCanceled)
                return NotFound();

            if (seminar.SpeakerId != userId)
                return Unauthorized();

            seminar.Cancel();

            _unitOfWork.SaveChanges();
            return Ok();
        }
    }
}
