﻿using Microsoft.AspNet.Identity;
using SeminarsHub.Core;
using SeminarsHub.Core.Dtos;
using SeminarsHub.Core.Models;
using System.Web.Http;

namespace SeminarsHub.Controllers.Api
{
    [Authorize]
    public class AttendancesController : ApiController
    {
        private readonly IUnitOfWork _unitOfWork;

        public AttendancesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpPost]
        public IHttpActionResult Attend(AttendanceDto dto) //end-point --> /api/attendances
        {
            var userId = User.Identity.GetUserId();
            var attendance = _unitOfWork.Attendances.GetAttendance(dto.SeminarId, userId);

            if (attendance != null)
            {
                return BadRequest("The Attendance is already exists");
            }

            attendance = new Attendance
            {
                SeminarId = dto.SeminarId,
                AttendeeId = userId
            };

            _unitOfWork.Attendances.Add(attendance);
            _unitOfWork.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteAttendance(int id)
        {
            var userId = User.Identity.GetUserId();

            var attendance = _unitOfWork.Attendances.GetAttendance(id, userId);
            if (attendance == null)
                return NotFound();

            _unitOfWork.Attendances.Remove(attendance);
            _unitOfWork.SaveChanges();

            return Ok(id);
        }
    }
}
