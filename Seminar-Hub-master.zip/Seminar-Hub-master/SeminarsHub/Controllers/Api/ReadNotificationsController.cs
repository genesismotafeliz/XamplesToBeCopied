﻿using AutoMapper;
using Microsoft.AspNet.Identity;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Http;
using SeminarsHub.Core.Dtos;
using SeminarsHub.Core.Models;
using SeminarsHub.Persistence;

namespace SeminarsHub.Controllers.Api
{
    public class ReadNotificationsController : ApiController
    {
        private readonly ApplicationDbContext _context;

        public ReadNotificationsController()
        {
            _context = new ApplicationDbContext();
        }


        [HttpGet]
        public IEnumerable<NotificationDto> GetTenReadNotifications()
        {
            var userId = User.Identity.GetUserId();
            var notifications = _context.UserNotifications
                .Where(un => un.UserId == userId && un.IsRead)
                .OrderByDescending(un => un.IsRead)
                .Select(un => un.Notification)
                .Include(n => n.Seminar.Speaker)
                .ToList().Take(10);

            return notifications.Select(Mapper.Map<Notification, NotificationDto>);
        }

    }
}
