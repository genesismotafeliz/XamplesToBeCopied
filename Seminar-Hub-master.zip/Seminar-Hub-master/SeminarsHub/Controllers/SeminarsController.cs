﻿using Microsoft.AspNet.Identity;
using SeminarsHub.Core;
using SeminarsHub.Core.Models;
using SeminarsHub.Core.ViewModels;
using System.Linq;
using System.Web.Mvc;

namespace SeminarsHub.Controllers
{
    public class SeminarsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public SeminarsController(IUnitOfWork unitOfWork)
        {
            //_unitOfWork = new UnitOfWork(new ApplicationDbContext());
            _unitOfWork = unitOfWork;   //Initializing dependency via DIP
        }

        [Authorize]
        public ActionResult Create()
        {
            var viewModel = new SeminarFormViewModel
            {
                Heading = "Add a seminar",
                SeminarTypes = _unitOfWork.Types.GetTypes()
            };


            return View("SeminarForm", viewModel);
        }

        [HttpPost]
        public ActionResult Search(SeminarsViewModel viewModel)
        {
            return RedirectToAction("Index", "Home", new { query = viewModel.SearchTerm });
        }



        [Authorize]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Create(SeminarFormViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.SeminarTypes = _unitOfWork.Types.GetTypes();
                return View("SeminarForm", viewModel);
            }

            var seminar = new Seminar
            {
                SpeakerId = User.Identity.GetUserId(),
                Venue = viewModel.Venue,
                TypeId = viewModel.TypeId,
                DateTime = viewModel.GetDateTime()
            };

            _unitOfWork.Seminars.Add(seminar);
            _unitOfWork.SaveChanges();

            return RedirectToAction("Mine", "Seminars");
        }

        [Authorize]
        public ActionResult Edit(int id) //Edit(Get)
        {
            var userId = User.Identity.GetUserId();

            var seminar = _unitOfWork.Seminars.GetSeminar(id);

            if (seminar == null)
                return HttpNotFound();
            if (seminar.SpeakerId != userId)
                return new HttpUnauthorizedResult();

            var viewModel = new SeminarFormViewModel
            {
                Heading = "Edit a seminar",
                SeminarId = id,
                SeminarTypes = _unitOfWork.Types.GetTypes(),
                Venue = seminar.Venue,
                Date = seminar.DateTime.ToString("d MMM yyyy"),
                Time = seminar.DateTime.ToString("HH:mm"),
                TypeId = seminar.TypeId
            };


            return View("SeminarForm", viewModel);
        }

        [Authorize]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Update(SeminarFormViewModel viewModel) //Edit(Post)
        {
            if (!ModelState.IsValid)
            {
                viewModel.SeminarTypes = _unitOfWork.Types.GetTypes();
                return View("SeminarForm", viewModel);
            }

            var seminar = _unitOfWork.Seminars.GetSeminarWithAttendees(viewModel.SeminarId);

            if (seminar == null)
                return HttpNotFound();

            if (seminar.SpeakerId != User.Identity.GetUserId())
                return new HttpUnauthorizedResult();

            seminar.Update(viewModel.GetDateTime(), viewModel.TypeId, viewModel.Venue);

            _unitOfWork.SaveChanges();

            return RedirectToAction("Mine", "Seminars");
        }


        [HttpGet]
        public ActionResult Details(int id)
        {
            var seminar = _unitOfWork.Seminars.GetSeminar(id);

            if (seminar == null)
                return HttpNotFound();

            var viewModel = new SeminarDetailsViewModel { Seminar = seminar };

            if (User.Identity.IsAuthenticated)
            {
                var userId = User.Identity.GetUserId();

                viewModel.IsAttending = _unitOfWork.Attendances.GetAttendance(seminar.Id, userId) != null;

                viewModel.IsFollowing = _unitOfWork.Followings.GetFollowing(userId, seminar.SpeakerId) != null;

            }

            return View("Details", viewModel);
        }





        [Authorize]
        public ActionResult Mine()  //My upcoming seminars
        {
            var userId = User.Identity.GetUserId();
            var seminars = _unitOfWork.Seminars.GetUpcomingSeminarsBySpeaker(userId);
            return View(seminars);
        }


        [Authorize]
        public ActionResult Attending()  // Seminars User is attending
        {
            var userId = User.Identity.GetUserId();

            var viewModel = new SeminarsViewModel
            {
                UpcomingSeminars = _unitOfWork.Seminars.GetSeminarsUserAttending(userId),
                ShowActions = User.Identity.IsAuthenticated,
                Heading = "Seminars I'm Attending",
                Attendances = _unitOfWork.Attendances.GetFutureAttendances(userId).ToLookup(a => a.SeminarId)
            };

            return View("Seminars", viewModel);
        }



    }
}