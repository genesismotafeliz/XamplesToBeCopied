﻿using Microsoft.AspNet.Identity;
using SeminarsHub.Core;
using SeminarsHub.Core.ViewModels;
using System.Linq;
using System.Web.Mvc;

namespace SeminarsHub.Controllers
{
    public class HomeController : Controller
    {

        private readonly IUnitOfWork _unitOfWork;

        public HomeController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public ActionResult Index(string query = null, int pageNumber = 1) //All Upcoming seminars
        {
            var upcomingSeminars = _unitOfWork.Seminars.GetUpcomingSeminars(query);


            var userId = User.Identity.GetUserId();

            var seminarsViewModel = new SeminarsViewModel
            {
                UpcomingSeminars = upcomingSeminars,
                ShowActions = User.Identity.IsAuthenticated,
                Heading = "Upcoming Seminars",
                SearchTerm = query,
                Attendances = _unitOfWork.Attendances
                                .GetFutureAttendances(userId)
                                .ToLookup(a => a.SeminarId)
            };

            return View("Seminars", seminarsViewModel);
        }


    }
}