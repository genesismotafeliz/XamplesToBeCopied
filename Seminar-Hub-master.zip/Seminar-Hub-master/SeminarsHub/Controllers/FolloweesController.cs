﻿using Microsoft.AspNet.Identity;
using SeminarsHub.Core;
using System.Linq;
using System.Web.Mvc;

namespace SeminarsHub.Controllers
{
    public class FolloweesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public FolloweesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [Authorize]
        [HttpGet]
        public ActionResult Following()  // List of Speakers, User is Following
        {
            var userId = User.Identity.GetUserId();
            var speakers = _unitOfWork.Users.GetSpeakersFollowedBy(userId);
            return View(speakers);
        }

    }
}