﻿using AutoMapper;
using SeminarsHub.Core.Dtos;
using SeminarsHub.Core.Models;

namespace SeminarsHub.App_Start
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            Mapper.CreateMap<ApplicationUser, ApplicationUserDto>();
            Mapper.CreateMap<Seminar, SeminarDto>();
            Mapper.CreateMap<Notification, NotificationDto>();

        }
    }
}