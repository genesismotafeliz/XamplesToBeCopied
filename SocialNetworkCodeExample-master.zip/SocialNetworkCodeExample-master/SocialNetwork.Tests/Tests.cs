﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SocialNetwork.Tests
{
    /// <summary>
    /// Tests for the social network.
    /// </summary>
    [TestClass]
    public class Tests
    {
        /// <summary>
        /// Asserts that the network's GetPosts method return all posts for a user but not those of users,
        /// regardless of whether or not they are following them.
        /// </summary>
        [TestMethod]
        public void GetPostsReturnsAllPostsForUser()
        {
            var userName = "A";
            var message = "New Message";
            var anotherMessage = "Another Message";

            var secondUserName = "B";
            var secondUserMessage = "Second User Message";

            var network = new Network();
            network.AddPost(userName, message);
            network.AddPost(userName, anotherMessage);
            network.AddPost(secondUserName, secondUserMessage);
            network.Follow(userName, secondUserName);

            var results = network.GetPosts(userName);

            // Results should contain message and anotherMessage but not secondUserMessage.
            Assert.IsTrue(results.Count() == 2);
            Assert.IsTrue(results.Any(x => x.Message == message));
            Assert.IsTrue(results.Any(x => x.Message == anotherMessage));
        }

        /// <summary>
        /// Asserts that the network's GetWall method returns a user's own posts as well as posts by users that they follow.
        /// </summary>
        [TestMethod]
        public void GetWallReturnsAllPostsForUserAndSubscriptions()
        {
            var userName = "A";
            var message = "New Message";
            var anotherMessage = "Another Message";

            var secondUserName = "B";
            var secondUserMessage = "Second User Message";

            var thirdUserName = "C";
            var thirdUserMessage = "Third User Message";

            var network = new Network();
            network.AddPost(userName, message);
            network.AddPost(userName, anotherMessage);
            network.AddPost(secondUserName, secondUserMessage);
            network.AddPost(thirdUserName, thirdUserMessage);
            network.Follow(userName, secondUserName);

            // Results for A's wall should contain all 3 posts from users A and B.
            var results = network.GetWall(userName);
            Assert.IsTrue(results.Count() == 3);
            Assert.IsTrue(results.Any(x => x.Message == message));
            Assert.IsTrue(results.Any(x => x.Message == anotherMessage));
            Assert.IsTrue(results.Any(x => x.Message == secondUserMessage));

            // However, results when looking at B's wall should only return B's posts.
            results = network.GetWall(secondUserName);
            Assert.IsTrue(results.Count() == 1);
            Assert.IsTrue(results.Any(x => x.Message == secondUserMessage));
        }
    }
}
