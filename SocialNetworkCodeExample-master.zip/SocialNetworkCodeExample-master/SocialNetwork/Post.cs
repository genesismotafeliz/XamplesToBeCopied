﻿using System;

namespace SocialNetwork
{
    /// <summary>
    /// Represents a user's post.
    /// </summary>
    public class Post
    {
        /// <summary>
        /// Initialises a new instance of the <see cref="Post"/> class.
        /// </summary>
        /// <param name="user">The name of the user who posted the message.</param>
        /// <param name="message">The message.</param>
        public Post(string user, string message)
        {
            this.User = user;
            this.Message = message;
            this.WhenPosted = DateTime.Now;
        }

        /// <summary>
        /// Gets the name of the user who created the post.
        /// </summary>
        public string User { get; private set; }

        /// <summary>
        /// Gets the post's message.
        /// </summary>
        public string Message { get; private set; }

        /// <summary>
        /// Gets the date and time and which the post was created.
        /// </summary>
        public DateTime WhenPosted { get; private set; }
    }
}
