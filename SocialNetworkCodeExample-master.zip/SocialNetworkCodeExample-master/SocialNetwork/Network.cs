﻿using System.Collections.Generic;
using System.Linq;

namespace SocialNetwork
{
    /// <summary>
    /// A class which represents the social network instance.
    /// </summary>
    public class Network
    {
        List<Post> posts = new List<Post>();
        Dictionary<string, List<string>> subscriptions = new Dictionary<string, List<string>>();

        /// <summary>
        /// Adds a post to the network.
        /// </summary>
        /// <param name="user">The user's name.</param>
        /// <param name="message">The message to post.</param>
        public void AddPost(string user, string message)
        {
            this.posts.Add(new Post(user, message));
        }

        /// <summary>
        /// Registers a user's subscription to see other users' posts on their wall.
        /// </summary>
        /// <param name="user">The name of the user.</param>
        /// <param name="follows">The name of the user to follow.</param>
        public void Follow(string user, string follows)
        {
            if (subscriptions.Keys.Contains(user))
            {
                var currentSubscriptions = subscriptions[user];
                currentSubscriptions.Add(follows);
            }
            else
            {
                this.subscriptions.Add(user, new List<string> { follows });
            }
        }

        /// <summary>
        /// Gets a collection of posts written by the given user.
        /// </summary>
        /// <param name="user">The name of the user.</param>
        /// <returns>A collection of posts written by the user.</returns>
        public IEnumerable<Post> GetPosts(string user)
        {
            return this.posts.Where(x => x.User == user);
        }

        /// <summary>
        /// Gets a user's wall.  This contains a user's own posts plus posts written by users that they follow.
        /// </summary>
        /// <param name="user">The name of the user.</param>
        /// <returns>A collection of wall posts.</returns>
        public IEnumerable<Post> GetWall(string user)
        {
            // A user's wall posts will have at least their own submissions.
            var wallPosts = this.posts.Where(x => x.User == user).ToList();

            if (this.subscriptions.ContainsKey(user))
            {
                var userSubscriptions = this.subscriptions[user];
                wallPosts.AddRange(this.posts.Where(x => userSubscriptions.Contains(x.User)));
            }

            return wallPosts;
        }
    }
}
