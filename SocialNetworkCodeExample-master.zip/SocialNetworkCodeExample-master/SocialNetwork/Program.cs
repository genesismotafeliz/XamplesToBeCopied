﻿using System;
using System.Collections.Generic;
using System.Linq;
using Humanizer;

namespace SocialNetwork
{
    /// <summary>
    /// The main application functions.
    /// </summary>
    class Program
    {
        private static string postCommand = " -> ";
        private static string getWallCommand = " wall";
        private static string followCommand = " follows ";

        /// <summary>
        /// The main method.
        /// </summary>
        /// <param name="args">Start up arguments.</param>
        static void Main(string[] args)
        {
            var network = new Network();

            var exit = false;

            Console.WriteLine("Enter 'exit' to exit the application.");

            while (!exit)
            {
                var input = Console.ReadLine();

                if (input == "exit")
                {
                    exit = true;
                }
                else
                {
                    if (input.Contains(postCommand))
                    {
                        var postArguments = SplitOnCommand(input, postCommand);
                        network.AddPost(postArguments[0], postArguments[1]);
                    }
                    else if (input.Contains(getWallCommand))
                    {
                        WritePostsToConsole(network.GetWall(input.Replace(getWallCommand, "")));
                    }
                    else if (input.Contains(followCommand))
                    {
                        var postArguments = SplitOnCommand(input, followCommand);
                        network.Follow(postArguments[0], postArguments[1]);
                    }
                    else
                    {
                        WritePostsToConsole(network.GetPosts(input));
                    }
                }
            }
        }

        /// <summary>
        /// Splits a string by a given string command.
        /// </summary>
        /// <param name="input">The input to split.</param>
        /// <param name="command">The command to split the string on.</param>
        /// <returns>A collection of strings, split by the given command.</returns>
        private static string[] SplitOnCommand(string input, string command)
        {
            return input.Split(new string[1] { command }, StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// Writes a ollection of posts to the console.
        /// </summary>
        /// <param name="posts">A collection of posts.</param>
        private static void WritePostsToConsole(IEnumerable<Post> posts)
        {
            foreach (var post in posts.OrderByDescending(x => x.WhenPosted))
            {
                Console.WriteLine(string.Format("{0} - {1} ({2})", post.User, post.Message, post.WhenPosted.ToUniversalTime().Humanize()));
            }
        }
    }
}
