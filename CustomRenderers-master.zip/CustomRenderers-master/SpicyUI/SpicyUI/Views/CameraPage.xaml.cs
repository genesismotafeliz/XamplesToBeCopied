﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace SpicyUI
{
	public partial class CameraPage : ContentPage
	{
		public CameraPage ()
		{
			InitializeComponent ();
		}
	}
}

