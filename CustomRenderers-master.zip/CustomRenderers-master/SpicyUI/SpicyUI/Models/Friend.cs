﻿using System;

namespace SpicyUI
{
	public class Friend
	{
		public string Name { get; set; }
		public string Image { get; set; }
	}
}