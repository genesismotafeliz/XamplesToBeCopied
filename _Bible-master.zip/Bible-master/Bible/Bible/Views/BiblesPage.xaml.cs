﻿namespace Bible.Views
{
    using Xamarin.Forms;

    public partial class BiblesPage : ContentPage
    {
        public BiblesPage()
        {
            InitializeComponent();
        }
    }
}