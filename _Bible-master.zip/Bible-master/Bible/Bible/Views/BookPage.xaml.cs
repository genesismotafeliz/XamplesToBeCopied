﻿namespace Bible.Views
{
    using Xamarin.Forms;

    public partial class BookPage : ContentPage
    {
        public BookPage()
        {
            InitializeComponent();
        }
    }
}