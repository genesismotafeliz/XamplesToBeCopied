﻿namespace Bible.Views
{
    using Xamarin.Forms;

    public partial class BiblePage : ContentPage
    {
        public BiblePage()
        {
            InitializeComponent();
        }
    }
}