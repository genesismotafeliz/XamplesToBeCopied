﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("PokéAPI.NET")]
[assembly: AssemblyDescription("Wrapper for http://www.pokeapi.co/")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("PoroCYon")]
[assembly: AssemblyProduct("PokéAPI.NET")]
[assembly: AssemblyCopyright("Copyright © PoroCYon 2013-2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: CLSCompliant(true)]
[assembly: InternalsVisibleTo("PokeApi.NET.Tests")]
