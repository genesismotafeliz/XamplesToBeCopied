﻿using System;

namespace Nutritionix.Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            NutritionixSamples.RunAll();

            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }
    }
}
