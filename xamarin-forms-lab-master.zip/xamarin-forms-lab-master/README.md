#59 NinjaTips | Xamarin Forms | Laboratorio Creando un App desde 0

* Video del Lab #1:
https://www.youtube.com/watch?v=mJ7TIXUJmIs
* Video del Lab #2:
https://www.youtube.com/watch?v=viOkK1NwNm8
