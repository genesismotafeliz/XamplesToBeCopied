﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace MasterDetailContentViews
{
    public partial class Page3Tabbed : TabbedPage
    {
        public Page3Tabbed()
        {
            InitializeComponent();
        }
    }
}
