# AdaptiveXamarinApps
