# SocialNetwork
ASP.NET Core 2.0 Project

# Database design at first sign

<img src="data.png" alt="" />