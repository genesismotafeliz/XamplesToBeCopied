﻿namespace SocialNetwork.Common
{
    public class CommonApplicationStrings
    {
        public const string ConnectionString =
            "Server=.;Database={0};Trusted_Connection=True;MultipleActiveResultSets=true";
    }
}