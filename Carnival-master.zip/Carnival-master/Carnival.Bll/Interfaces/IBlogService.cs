﻿using BLL.Entity;
using ClassLibrary.Models;

namespace BLL.Interfaces
{
    public interface IBlogService:IBaseService<Blog>
    {
        
    }
}