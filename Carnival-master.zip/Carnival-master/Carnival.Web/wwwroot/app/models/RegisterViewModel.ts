﻿import { Component } from '@angular/core';

export class RegisterViewModel {
    email: string;
    password: string;
    confirmPassword: string;
}
