﻿import { Component } from '@angular/core';

export class ErrorResponse {
    memberNames: string;
    errorMessage: string;
}
