﻿import { Component } from '@angular/core';

export class TestData {
    id: string;
    username: string;
    text: string;
}
