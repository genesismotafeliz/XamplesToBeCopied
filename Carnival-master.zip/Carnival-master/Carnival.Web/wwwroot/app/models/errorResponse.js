"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ErrorResponse = (function () {
    function ErrorResponse() {
    }
    return ErrorResponse;
}());
exports.ErrorResponse = ErrorResponse;
//# sourceMappingURL=errorResponse.js.map