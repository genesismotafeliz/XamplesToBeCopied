﻿import { Component } from '@angular/core';

export class LoginViewModel {
    email: string;
    password: string;
}
