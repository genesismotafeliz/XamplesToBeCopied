﻿import { Component } from '@angular/core';

export class ChangePasswordViewModel {
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
}
