"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ViewModelResponse = (function () {
    function ViewModelResponse() {
    }
    return ViewModelResponse;
}());
exports.ViewModelResponse = ViewModelResponse;
//# sourceMappingURL=viewModelResponse.js.map