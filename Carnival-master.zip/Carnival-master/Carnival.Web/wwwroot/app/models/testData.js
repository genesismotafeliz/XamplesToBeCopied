"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TestData = (function () {
    function TestData() {
    }
    return TestData;
}());
exports.TestData = TestData;
//# sourceMappingURL=testData.js.map