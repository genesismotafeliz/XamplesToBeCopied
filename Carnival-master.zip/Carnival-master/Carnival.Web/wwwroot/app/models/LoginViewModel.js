"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoginViewModel = (function () {
    function LoginViewModel() {
    }
    return LoginViewModel;
}());
exports.LoginViewModel = LoginViewModel;
//# sourceMappingURL=LoginViewModel.js.map