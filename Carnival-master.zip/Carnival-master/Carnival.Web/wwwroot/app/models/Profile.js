"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Profile = (function () {
    function Profile() {
    }
    return Profile;
}());
exports.Profile = Profile;
//# sourceMappingURL=Profile.js.map