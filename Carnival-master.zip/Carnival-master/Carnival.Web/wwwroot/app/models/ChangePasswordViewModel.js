"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ChangePasswordViewModel = (function () {
    function ChangePasswordViewModel() {
    }
    return ChangePasswordViewModel;
}());
exports.ChangePasswordViewModel = ChangePasswordViewModel;
//# sourceMappingURL=ChangePasswordViewModel.js.map