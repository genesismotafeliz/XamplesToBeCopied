export class Profile {
    id: string;
    bio: string;
    name: string;
}
