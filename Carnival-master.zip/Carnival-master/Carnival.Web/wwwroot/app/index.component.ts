﻿import { Component } from '@angular/core';

@Component({
    selector: 'my-index',
    templateUrl: 'partial/indexComponent'
})

export class IndexComponent {
}
