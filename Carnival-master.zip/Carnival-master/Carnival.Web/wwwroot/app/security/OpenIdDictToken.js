"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OpenIdDictToken = (function () {
    function OpenIdDictToken() {
    }
    return OpenIdDictToken;
}());
exports.OpenIdDictToken = OpenIdDictToken;
//# sourceMappingURL=OpenIdDictToken.js.map