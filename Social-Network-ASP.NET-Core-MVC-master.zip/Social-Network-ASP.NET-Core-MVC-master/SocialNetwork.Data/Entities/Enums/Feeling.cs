﻿namespace SocialNetwork.Data.Entities.Enums
{
    public enum Feeling
    {
        Happy = 0,
        Luky = 1,
        Great = 2,
        Dissapointed = 3,
        Miserable = 4
    }
}