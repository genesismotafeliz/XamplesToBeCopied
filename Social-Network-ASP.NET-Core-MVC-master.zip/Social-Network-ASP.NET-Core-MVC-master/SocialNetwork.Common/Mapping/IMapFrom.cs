﻿namespace SocialNetwork.Common.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}