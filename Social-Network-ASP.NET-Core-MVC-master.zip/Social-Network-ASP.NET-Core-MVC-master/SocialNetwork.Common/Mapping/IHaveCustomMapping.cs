﻿using AutoMapper;

namespace SocialNetwork.Common.Mapping
{
    public interface IHaveCustomMapping
    {
        void ConfigureMapping(Profile profile);
    }
}