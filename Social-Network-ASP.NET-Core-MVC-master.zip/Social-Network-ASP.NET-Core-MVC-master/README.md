# Social-Network-ASP.NET-Core-MVC
A simple social network application developped with ASP.NET Core MVC
