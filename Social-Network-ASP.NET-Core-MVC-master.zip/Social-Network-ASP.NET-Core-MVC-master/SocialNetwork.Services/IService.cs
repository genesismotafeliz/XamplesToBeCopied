﻿namespace SocialNetwork.Services
{
    public interface IService
    {
    }
}