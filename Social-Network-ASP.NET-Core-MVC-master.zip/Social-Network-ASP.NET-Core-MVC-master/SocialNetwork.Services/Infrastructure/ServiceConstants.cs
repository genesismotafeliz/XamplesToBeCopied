﻿namespace SocialNetwork.Services.Infrastructure
{
    public class ServiceConstants
    {
        public const string ImageRenderBaseString = "data:image; base64,";
        public const string AdminUserName = "Administrator";
    }
}