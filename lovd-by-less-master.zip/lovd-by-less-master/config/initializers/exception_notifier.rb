# Add the emails which should receive exception notifications below.  ie: %W(admin1@yoursite.com admin2@yoursite.com)


ExceptionNotifier.sender_address =  %("Name Error <error@appname.url>")
ExceptionNotifier.exception_recipients = %W()
ExceptionNotifier.email_prefix = "[App name Exception] "