require 'rubygems'
require 'ostruct'

