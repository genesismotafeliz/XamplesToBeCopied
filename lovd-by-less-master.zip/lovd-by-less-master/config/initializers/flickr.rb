# ======================
# = Flickr Integration =
# ======================

require 'flickr'

FLICKR_KEY = '311e11626af5e7b9518a960a687a9b9a'
FLICKR_SECRET = '643cbb44766793f1'
FLICKR_CACHE = "#{RAILS_ROOT}/config/flickr.cache"