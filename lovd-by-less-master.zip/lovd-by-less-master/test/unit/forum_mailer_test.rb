require 'test_helper'

class ForumMailerTest < ActionMailer::TestCase
  tests ForumMailer
  # replace this with your real tests
  def test_truth
    assert true
  end
end
