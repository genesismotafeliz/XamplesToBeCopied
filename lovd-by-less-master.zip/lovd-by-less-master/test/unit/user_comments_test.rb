require File.dirname(__FILE__) + '/../test_helper'

class UserCommentsTest < ActiveSupport::TestCase

  def test_associations
    _test_associations
  end
end