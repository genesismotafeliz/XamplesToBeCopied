﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace TanitaTracker.Views
{
    public partial class MainTabbedPage : TabbedPage
    {
        public MainTabbedPage()
        {
            InitializeComponent();
        }
    }
}
