﻿using Xamarin.Forms;

namespace TanitaTracker.Views
{
    public partial class RegisterUserPage : ContentPage
    {
        public RegisterUserPage()
        {
            InitializeComponent();
        }
    }
}
