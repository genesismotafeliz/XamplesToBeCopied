# TanitaTracker   

## Master  ![Build status](https://build.mobile.azure.com/v0.1/apps/78ef69af-242d-4129-a4e6-23101e9156b1/branches/master/badge)
## Develop  ![Build status](https://build.mobile.azure.com/v0.1/apps/78ef69af-242d-4129-a4e6-23101e9156b1/branches/develop/badge)

Tracker of Tanita Omniron for La Foca Fitness club
