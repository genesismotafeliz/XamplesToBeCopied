"C# ASP.Net-MVC-Web-App"

[Academic Project] - Web "Social Network" application.

Built in Visual Studio IDE on-top of windows environment.

------------------------------------------------------------------------------------------------------------

> C# - ASP.Net MVC web application.

> Implemetes 3 seperate modules, where each has full CRUD capabilities. 

> Entity framework DB

> UI Makes use of Javascript, JQuery, HTML5, CSS3
