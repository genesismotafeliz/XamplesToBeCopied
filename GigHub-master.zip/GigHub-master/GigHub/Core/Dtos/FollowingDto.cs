﻿namespace GigHub.Core.Dtos
{
    public class FollowingDto
    {
        public string FolloweeId { get; set; }    
    }
}