﻿namespace GigHub.Core.Dtos
{
    public class AttendanceDto
    {
        public int GigId { get; set; }    
    }
}