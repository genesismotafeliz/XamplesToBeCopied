﻿
namespace GigHub.Core.Models
{
    public enum NotificationType
    {
        GigCanceled = 1, 
        GigUpdated = 2, 
        GigCreated = 3
    }
}