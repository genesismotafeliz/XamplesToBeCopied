taskever
========

A free social network for task management.

http://www.taskever.com/

IMPORTANT: This project is OUT DATED and not compatible with latest version of ASP.NET Boilerplate. It's planned to be updated later.
