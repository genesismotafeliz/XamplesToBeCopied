using Abp.Application.Services.Dto;

namespace Taskever.Friendships.Dto
{
    public class CancelFriendshipRequestInput : EntityDto
    {

    }
}