﻿define('jquery', function () { return jQuery; });
define('knockout', ko);
define(function() {
    return {
        
    };
});