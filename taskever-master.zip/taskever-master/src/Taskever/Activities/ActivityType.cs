namespace Taskever.Activities
{
    public enum ActivityType
    {
        CreateTask = 1,
        CompleteTask = 2
    }
}