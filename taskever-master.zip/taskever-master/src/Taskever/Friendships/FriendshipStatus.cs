namespace Taskever.Friendships
{
    public enum FriendshipStatus
    {
        WaitingApprovalFromFriend = 0,

        WaitingApprovalFromUser = 1,

        Accepted = 2
    }
}