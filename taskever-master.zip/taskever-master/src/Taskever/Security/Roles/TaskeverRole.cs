using Abp.Security.Roles;

namespace Taskever.Security.Roles
{
    public class TaskeverRole : AbpRole
    {
        //no additional field yet
    }
}