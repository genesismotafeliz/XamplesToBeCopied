namespace Taskever.Tasks
{
    public enum TaskPriority:byte
    {
        Low = 1,
        BelowNormal = 2,
        Normal = 3,
        AboveNormal = 4,
        High = 5
    }
}