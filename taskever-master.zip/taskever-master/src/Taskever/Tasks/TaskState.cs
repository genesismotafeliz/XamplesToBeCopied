namespace Taskever.Tasks
{
    public enum TaskState : byte
    {
        New = 1,
        WorkingOn = 2,
        Completed = 3
    }
}