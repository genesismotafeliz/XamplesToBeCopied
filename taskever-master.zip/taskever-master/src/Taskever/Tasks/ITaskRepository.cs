﻿using Abp.Domain.Repositories;

namespace Taskever.Tasks
{
    public interface ITaskRepository : IRepository<Task>
    {
    }
}
