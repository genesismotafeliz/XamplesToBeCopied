﻿using Xamarin.Forms;

namespace PrismSeries.Views
{
    public partial class SeriesListPage : ContentPage
    {
        public SeriesListPage()
        {
            InitializeComponent();
        }
    }
}
