﻿namespace Domain
{
    using Newtonsoft.Json;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }

        [Display(Name = "RNC o Cedula")]
        [MaxLength(15, ErrorMessage = "El tamaño maximo para el campo {0} es {1} caracteres")]
        [Required(ErrorMessage = "Este campo es requerido")]
        public string Rnc { get; set; }

        [Display(Name = "Nombre")]
        [MaxLength(50, ErrorMessage = "Ha Exedido la longitud maxima de este campo")]
        [Required(ErrorMessage = "Este campo es requerido")]
        public string FirstName { get; set; }

        [Display(Name = "Apellido")]
        [MaxLength(50, ErrorMessage = "Ha Exedido la longitud maxima de este campo")]
        [Required(ErrorMessage = "Este campo es requerido")]
        public string LastName { get; set; }

        [Display(Name = "Salario")]
        public decimal? Salary { get; set; }

        [Display(Name = "Direccion")]
        [MaxLength(200, ErrorMessage = "Ha Exedido la longitud maxima de este campo")]
        public string Address { get; set; }

        [Display(Name = "Fecha de Ingreso")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? Date { get; set; }

        [MaxLength(50, ErrorMessage = "Ha Exedido la longitud maxima de este campo")]
        [DataType(DataType.EmailAddress)]
        [Index("Employee_Email_Index", IsUnique = true)]
        public string Email { get; set; }

        [MaxLength(15, ErrorMessage = "Ha Exedido la longitud maxima de este campo")]
        [DataType(DataType.PhoneNumber)]
        [Index("Employee_Tel_Index", IsUnique = true)]
        public string Tel { get; set; }

        [Display(Name = "Contraseña")]
        [DataType(DataType.Password)]
        [StringLength(16, ErrorMessage =
            "El Campo {0} solo acepta maximo {1} y minimo {2} caracteres",
            MinimumLength = 6)]
        public string Password { get; set; }

        public int GenderId { get; set; }

        public int DepartmentId { get; set; }

        public int StatusId { get; set; }

        [Display(Name = "Imagen")]
        [DataType(DataType.ImageUrl)]
        public string PictureRoute { get; set; }

    

        [JsonIgnore]
        public virtual Gender Gender { get; set; }

        [JsonIgnore]
        public virtual Department Department { get; set; }

        [JsonIgnore]
        public virtual Status Status { get; set; }

    }
}
