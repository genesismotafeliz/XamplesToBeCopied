namespace Domain.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Departments",
                c => new
                    {
                        DepartmentId = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.DepartmentId);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployeeId = c.Int(nullable: false, identity: true),
                        Rnc = c.String(nullable: false, maxLength: 15),
                        FirstName = c.String(nullable: false, maxLength: 50),
                        LastName = c.String(nullable: false, maxLength: 50),
                        Salary = c.Decimal(precision: 18, scale: 2),
                        Address = c.String(maxLength: 200),
                        Date = c.DateTime(),
                        Email = c.String(maxLength: 50),
                        Tel = c.String(maxLength: 15),
                        Password = c.String(maxLength: 16),
                        GenderId = c.Int(nullable: false),
                        DeparmentId = c.Int(nullable: false),
                        PictureRoute = c.String(),
                        Department_DepartmentId = c.Int(),
                    })
                .PrimaryKey(t => t.EmployeeId)
                .ForeignKey("dbo.Departments", t => t.Department_DepartmentId)
                .ForeignKey("dbo.Genders", t => t.GenderId, cascadeDelete: true)
                .Index(t => t.Email, unique: true, name: "Employee_Email_Index")
                .Index(t => t.Tel, unique: true, name: "Employee_Tel_Index")
                .Index(t => t.GenderId)
                .Index(t => t.Department_DepartmentId);
            
            CreateTable(
                "dbo.Genders",
                c => new
                    {
                        GenderId = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.GenderId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Employees", "GenderId", "dbo.Genders");
            DropForeignKey("dbo.Employees", "Department_DepartmentId", "dbo.Departments");
            DropIndex("dbo.Employees", new[] { "Department_DepartmentId" });
            DropIndex("dbo.Employees", new[] { "GenderId" });
            DropIndex("dbo.Employees", "Employee_Tel_Index");
            DropIndex("dbo.Employees", "Employee_Email_Index");
            DropTable("dbo.Genders");
            DropTable("dbo.Employees");
            DropTable("dbo.Departments");
        }
    }
}
