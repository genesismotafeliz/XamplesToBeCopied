namespace Domain.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class GettingBacRnc : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Employees", "Rnc", c => c.String(nullable: false, maxLength: 15));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Employees", "Rnc");
        }
    }
}
