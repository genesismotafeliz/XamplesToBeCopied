namespace Domain.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddingStatus : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Status",
                c => new
                    {
                        StatusId = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.StatusId);
            
            AddColumn("dbo.Employees", "StatusId", c => c.Int(nullable: false));
            CreateIndex("dbo.Employees", "StatusId");
            AddForeignKey("dbo.Employees", "StatusId", "dbo.Status", "StatusId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Employees", "StatusId", "dbo.Status");
            DropIndex("dbo.Employees", new[] { "StatusId" });
            DropColumn("dbo.Employees", "StatusId");
            DropTable("dbo.Status");
        }
    }
}
