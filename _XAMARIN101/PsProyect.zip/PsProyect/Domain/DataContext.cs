﻿using System.Data.Entity;

namespace Domain
{
    public class DataContext:DbContext
    {
        public DataContext():base("DefaultConnection")
        {
           

        }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Department> Departments { get; set; }

        public DbSet<Gender> Genders { get; set; }

        public DbSet<Status> Status { get; set; }
    }
}
