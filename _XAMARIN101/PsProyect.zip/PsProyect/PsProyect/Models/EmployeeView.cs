﻿using Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace PsProyect.Models
{
    public class EmployeeView : Employee
    {
        [NotMapped]
        public HttpPostedFileBase PictureFile { get; set; }

        [NotMapped]
        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

    }
}