﻿using Domain;

namespace PsProyect.Models
{
    public class LocalDataContext:EmployeeDbEntities
    {
    }
}