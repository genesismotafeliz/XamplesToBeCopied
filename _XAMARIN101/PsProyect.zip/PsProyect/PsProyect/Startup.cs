﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PsProyect.Startup))]
namespace PsProyect
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
