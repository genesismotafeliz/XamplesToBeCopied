﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AdsAdmin
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class AdMobView : ContentView
	{
		public AdMobView ()
		{
			//InitializeComponent ();
		}
	}
}