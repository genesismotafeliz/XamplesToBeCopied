﻿using Xamarin.Forms;

namespace EmpList.Views
{
    public partial class EmployeeDetaiilsPage : ContentPage
    {
        public EmployeeDetaiilsPage()
        {
            InitializeComponent();
        }
    }
}
