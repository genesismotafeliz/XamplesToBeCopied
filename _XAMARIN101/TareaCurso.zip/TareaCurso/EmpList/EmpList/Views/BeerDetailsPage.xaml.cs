﻿using Xamarin.Forms;

namespace EmpList.Views
{
    public partial class BeerDetailsPage : ContentPage
    {
        public BeerDetailsPage()
        {
            InitializeComponent();
        }
    }
}
