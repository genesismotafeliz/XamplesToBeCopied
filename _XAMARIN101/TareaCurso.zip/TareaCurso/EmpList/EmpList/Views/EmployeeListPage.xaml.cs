﻿using Xamarin.Forms;

namespace EmpList.Views
{
    public partial class EmployeeListPage : ContentPage
    {
        public EmployeeListPage()
        {
            InitializeComponent();
        }
    }
}
