﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parichay.Security.ViewModel
{
    public class DbEntity
    {
        public int Id{get;set;}
        public string Name{get;set;}
        public string LoweredName{get;set;}
        public string Description{get;set;}
    }
}
