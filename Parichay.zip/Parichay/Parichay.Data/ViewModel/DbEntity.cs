﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Parichay.Data.ViewModel
{
    public class DbEntity
    {
        public System.Int32 Id{get;set;}
        public string Name{get;set;}
        public string LoweredName{get;set;}
        public string Description{get;set;}
    }
}
