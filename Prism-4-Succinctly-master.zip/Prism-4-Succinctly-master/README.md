# Prism 4 Succinctly
This is the companion repo for [*Prism 4 Succinctly*](https://www.syncfusion.com/ebooks/prism) by Eric Stitt. Published by Syncfusion.

As the file name suggests, please read the [READ ME FIRST](https://github.com/SyncfusionSuccinctlyE-Books/Prism-4-Succinctly/blob/master/READ%20ME%20FIRST.pdf) document before checking out the demo solutions. 

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/Prism-4-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/prism)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).
