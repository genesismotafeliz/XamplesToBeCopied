﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRISM4.INFRASTRUCTURE.SERVICES.UI_SERVICES.DESCRIPTION_SERVICES
{
    public class DescriptionResult
    {
        public string Description { get; set; }
        public int ExceptionId { get; set; }
    }
}
