﻿namespace Crosschat.Server.Domain.Entities
{
    public enum UserRole
    {
        User,
        Moderator,
        Admin,
    }
}
