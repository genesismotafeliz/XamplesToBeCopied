﻿using Xamarin.Forms;

namespace Crosschat.Client.Views.Controls
{
    public class ChatListView : ListView
    {
    }
}
