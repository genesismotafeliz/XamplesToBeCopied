﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crosschat.Client
{
    public partial class SplashscreenPage
    {
        public SplashscreenPage()
        {
            InitializeComponent();
        }
    }
}
