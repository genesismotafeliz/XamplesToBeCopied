﻿namespace Crosschat.Server.Application.DataTransferObjects.Enums
{
    public enum DevoiceResponseType
    {
        Success,
        Failed,
    }
}