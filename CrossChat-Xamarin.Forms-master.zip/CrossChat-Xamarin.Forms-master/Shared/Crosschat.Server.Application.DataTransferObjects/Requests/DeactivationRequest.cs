﻿namespace Crosschat.Server.Application.DataTransferObjects.Requests
{
    public class DeactivationRequest : RequestBase { }
    public class DeactivationResponse : ResponseBase { }
}