extern "C"
{
    void _ReportAchievement( const char* achievementID, float progress );
}