﻿
namespace MedicalAppointments.ViewModels
{
    public class MedicalAppointmentsViewModel
    {
    }
}
