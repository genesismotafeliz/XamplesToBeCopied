﻿namespace MedicalAppointments.ViewModels
{
    public class RegisterViewModel
    {
    }
}
