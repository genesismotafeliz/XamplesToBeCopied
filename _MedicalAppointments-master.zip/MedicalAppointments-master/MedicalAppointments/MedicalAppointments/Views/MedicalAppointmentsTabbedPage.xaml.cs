﻿
namespace MedicalAppointments.Views
{
    using Xamarin.Forms;

    public partial class MedicalAppointmentsTabbedPage : TabbedPage
    {
        public MedicalAppointmentsTabbedPage ()
        {
            InitializeComponent();
        }
    }
}