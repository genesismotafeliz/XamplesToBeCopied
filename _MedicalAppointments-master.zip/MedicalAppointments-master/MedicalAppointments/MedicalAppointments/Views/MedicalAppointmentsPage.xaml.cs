﻿
namespace MedicalAppointments.Views
{
    using Xamarin.Forms;
	public partial class MedicalAppointmentsPage : ContentPage
	{
		public MedicalAppointmentsPage ()
		{
			InitializeComponent ();
		}
	}
}