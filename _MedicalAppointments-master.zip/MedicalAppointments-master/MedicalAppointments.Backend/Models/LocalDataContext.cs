﻿namespace MedicalAppointments.Backend.Models
{
    using MedicalAppointments.Domain;

    public class LocalDataContext : DataContext
    {        
    }
}