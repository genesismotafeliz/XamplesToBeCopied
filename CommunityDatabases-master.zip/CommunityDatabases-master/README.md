# CommunityDatabases
The goal of this project is share with you,  xamples and complete databases that have served me over the years to improve my knowledge of programming, in order that they can serve you for any system that you are implementing and need some guide or orientation
