SocialWords.NET
===============

A tool for sharing words from Longman English Dictionary on social networks
