##Algoritmos

Algunos libros generales sobre algoritmos:

* Algorithms - Robert Segwick
  * [Libro - Amazon.com](http://amzn.com/032157351X) :moneybag:
  * [Curso gratuito de Princeton University via Coursera](https://www.coursera.org/course/algs4partI) :free: Totalmente gratis e impartido por el autor del libro

* [The art of computer programming - Donald Knuth(Amazon)](http://www.amazon.com/Computer-Programming-Volumes-1-4A-Boxed/dp/0321751043) :moneybag::moneybag::moneybag::moneybag:

Preparación para entrevistas de trabajo:

* [Elements of Programming Interviews - Adnan Aziz (Amazon)](http://amzn.com/1479274836)
* [Cracking the Coding Interview - Gayle Laakmann(Amazon)](http://amzn.com/098478280X)
