##Django

###Nivel Principiante
- http://www.djangobook.com/en/2.0/index.html

###Nivel Intermedio
- http://lightbird.net/dbe2/

###Nivel Avanzado

###Screencasts
- [GoDjango](https://godjango.com/) :moneybag:
 
###Patrones
- https://djangosnippets.org/snippets/
- http://snipplr.com/search.php?q=django&btnsearch=go
