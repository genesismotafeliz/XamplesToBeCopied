##Python

### Libros
* [Dive Into Python](http://www.diveintopython.net/) :free:

### Recursos
* [Documentacion Oficial](https://www.python.org/doc/) :free:
* [Tutorial Interactivo](http://learnpython.org/) :free:
* [Curso de Python gratis](http://www.codecademy.com/tracks/python) :free: _[registracion gratis requerida]_
* [Curso de Python en Google](https://developers.google.com/edu/python/) :free:
* [Curso gratis ofrecido por Rice University](https://www.coursera.org/course/interactivepython) :free:
	_Este curso tiene cupo limitado y es ofrecido por 4 maestros de la Rice University. Muy divertido ya que todos los proyectos semanales son juegos_

### Foros de preguntas y respuestas

#### Para principiantes

* [Reddit: Learn Python](http://www.reddit.com/r/learnpython)

#### Medio y Avanzado

* [Reddit: Python](http://www.reddit.com/r/python)