## Git

#### http://ftp.newartisans.com/pub/git.from.bottom.up.pdf - John Wiegley
[Git from bottom up - John Wiegley](http://ftp.newartisans.com/pub/git.from.bottom.up.pdf)

