##Tecnología y Emprendimiento

####Definición y Administración de un startup

* The Lean Startup
  * http://theleanstartup.com (site oficial)
  * [Amazon](http://amzn.com/0307887898) :moneybag:

* Business Model Generation
  * http://businessmodelgeneration.com (site oficial)
  * [Amazon](http://amzn.com/0470876417) :moneybag:

* [Do More Faster - Techstars Lessons to Accelerate your Startup (Amazon)](http://amzn.com/0470929839) :moneybag:

####Marketing

* [Seth Godin - The purple Cow (Amazon)](http://amzn.com/159184021X) :moneybag:
