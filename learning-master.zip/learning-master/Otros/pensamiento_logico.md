##Pensamiento Logico

A continuación algunos recursos que tratan el proceso de aprendizaje y de como
poner y aplicar ideas en los contextos adecuados para resolver problemas


####Pragmatic Thinking and Learning - Andy Hunt

Este libro es de Andy Hunt, es el escritor del famoso "Programador Pragmático". Es uno de los mejores libros que he leído en mi vida (Amhed)

* [Site oficial](http://pragprog.com/book/ahptl/pragmatic-thinking-and-learning) :moneybag:
* [Amazon.com](http://www.amazon.com/Pragmatic-Thinking-Learning-Refactor-Programmers/dp/1934356050):moneybag:


####Clear and Present Thinking - A handbook in logic and rationality :free:

Este libro surgió a partir de una campaña en Kickstarter para generar un
libro gratis que pueda ser usado en universidades y trate el tema del pensamiento.

Solo puede ser descargado en formato de eBook. Si lo quieres para el kindle, tiene
el precio mínimo de 99 centavos (US$)

* [Site Oficial](http://www.brendanmyers.net/wickedrabbit/index.php?option=com_content&view=article&id=50:cpthinking&catid=19:aboutbooks)
* [Amazon (kindle only)](http://www.amazon.com/Clear-Present-Thinking-Brendan-Myers-ebook/dp/B00CXVSG96)
