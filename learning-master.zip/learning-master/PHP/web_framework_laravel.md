##Laravel

Laravel es un framework web escrito en PHP con una sintaxis expresiva y elegante, nace ante la necesidad de traer buenas prácticas y código de calidad a la comunidad de PHP. Según su propia descripción buscan que desarrollar sea divertido de nuevo y este está muy influenciado por otros frameworks web:

>... we've attempted to combine the very best of what we have seen in other web frameworks, including frameworks implemented in other languages, such as Ruby on Rails, ASP.NET MVC, and Sinatra.

Documentación Oficial: http://www.laravel.com/docs
### Algunos recursos

#### Books
[Laravel Testing Decoded](https://leanpub.com/laravel-testing-decoded) :moneybag:

#### Videos
[Laracasts - Jeffrey Way](https://laracasts.com/) :moneybag:

#### Otros
...
