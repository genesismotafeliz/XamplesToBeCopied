![Angular Logo](https://angularjs.org/img/AngularJS-large.png)

##Angular JS

..

Documentación Oficial: [http://docs.angularjs.org/guide](http://docs.angularjs.org/guide)

### Algunos recursos

#### Books
...

#### Videos
[Egghead.io - John Lindquist (Free & ~US$14.99/Mo)](http://egghead.io) :moneybag:

#### Otros
...

#### Tutoriales

* Tutorial Oficial

    Como crear una aplicacion desde cero. Completo con fuente en github para cada paso

    [https://docs.angularjs.org/tutorial](http://docs.angularjs.org/guide)


* Building an Angular App

    Video tutorial de como crear una aplicacion completa para los que aprenden mejor mirando.
    Paso por paso con codigo fuente disponible en github

    <https://egghead.io/lessons/angularjs-building-an-angular-app-bootstrapping>
    
* Learn AngularJS

    From Codeacademy: Learn to build web apps using AngularJS 1.x. By the end of the course, you'll be able to use AngularJS to create your own apps.

    [Learn AngularJS](www.codecademy.com/learn/learn-angularjs)

    
