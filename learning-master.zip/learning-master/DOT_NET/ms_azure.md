##AZURE
Microsoft Azure (anteriormente Windows Azure y Azure Services Platform) es una plataforma ofrecida como servicio y alojada en los Data Centers de Microsoft

Excelente articulo para iniciar en el mundo de azure.
 
###Recursos para principiantes:

* [Learning map for Azure Websites](http://azure.microsoft.com/en-us/documentation/articles/websites-learning-map/)
* [The world's greatest Azure demo](http://www.troyhunt.com/2014/03/the-worlds-greatest-azure-demo.html)
* [Pluralsight: Introduction to Windows Azure](http://www.pluralsight.com/courses/beginner-azure) :moneybag: 
* [Azure Fridays - Demostraciones semanales](http://azure.microsoft.com/en-us/documentation/videos/azure-friday/)

