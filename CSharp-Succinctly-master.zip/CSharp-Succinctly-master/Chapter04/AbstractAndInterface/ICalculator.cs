﻿public interface ICalculator
{
    double Add(double num1, double num2);
}