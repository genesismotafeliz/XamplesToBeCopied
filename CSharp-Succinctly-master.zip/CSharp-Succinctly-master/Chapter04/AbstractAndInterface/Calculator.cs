﻿public abstract class Calculator
{
    // ...
    public abstract double Add(double num1, double num2);
}