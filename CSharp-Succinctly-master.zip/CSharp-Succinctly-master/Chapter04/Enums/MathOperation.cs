﻿public enum MathOperation
{
    Add,
    Subtract,
    Multiply,
    Divide
}