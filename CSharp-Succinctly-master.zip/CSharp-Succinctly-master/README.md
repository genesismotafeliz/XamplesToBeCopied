# C# Succinctly
This is the companion repo for [*C# Succinctly*](https://www.syncfusion.com/ebooks/csharp) by Joe Mayo. Published by Syncfusion.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/CSharp-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/csharp)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).
