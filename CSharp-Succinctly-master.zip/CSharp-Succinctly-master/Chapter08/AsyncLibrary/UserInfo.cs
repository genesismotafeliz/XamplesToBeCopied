﻿public class UserInfo
{
    public string Info { get; set; }
    public string Address { get; set; }
}
