﻿using System;

public class ClickEventArgs : EventArgs
{
    public string Name { get; set; }
}