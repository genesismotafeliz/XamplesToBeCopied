﻿public delegate double Add(double num1, double num2);
