﻿public class Program
{
    public static void Main()
    {
        var llist = new LinkedList<string>();
        llist.Add("Jamie");
        llist.Add("Ron");
        //...

        Node<string> name = new Node<string>("May");
    }
}
