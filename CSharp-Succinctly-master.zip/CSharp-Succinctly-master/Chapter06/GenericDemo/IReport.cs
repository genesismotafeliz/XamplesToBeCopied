﻿using System;

public interface IReport
{
    DateTime Date { get; set; }
}
