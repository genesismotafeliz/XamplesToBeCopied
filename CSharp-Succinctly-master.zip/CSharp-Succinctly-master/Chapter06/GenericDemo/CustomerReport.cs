﻿using System;

public class CustomerReport : Report, IReport
{
    public DateTime Date { get; set; }
}
