﻿using System;

public class OrdersReport : Report, IReport
{
    public DateTime Date { get; set; }
}
