﻿public abstract class Report { }
