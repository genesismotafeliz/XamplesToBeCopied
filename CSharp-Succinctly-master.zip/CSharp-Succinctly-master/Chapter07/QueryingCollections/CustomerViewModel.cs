﻿public class CustomerViewModel
{
    public string Name { get; set; }
}
