﻿public class Order
{
    public int CustomerID { get; set; }
    public string Description { get; set; }
}
