using System;

class Greetings
{
    static void Main()
    {
        Console.WriteLine("Greetings!");

    }
}