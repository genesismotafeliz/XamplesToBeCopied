﻿using Syncfusion;
using System;

using Crypto = System.Security.Cryptography;

namespace NamespaceDemo
{
    class Program
    {
        static void Main()
        {
            int val1 = 5;
            Console.WriteLine(val1);
            int val2 = ++val1;
            Console.WriteLine(val2);

            Console.Read();
        }
    }
}
