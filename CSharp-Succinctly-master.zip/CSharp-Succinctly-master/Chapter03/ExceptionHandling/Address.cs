﻿public class Address
{
    public string City { get; set; }
}
