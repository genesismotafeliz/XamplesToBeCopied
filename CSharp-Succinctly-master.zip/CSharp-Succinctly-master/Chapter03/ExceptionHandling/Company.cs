﻿internal class Company
{
    public Address Address { get; set; }
}
