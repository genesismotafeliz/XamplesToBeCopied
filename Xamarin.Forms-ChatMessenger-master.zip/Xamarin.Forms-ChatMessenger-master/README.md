# Xamarin.Forms-ChatMessenger
Uses the JSQmessages component and makes it work with Xamarin.forms.  It is meant currently only for iOS. 

The code is documented.

It works such that there is a ChatPageRenderer in the iOS solution. It would make more sense if you ran the code.  It uses that with the JSQMessages Component for Xamarin. Feel free to use as you wish.
