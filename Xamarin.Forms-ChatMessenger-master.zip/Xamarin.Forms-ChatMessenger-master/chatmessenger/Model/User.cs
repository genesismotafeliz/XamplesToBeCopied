﻿using System;

namespace chatmessenger
{
	public class User
	{
		public string Id { get; set;}
		public string DisplayName { get; set;}
	}
}

