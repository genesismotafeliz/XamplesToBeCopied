<?php
/*******************************************************
 *   Copyright (C) 2006  http://p3net.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************/ 
ini_set("include_path", SPACES_DIRECTORY . 'libs');

//ini_set("error_reporting", E_ERROR);
require_once(SPACES_DIRECTORY . 'libs/spaces.libs.php');
require_once(SPACES_DIRECTORY . 'libs/Smarty.class.php');
require_once(SPACES_DIRECTORY . 'user_uploaded/processor.php');
require_once(SPACES_DIRECTORY . 'config.php');

// database configuration
class Spaces_SQL {
    function Spaces_SQL() {
	
        if(defined('DB_NAME'))
        {
        	mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die("<b>Critical Error:</b> Could not connect to database.");
        	mysql_select_db(DB_NAME) or die("<b>Critical Error:</b> Could not select AstroSPACES table.");
        }
    }       
}

// smarty configuration
class Spaces_Smarty extends Smarty { 
    function Spaces_Smarty() {
        $this->compile_dir = SPACES_DIRECTORY . 'templates_c';
        $this->config_dir = SPACES_DIRECTORY . 'configs';
        $this->cache_dir = SPACES_DIRECTORY . 'cache';
    }
}   
?>
