To use AstroSPACES 1.1.1, you must perform the following steps, in order:
===========================================================================
FRESH INSTALL
SEE BELOW FOR UPGRADE
===========================================================================
1) Open /definitions.php

2) Locate the line "define('SPACES_DIRECTORY', 'EDITME');".

3) Edit with the FULL path of your web directory (usually something like wwwroot/username/domainname/htdocs/). If you are unsure, contact your webhost. BE SURE TO INCLUDE TRAILING SLASH!

4) Locate the line "define('SPACES_PATH', 'EDITME');".

5) Edit with the domain name and path that AstroSPACES will be accessible from. For example, if you access AstroSPACES at http://mydomain.com/astrospaces, put http://mydomain.com/astrospaces in place of EDITME. BE SURE TO INCLUDE THE TRAILING SLASH! **NOTE: IF THIS IS NOT CORRECT, NOBODY WILL BE ABLE TO ACTIVATE THEMSELVES!!!**

4) Open templates/header.tpl

5) Find the following line:
<base url="http://www.yoursite.com">
6) Change http://yoursite.com to your domain name (for example, if your domain name is p3net.net, the line would now read the following:
<base url="http://p3net.net">) THE WWW DEPENDS ON YOUR PREFERANCES!

7) Upload the ENTIRE contents of the astroSPACES folder.
8) CHMOD all directories to 777 (rwxrwxrwx)

9) Browse to http://mydomain.com/space.php?action=install
10) Follow the installer directions

11) If all goes well, you will be directed to the registration page.

12) Register

13) Invite your friends to join!

IN THE EVENT YOU ARE NOT ABLE TO INSTALL USING THE NORMAL INSTALLER, PLEASE CONTINUE OVER TO THE /misc DIRECTORY.
THERE IS ALTERNATE INSTALL INFORMATION IN THAT DIRECTORY.

=========================================================================
UPGRADING

NOTE: To upgrade multiple version, you must go version-by-version.
=========================================================================
UPGRADE
1.0.1 - 1.0.2
=========================================================================
1) Follow steps  1-8 Above
2) Browse to http://yoursite.com/index.php?action=update101-102
3) If there are no errors, enjoy your AstroSPACES upgrade!
=========================================================================
UPGRADE
1.0.2 - 1.1.0
=========================================================================
1) Follow steps 1-8 Above. There is no need to run the updater, no 
   database changes have been made.
=========================================================================
UPGRADE
1.1.0 - 1.1.1
=========================================================================
1) Follow steps 1-5 Above.
2) Upload every file EXCEPT config.php in the 1.1.1 package
3) Browse to http://yoursite.com/index.php?action=update
4) If there are no errors, enjoy your AstroSPACES upgrade!

If you have any issues, please post at our support forum, located at
http://p3net.net/

Google Code is also the host of out SVN repository, if you care to check out 
the bleeding edge code. The url to the Google Code project is 
http://code.google.com/p/osspaces

========== DEVELOPERS ==========
Kirk Stebbler <http://p3net.net> -- Development Team Leader
jon-c <http://kornfieldusa.com> -- Development Team
Computer-Geek <> -- Development Team