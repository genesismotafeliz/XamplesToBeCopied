<?php
/*******************************************************
 *   Copyright (C) 2006  http://p3net.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************/ 
require('definitions.php');

$_action= isset($_REQUEST["action"]) ? $_REQUEST["action"] : 'index';
switch($_action)
{
	case 'index':
		$spaces->adminHome();
		break;
	case 'edituserlist':
		$action=$_GET["mode"];
		$spaces->adminEditUserList($action);		
		break;
	case 'edituser':
		$id=$_GET["id"];
		$spaces->adminEditUser($id);
		break;
	case 'editusersubmit':
		$spaces->adminEditUserProcess($_POST);
		break;
	case 'editspace':
		$id=$_GET["id"];
		$spaces->adminEditSpace($id);
		break;
	case 'editspaceprocess':
		$spaces->adminEditSpaceProcess($_POST);
		break;
	case 'editcomments':
		$id=$_GET["id"];
		$spaces->adminDeleteComment($id);
		break;
	case 'deletecommentprocess':
		$id=$_GET["id"];
		$spaces->adminDeleteCommentProcess($id);
		break;
	case 'deluser':
		$id=$_GET["id"];
		$spaces->adminDeleteUser($id);
		break;
	case 'styleinstall':
		$spaces->adminTemplateInstall();
		break;
	case 'installstyle':
		$spaces->adminStyleProcess($_GET["name"]);
		break;
}
?>