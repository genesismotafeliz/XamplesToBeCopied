<?php
/*******************************************************
 *   Copyright (C) 2006  http://p3net.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************/ 
class ProfileChanges {

    // database object
    var $sql = null;
    // smarty template object
    var $tpl = null;
    // error messages
    var $error = null;
    
    /**
     * class constructor
     */
    function ProfileChanges() {

        // instantiate the sql object
        $this->sql =& new Spaces_SQL;
        // instantiate the template object
        $this->tpl =& new Spaces_Smarty;

    }
function submitProfileChanges($formvars)
    {
      $id=$_POST["id"];
      $username=$_POST["username"];
      $aim=$_POST["aim"];
      $msn=$_POST["msn"];
      $irc=$_POST["irc"];
      $icq=$_POST["icq"];
      
      $update=array(
      "UPDATE users SET `username`='$username' WHERE `id`=$id",
      "UPDATE users SET `aim`='$aim' WHERE `id`=$id",
      "UPDATE users SET `msn`='$msn' WHERE `id`=$id",
      "UPDATE users SET `irc`='$irc' WHERE `id`=$id",
      "UPDATE users SET `icq`='$icq' WHERE `id`=$id");
      
      mysql_query($update[0]);
      mysql_query($update[1]);
      mysql_query($update[2]);
      mysql_query($update[3]);
      mysql_query($update[4]);
      
      if(!(empty($_FILES["uploadedfile"]["tmp_name"])))
      {
        $path = "user_uploaded/" . $_SESSION["userid"] . "/";
        if(!(is_dir($path)))
        {
          mkdir($path) or die("Unable to make directory: " . $path);
        }
      	if($_FILES['uploadedfile']['size'] > 75000)
      	{
      		die("Your file is too big -- the maximum filesize is 75k!");
      	}
      	$ext=explode(".", basename($_FILES['uploadedfile']['name']));
      	$count=count($ext);
      	$count=$count-1;
      	$name=rand(1,10000000) * rand(1,1000000);
      	$name=$name . "." . $ext[$count];
		implode("/", $tempdir);
		//$name=$tempdir . "" . $name;
		$path=$path . $name;
		
		//die($name . " | " . $path . " | " . $tempdir);
		
        if(move_uploaded_file($tempdir . $_FILES['uploadedfile']['tmp_name'], $path))
        {
          $name=basename($name);
          $id=$_SESSION["userid"];
          $_query="UPDATE users SET `icon`='$name' WHERE id=$id LIMIT 1";
          mysql_query($_query);
        }
      
        else
        {
          die("Could not upload your profile image. Please try again.");
        }
      }
    }
    function make_path($id)
    {
       $path = "user_uploaded/" . $id  . "/";
        if(!(is_dir($path)))
        {
          mkdir($path);
        }
  }
 }
?>
