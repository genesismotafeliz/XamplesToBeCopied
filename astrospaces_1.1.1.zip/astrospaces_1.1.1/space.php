<?php
/*******************************************************
 *   Copyright (C) 2006  http://p3net.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************/ 
require('definitions.php');

$_action= isset($_REQUEST["action"]) ? $_REQUEST["action"] : 'view';

switch($_action)
{
  case 'view':
    if(isset($_GET["id"]) && !(empty($_GET["id"])))
    {
      $id=$_GET["id"];
    }
    else
    {
      $id=$_SESSION["userid"];
    }
    if(empty($id))
    {
      header('location: profile.php?action=login');
    }
    $spaces->showSpace($id);
    break;
  
  case 'edit':
    $spaces->editSpace();
    break;
  
  case 'editprocess':
    $spaces->editSpaceProcess($_POST);
    break;
  
  case 'sendcomment':
    $to=$_GET["id"];
    $spaces->addComment($to);
    break;
  
  case 'comment_process':
    $spaces->addCommentProcess($_POST);
    break;
  
  case 'addfriend':
    $add=$_GET["id"];
    $spaces->addAsFriend($add);
    break;
    
  case 'memberlist':
  	$spaces->memberlist();
  	break;
  
  case 'install' :
  	$spaces->install();
  	break;
  	
  case 'install_process' :
  	$spaces->install_process($_POST);
  	break;
  
  case 'rewrite' :
  	$name=$_GET["name"];
  	$spaces->rewrite_url($name);
  	break;
  	
  case 'friendauth' :
  	$spaces->authfriend();
  	break;
  
  case 'approvefriend' :
  	$id=$_GET["id"];
  	$spaces->approvefriend($id);
  	break;
  case 'deletecomment':
  	$id=$_GET["id"];
  	$spaces->deleteComment($id);
  	break;
}
?>
