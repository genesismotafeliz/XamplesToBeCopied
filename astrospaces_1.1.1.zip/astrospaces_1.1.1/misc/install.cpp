#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream installer;
    string dbname;
    string dbuser;
    string dbpass;
    string dbhost;
    
    cout << "Welcome to the AstroSPACES Alternate Installer." << endl;
    cout << "This installer is meant for those who are unable" << endl;
    cout << "to use the standard installer." << endl;
    
    cout << endl << "Please input your database name: ";
    cin >> dbname;
    cout << endl << "Please input your databaser user: ";
    cin >> dbuser;
    cout << endl << "Please input your database password: ";
    cin >> dbpass;
    cout << "Please input your database host: ";
    cin >> dbhost;
    cout << endl << "We are now writing config.php. Please continue" << endl;
    cout << "reading the README in this directory for information on" << endl;
    cout << "installing the database. Enjoy using AstroSPACES!";
    
    installer.open("../config.php");
    installer << "<?php define('DB_NAME', '" << dbname << "'); define('DB_USER', '" << dbuser << "'); define('DB_PASSWORD', '" << dbpass << "'); define('DB_HOST', '" << dbhost << "'); ?>";
    installer.close();
    return 0;
}
