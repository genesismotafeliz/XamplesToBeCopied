﻿namespace Automoviles
{


    partial class AutomovilesDataSet
    {
    }
}

namespace Automoviles.AutomovilesDataSetTableAdapters {
    
    
    public partial class MarcaTableAdapter {
    }
}
