﻿namespace mobSocial.Core.Exception
{
    public class mobSocialException : System.Exception
    {
        public mobSocialException()
        { }

        public mobSocialException(string message) : base(message)
        {
            
        }
    }
}