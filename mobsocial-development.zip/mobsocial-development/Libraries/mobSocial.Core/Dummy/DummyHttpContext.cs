﻿using System.Web;

namespace mobSocial.Core.Dummy
{
    /// <summary>
    /// Specifies a dummy httpcontext for test purposes
    /// </summary>
    public class DummyHttpContext : HttpContextBase
    {
        
    }
}