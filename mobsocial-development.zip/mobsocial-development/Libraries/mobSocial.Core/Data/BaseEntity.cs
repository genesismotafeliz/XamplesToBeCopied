﻿namespace mobSocial.Core.Data
{
    public abstract partial class BaseEntity
    {
        /// <summary>
        /// The Id of the entity
        /// </summary>
        public int Id { get; set; }
    }
}