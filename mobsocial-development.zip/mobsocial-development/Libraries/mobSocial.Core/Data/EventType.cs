﻿namespace mobSocial.Core.Data
{
    public enum EventType
    {
        Insert,
        Update,
        Delete
    }
}