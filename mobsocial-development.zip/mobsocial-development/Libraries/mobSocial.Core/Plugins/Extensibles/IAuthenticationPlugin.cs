﻿namespace mobSocial.Core.Plugins.Extensibles
{
    /// <summary>
    /// Interface for creating authentication plugins
    /// </summary>
    public interface IAuthenticationPlugin : IPlugin
    {

    }
}