﻿namespace mobSocial.Core.Plugins.Extensibles.Payments
{
    public interface ITransactionVoidRequest : ITransactionRequestBase
    {
        
    }
}