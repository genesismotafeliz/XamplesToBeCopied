﻿// 
namespace mobSocial.Core.Plugins.Extensibles.Payments
{
    public interface ITransactionVoidResult : ITransactionResultBase
    {
        
    }
}