﻿namespace mobSocial.Core.Plugins.Extensibles.Payments
{
    public interface ITransactionCaptureRequest : ITransactionRequestBase
    {
        
    }
}