﻿namespace mobSocial
{
    public class GlobalSettings
    {
        public const string AppVersion = "1.0";
    }
}