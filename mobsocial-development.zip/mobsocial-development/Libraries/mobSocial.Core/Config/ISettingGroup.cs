﻿namespace mobSocial.Core.Config
{
    public interface ISettingGroup
    {
         
    }
}