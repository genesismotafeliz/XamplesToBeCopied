﻿namespace mobSocial.Data.Constants
{
    public static class TimelineAutoPostTypeNames
    {
        public static class VideoBattle
        {
            public const string Publish = "videobattle-publish";
            public const string BattleStart = "videobattle-start";
            public const string BattleComplete = "videobattle-complete";
        }
    }
}
