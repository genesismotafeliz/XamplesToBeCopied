﻿namespace mobSocial.Data.Constants
{
    public class CreditContextKeyNames
    {
        public const string BattleVote = "battle_vote_{0}";

        public const string BattleSponsor = "battle_sponsor_{0}";


    }
}