﻿namespace mobSocial.Data.Constants
{
    public class EmailTokenNames
    {
        public const string MessageContent = "{{Message.Content}}";

        public const string ActivationUrl = "{{User.ActivationUrl}}";
    }
}
