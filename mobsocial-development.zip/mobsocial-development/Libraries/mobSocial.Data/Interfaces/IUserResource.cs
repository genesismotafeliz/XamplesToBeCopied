﻿namespace mobSocial.Data.Interfaces
{
    public interface IUserResource
    {
        int Id { get; set; }

        int UserId { get; set; }
    }
}