﻿namespace mobSocial.Data.Interfaces
{
    public interface IPermalinkSupported
    {
        int Id { get; set; }

        string Name { get; set; }
    }
}