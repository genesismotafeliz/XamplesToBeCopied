﻿namespace mobSocial.Data.Enum
{
    public enum LoginStatus
    {
        Success,
        FailedInactiveUser,
        FailedDeletedUser,
        FailedUserNotExists,
        Failed
    }
}