﻿namespace mobSocial.Data.Enum
{
    public enum UserRegistrationStatus
    {
        Success,
        FailedAsEmailAlreadyExists
    }
}