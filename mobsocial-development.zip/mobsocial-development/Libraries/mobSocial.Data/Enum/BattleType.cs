﻿namespace mobSocial.Data.Enum
{
    public enum BattleType
    {
        Video = 1,
        Picture = 2
    }
}