﻿namespace mobSocial.Data.Enum
{
    public enum BattleVoteType
    {
        Rating,
        LikeDislike,
        SelectOneWinner
    }
}
