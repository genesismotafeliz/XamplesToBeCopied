﻿namespace mobSocial.Data.Enum
{
    public enum BattleParticipationType
    {
        Open = 1,
        InviteOnly = 2,
        SignUp = 3
    }
}
