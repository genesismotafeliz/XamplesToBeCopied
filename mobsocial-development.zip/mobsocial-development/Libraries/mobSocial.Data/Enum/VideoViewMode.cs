namespace mobSocial.Data.Enum
{
    public enum VideoViewMode
    {
        Regular = 0,
        TheaterMode = 1

    }
}