﻿namespace mobSocial.Data.Enum
{
    public enum SponsorshipType
    {
        CashWithOptionalProducts = 1,
        OnlyProducts = 2
    }
}