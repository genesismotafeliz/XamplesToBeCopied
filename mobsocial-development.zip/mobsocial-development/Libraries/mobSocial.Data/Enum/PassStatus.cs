﻿namespace mobSocial.Data.Enum
{
    public enum PassStatus
    {
        NotUsed = 0,
        Used = 1
    }
}