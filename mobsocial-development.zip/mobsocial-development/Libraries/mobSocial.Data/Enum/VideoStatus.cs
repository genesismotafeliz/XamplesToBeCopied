﻿namespace mobSocial.Data.Enum
{
    public enum VideoStatus
    {
        Pending,//video uploaded is pending for moderation
        Approved //video uploaded is approved
    }
}
