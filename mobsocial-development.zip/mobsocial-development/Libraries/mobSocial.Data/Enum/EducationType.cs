﻿namespace mobSocial.Data.Enum
{
    public enum EducationType
    {
        School,
        College,
        Graduation
    }
}