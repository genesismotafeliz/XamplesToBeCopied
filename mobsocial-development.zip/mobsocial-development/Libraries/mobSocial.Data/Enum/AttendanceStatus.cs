﻿namespace mobSocial.Data.Enum
{
    public enum AttendanceStatus
    {
        None = 0,
        Invited = 1,
        Going = 2,
        Maybe = 3,
        NotGoing = 4
        
    }
}
