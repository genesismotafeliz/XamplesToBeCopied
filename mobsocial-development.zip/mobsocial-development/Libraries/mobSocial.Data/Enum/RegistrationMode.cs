﻿namespace mobSocial.Data.Enum
{
    public enum RegistrationMode
    {
        Immediate,
        WithActivationEmail,
        ManualApproval
    }
}