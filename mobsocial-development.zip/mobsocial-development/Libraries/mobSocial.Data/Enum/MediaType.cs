﻿namespace mobSocial.Data.Enum
{
    public enum MediaType
    {
        Image,
        Video,
        Zip,
        Pdf,
        Powerpoint,
        Word
    }
}