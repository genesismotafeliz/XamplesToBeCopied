﻿namespace mobSocial.Data.Enum
{
    public enum BattlesSortBy
    {
        VotingStartDate,
        VotingEndDate,
        SponsorshipAmount,
        PrizeAmount,
        NumberOfParticipants,
        Id
    }
}