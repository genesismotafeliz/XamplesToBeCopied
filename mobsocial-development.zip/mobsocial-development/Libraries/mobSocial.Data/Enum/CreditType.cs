﻿namespace mobSocial.Data.Enum
{
    public enum CreditType
    {
        Transactional = 1,
        Promotional = 2
    }
}