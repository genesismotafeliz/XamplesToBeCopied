﻿namespace mobSocial.Data.Enum
{
    public enum SponsoredCashDistributionType
    {
        TopWinnerGetsAll = 0,
        AllWinnersGetShare = 1
    }
}