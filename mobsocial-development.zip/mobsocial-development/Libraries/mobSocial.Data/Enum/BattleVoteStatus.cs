﻿namespace mobSocial.Data.Enum
{
    public enum BattleVoteStatus
    {
        Voted,
        NotVoted
    }
}
