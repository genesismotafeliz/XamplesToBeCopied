﻿namespace mobSocial.Data.Enum
{
    public enum MediaSaveLocation
    {
        Database = 0,
        FileSystem = 1
    }
}
