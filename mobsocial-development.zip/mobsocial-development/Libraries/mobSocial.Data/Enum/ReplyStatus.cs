﻿namespace mobSocial.Data.Enum
{
    public enum ReplyStatus
    {
        Sent = 1,
        Received = 2,
        Read = 3,
        Deleted = 4
    }
}