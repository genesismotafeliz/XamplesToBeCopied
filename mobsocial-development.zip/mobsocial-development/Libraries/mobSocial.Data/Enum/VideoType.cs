namespace mobSocial.Data.Enum
{
    public enum VideoType
    {
        AlbumVideo = 1,
        BattleVideo = 2
    }
}