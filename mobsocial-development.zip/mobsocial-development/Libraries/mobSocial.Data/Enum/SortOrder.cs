﻿namespace mobSocial.Data.Enum
{
    public enum SortOrder
    {
        Ascending = 1,
        Descending = 2
    }
}