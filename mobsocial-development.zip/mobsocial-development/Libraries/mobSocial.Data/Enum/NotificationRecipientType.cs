﻿namespace mobSocial.Data.Enum
{
    public enum NotificationRecipientType
    {
        Voter,
        Participant
    }
}
