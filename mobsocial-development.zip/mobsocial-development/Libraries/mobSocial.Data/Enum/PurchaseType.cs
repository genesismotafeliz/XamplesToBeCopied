﻿namespace mobSocial.Data.Enum
{
    public enum PurchaseType
    {
        VoterPass = 1,
        SponsorPass = 2
    }
}