﻿namespace mobSocial.Data.Enum
{
    public enum PaymentStatus
    {
        Pending,
        Authorized,
        Paid,
        Voided,
        Refunded
    }
}