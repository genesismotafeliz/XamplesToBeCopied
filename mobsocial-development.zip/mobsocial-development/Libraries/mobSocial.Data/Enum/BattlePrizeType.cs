﻿namespace mobSocial.Data.Enum
{
    public enum BattlePrizeType
    {
        FixedAmount = 1,
        PercentageAmount = 2,
        FixedProduct = 3,
        Other = 4
    }
}