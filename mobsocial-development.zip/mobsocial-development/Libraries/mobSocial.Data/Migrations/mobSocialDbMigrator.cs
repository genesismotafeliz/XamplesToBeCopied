﻿using System.Data.Entity.Migrations;

namespace mobSocial.Data.Migrations
{
    public class mobSocialDbMigrator : DbMigrator
    {
        public mobSocialDbMigrator(DbMigrationsConfiguration configuration) : base(configuration)
        {
        }
    }
}