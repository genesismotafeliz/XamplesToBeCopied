﻿namespace mobSocial.Data.Entity
{
    public class MappingConfiguration
    {
        public const string TablePrefix = "mobSocial_";
    }
}