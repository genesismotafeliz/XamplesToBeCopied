﻿namespace mobSocial.Data.Entity.Timeline
{
    public class TimelinePostOwnerTypeNames
    {
        public const string Customer = "customer";
    }
}
