﻿using mobSocial.Core.Services;
using mobSocial.Data.Entity.Education;

namespace mobSocial.Services.Education
{
    public interface ISchoolService : IBaseEntityService<School>
    {
        
    }
}