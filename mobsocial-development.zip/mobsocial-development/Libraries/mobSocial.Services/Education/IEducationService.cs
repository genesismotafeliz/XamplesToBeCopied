﻿using mobSocial.Core.Services;

namespace mobSocial.Services.Education
{
    public interface IEducationService : IBaseEntityService<Data.Entity.Education.Education>
    {
    }
}
