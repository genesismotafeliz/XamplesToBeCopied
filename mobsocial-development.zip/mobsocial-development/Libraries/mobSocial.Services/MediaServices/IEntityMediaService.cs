﻿using mobSocial.Core.Services;
using mobSocial.Data.Entity.MediaEntities;

namespace mobSocial.Services.MediaServices
{
    public interface IEntityMediaService : IBaseEntityService<EntityMedia>
    {
        
    }
}