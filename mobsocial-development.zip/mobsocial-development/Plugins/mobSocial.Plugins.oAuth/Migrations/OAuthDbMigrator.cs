﻿using System.Data.Entity.Migrations;

namespace mobSocial.Plugins.OAuth.Migrations
{
    public class OAuthDbMigrator : DbMigrator
    {
        public OAuthDbMigrator(DbMigrationsConfiguration configuration) : base(configuration)
        {
        }
    }
}
