﻿using System.Web.Routing;
using mobSocial.Core.Infrastructure.Mvc;

namespace mobSocial.Plugins.OAuth
{
    public class RouteMap : IRouteMap
    {
        public void MapRoutes(RouteCollection routes)
        {
            
        }
    }
}
