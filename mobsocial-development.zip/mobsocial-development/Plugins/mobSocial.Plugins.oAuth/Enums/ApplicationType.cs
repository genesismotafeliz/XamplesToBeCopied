﻿namespace mobSocial.Plugins.OAuth.Enums
{
    public enum ApplicationType
    {
        NativeFullControl = 0,
        JavaScriptFullControl = 1,
        NativeConfidential = 2,
        JavascriptConfidential = 3
    }
}