﻿namespace mobSocial.Plugins.OAuth.Enums
{
    public enum TokenType
    {
        RefreshToken,
        AccessToken   
    }
}