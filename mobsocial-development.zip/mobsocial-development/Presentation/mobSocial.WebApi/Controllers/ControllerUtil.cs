﻿namespace mobSocial.WebApi.Controllers
{
    public static class ControllerUtil
    {
        public static string MobSocialViewsFolder = "~/Plugins/Widgets.mobSocial/Views/mobSocial/";

        public static string MobSocialPluginsFolder = "~/Plugins/Widgets.mobSocial/";
    }
}
