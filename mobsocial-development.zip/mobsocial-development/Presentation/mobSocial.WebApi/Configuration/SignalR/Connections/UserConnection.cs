﻿namespace mobSocial.WebApi.Configuration.SignalR.Connections
{
    public class UserConnection
    {
        public string UserId { get; set; }

        public string ConnectionId { get; set; }
    }
}