﻿using Microsoft.AspNet.SignalR.Hubs;

namespace mobSocial.WebApi.Configuration.SignalR.Hubs
{
    [HubName("notification")]
    public class NotificationHub : MobSocialHub
    {
    }
}