﻿using Microsoft.AspNet.SignalR;

namespace mobSocial.WebApi.Configuration.SignalR.Hubs
{
    public abstract class MobSocialHub : Hub
    {
    }
}