﻿namespace mobSocial.WebApi.Configuration.Mvc.Results
{
    public interface IApiCallResult
    {
        
    }
}