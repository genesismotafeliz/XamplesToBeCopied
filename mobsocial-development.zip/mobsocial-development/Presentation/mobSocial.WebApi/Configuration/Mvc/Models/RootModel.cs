﻿namespace mobSocial.WebApi.Configuration.Mvc.Models
{
    public abstract class RootModel
    {
       
    }
}