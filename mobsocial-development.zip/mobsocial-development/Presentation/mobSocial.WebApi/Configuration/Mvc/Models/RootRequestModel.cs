﻿namespace mobSocial.WebApi.Configuration.Mvc.Models
{
    public class RootRequestModel : RootModel
    {
         
    }
}