﻿namespace mobSocial.WebApi.Configuration.Mvc.Models
{
    public class RootEntityModel : RootModel
    {
        public int Id { get; set; }
    }
}