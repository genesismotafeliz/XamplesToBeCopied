﻿namespace mobSocial.WebApi.Configuration.Mvc.UI
{
    public enum ResourceRegistrationType
    {
        Script,
        Style
    }
}