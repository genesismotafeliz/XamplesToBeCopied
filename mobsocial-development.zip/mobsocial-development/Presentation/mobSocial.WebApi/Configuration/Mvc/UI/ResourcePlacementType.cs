﻿namespace mobSocial.WebApi.Configuration.Mvc.UI
{
    public enum ResourcePlacementType
    {
        HeadTag,
        BeforeEndBodyTag
    }
}