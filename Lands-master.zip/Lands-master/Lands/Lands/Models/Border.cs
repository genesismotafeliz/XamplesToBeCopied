﻿namespace Lands.Models
{
    public class Border
    {
        public string Code
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }
    }
}
