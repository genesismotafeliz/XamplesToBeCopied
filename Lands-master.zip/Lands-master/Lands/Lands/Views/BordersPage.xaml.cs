﻿namespace Lands.Views
{
    using Xamarin.Forms;
    using Xamarin.Forms.Xaml;

    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class BordersPage : ContentPage
	{
		public BordersPage ()
		{
			InitializeComponent ();
		}
	}
}