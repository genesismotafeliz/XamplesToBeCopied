﻿namespace Lands.Views
{
    using Xamarin.Forms;

    public partial class LandsPage : ContentPage
    {
        public LandsPage()
        {
            InitializeComponent();
        }
    }
}
