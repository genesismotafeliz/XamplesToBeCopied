﻿namespace Twitter.Models
{
    public enum NotificationType
    {
        Retweet,
        FavouriteTweet,
        NewFollower
    }
}
