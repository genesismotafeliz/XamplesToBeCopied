﻿namespace Twitter.App.Models.ViewModels
{
    public class UserViewModel
    {
        public string Username { get; set; }

        public string Email { get; set; }
    }
}