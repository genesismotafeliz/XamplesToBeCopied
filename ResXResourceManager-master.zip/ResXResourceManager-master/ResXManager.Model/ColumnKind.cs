namespace tomenglertde.ResXManager.Model
{
    public enum ColumnKind
    {
        Text,
        Comment
    }
}