﻿namespace tomenglertde.ResXManager.Model
{
    public enum ConfigurationScope
    {
        Global,
        Solution
    }
}