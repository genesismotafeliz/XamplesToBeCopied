﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows.Markup;

[assembly: AssemblyTitle("ResXManager.Model")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.MainAssembly)]

[assembly: XmlnsDefinition("urn:ResXManager.Model", "tomenglertde.ResXManager.Model")]
[assembly: XmlnsDefinition("urn:ResXManager.Model", "tomenglertde.ResXManager.Model.Properties")]


