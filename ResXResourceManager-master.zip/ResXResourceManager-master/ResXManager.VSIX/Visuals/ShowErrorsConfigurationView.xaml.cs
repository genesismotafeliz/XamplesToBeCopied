﻿namespace tomenglertde.ResXManager.VSIX.Visuals
{
    using TomsToolbox.Wpf.Composition;

    /// <summary>
    /// Interaction logic for ShowErrorsConfigurationView.xaml
    /// </summary>
    [DataTemplate(typeof(ShowErrorsConfigurationViewModel))]
    public partial class ShowErrorsConfigurationView
    {
        public ShowErrorsConfigurationView()
        {
            InitializeComponent();
        }
    }
}
