﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Markup;

[assembly: AssemblyTitle("ResXManager.View")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.MainAssembly)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]

[assembly: XmlnsPrefix("urn:ResXManager.View", "view")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View.Properties")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View.Behaviors")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View.ColumnHeaders")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View.Converters")]
[assembly: XmlnsDefinition("urn:ResXManager.View", "tomenglertde.ResXManager.View.Visuals")]


