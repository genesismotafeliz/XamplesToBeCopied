﻿    
 /*  function initSideBarButtons(){
       $("#makepostbtn").click(function () {
           var dialog = $('#postPopup');

           $.get('/Home/_MakePost', {},
              function (responseText, textStatus, XMLHttpRequest) {
                  dialog.html(responseText);
                  dialog.show();
              }
          );
           drawCircleOverlay(userLat, userLong);
       });
   }*/