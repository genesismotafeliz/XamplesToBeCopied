You can find full list of changes in changes.txt

Issue tracker: 		- http://issues.castleproject.org/dashboard

Documentation (work in progress):
Dictionary Adapter	- http://docs.castleproject.org/Tools.Castle-DictionaryAdapter.ashx
DynamicProxy		- http://docs.castleproject.org/Tools.DynamicProxy.ashx
Discusssion group: 	- http://groups.google.com/group/castle-project-users
StackOverflow tags:	- castle-dynamicproxy, castle-dictionaryadapter, castle