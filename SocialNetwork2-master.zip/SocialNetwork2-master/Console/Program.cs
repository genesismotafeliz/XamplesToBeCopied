﻿
using DataAccess.Repositories;
using Domain;
using Services;

namespace Console
{
    class Program
    {
        static void Main(string[] args)
        {
            UserService userSevice = new  UserService(new UnitOfWork());
            User user = new User();
            user.Name = "TestUser";
            //userSevice.Add(user);
            System.Console.WriteLine("ok");
            System.Console.ReadKey();
        }
    }
}
