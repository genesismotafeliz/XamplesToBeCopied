﻿using DataAccess.Repositories;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class UserService
    {
        private IUnitOfWork _unitOfWork;
        public UserService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public void Add(User user)
        {
            user.AvatarIdFoto = 1;
            _unitOfWork.GetRepository<User>().Add(user);
            _unitOfWork.SaveContext();
        }
        public void Delete(int id)
        {
            _unitOfWork.GetRepository<User>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public void Edit(User user)
        {
            _unitOfWork.GetRepository<User>().Update(user);
            _unitOfWork.SaveContext();
        }
        public User Get(int id)
        {
            return _unitOfWork.GetRepository<User>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public List<User> Get()
        {
            return _unitOfWork.GetRepository<User>().Get();
        }
        public User GetUserByApplicationId(string id)
        {
            return _unitOfWork.GetRepository<User>().Get(arg => arg.ApplicationUserId == id).FirstOrDefault();
        }
        public int GetUserIdByApplicationId(string id)
        {
            return _unitOfWork.GetRepository<User>().Get(arg => arg.ApplicationUserId == id).FirstOrDefault().Id;
        }
        public void RequestToAddToFriend(RequestToFriend request)
        {
            _unitOfWork.GetRepository<RequestToFriend>().Add(request);
            _unitOfWork.SaveContext();
        }
        public void DeleteRequest(int id)
        {
            _unitOfWork.GetRepository<RequestToFriend>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public RequestToFriend GetRequestById(int id)
        {
            return _unitOfWork.GetRepository<RequestToFriend>().Get(id);
        }
        public List<RequestToFriend> GetRequestDeclarantByUserId(int userId)
        {            
            return _unitOfWork.GetRepository<RequestToFriend>().Get(arg => arg.AcceptRequestUserId == userId);
        }
        public void AddTofriend(int id)
        {
            RequestToFriend request = new RequestToFriend();
            request = GetRequestById(id);
            Friends friend = new Friends();
            Friends friend2 = new Friends();
            friend.IdUser = request.AcceptRequestUserId;
            friend.IdFriend = request.DeclerantUserId;
            friend2.IdUser = request.DeclerantUserId;
            friend2.IdFriend = request.AcceptRequestUserId;
            _unitOfWork.GetRepository<Friends>().Add(friend);
            _unitOfWork.GetRepository<Friends>().Add(friend2);
            _unitOfWork.GetRepository<RequestToFriend>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public void CanceledRequestToFriend(int id)
        {
            _unitOfWork.GetRepository<RequestToFriend>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public List<User> GetFriendsByUserId(int id)
        {
            List<User> users = new List<User>();
            List<Friends> friends = new List<Friends>();
            friends = _unitOfWork.GetRepository<Friends>().Get(arg => arg.IdUser == id);
            //friends.AddRange(_unitOfWork.GetRepository<Friends>().Get(arg => arg.IdFriend == id));
            foreach(Friends friend in friends)
            {
                //users.AddRange(_unitOfWork.GetRepository<User>().Get(arg => arg.Id == friend.IdUser));
                users.AddRange(_unitOfWork.GetRepository<User>().Get(arg => arg.Id == friend.IdFriend));
            }
            return users;
        }
        public List<User> FindUserByName(string name)
        {
            return _unitOfWork.GetRepository<User>().Get(arg => arg.Name == name);
        }
    }
}
