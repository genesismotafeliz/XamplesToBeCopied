﻿using DataAccess.Repositories;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class WallService
    {
        private IUnitOfWork _unitOfWork;
        public WallService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public void Add(Wall wall)
        {
            _unitOfWork.GetRepository<Wall>().Add(wall);
            _unitOfWork.SaveContext();
        }
        public void Edit(Wall wall)
        {
            _unitOfWork.GetRepository<Wall>().Update(wall);
            _unitOfWork.SaveContext();
        }
        public void Delete(int id)
        {
            _unitOfWork.GetRepository<Wall>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public List<Wall> GetAll()
        {
            return _unitOfWork.GetRepository<Wall>().Get();
        }
        public List<Wall> GetByUserId(int id)
        {
            return _unitOfWork.GetRepository<Wall>().Get(a => a.UserId == id);
        }
    }
}
