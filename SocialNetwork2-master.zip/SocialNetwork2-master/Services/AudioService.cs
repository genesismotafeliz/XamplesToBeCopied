﻿using DataAccess.Repositories;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class AudioService
    {

        private IUnitOfWork _unitOfWork;
        public AudioService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public void AddAudio(Audio Audio)
        {
            _unitOfWork.GetRepository<Audio>().Add(Audio);
            _unitOfWork.SaveContext();
        }
        public void DeleteAudio(int id)
        {
            _unitOfWork.GetRepository<Audio>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public void EditAudio(Audio Audio)
        {
            _unitOfWork.GetRepository<Audio>().Update(Audio);
            _unitOfWork.SaveContext();
        }
        public Audio GetAudioById(int id)
        {
            return _unitOfWork.GetRepository<Audio>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public Audio GetAudio(int id)
        {
            return _unitOfWork.GetRepository<Audio>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public IEnumerable<Audio> GetAudio(string searchText)
        {
            return _unitOfWork.GetRepository<Audio>().Get(arg => arg.Name.Contains(searchText)).ToList();
        }
        public List<Audio> GetAudios()
        {
            return _unitOfWork.GetRepository<Audio>().Get();
        }
        public List<Audio> GetByUserId(int idUser)
        {
            return _unitOfWork.GetRepository<Audio>().Get(arg => arg.IdUser == idUser);
        }

    }
}
