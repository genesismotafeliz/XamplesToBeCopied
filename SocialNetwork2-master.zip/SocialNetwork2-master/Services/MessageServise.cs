﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Migrations;
using DataAccess.Repositories;
using Domain;

namespace Services
{
    public class MessageServise
    {
        private IUnitOfWork _unitOfWork;
        public MessageServise(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public void AddMessage(Message message)
        {
            _unitOfWork.GetRepository<Message>().Add(message);
            _unitOfWork.SaveContext();
        }
        public void DeleteMessage(int id)
        {
            _unitOfWork.GetRepository<Message>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public void EditMessage(Message message)
        {
            _unitOfWork.GetRepository<Message>().Update(message);
            _unitOfWork.SaveContext();
        }
        public Message GetMessageById(int id)
        {
            return _unitOfWork.GetRepository<Message>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public Message GetMessage(int id)
        {
            return _unitOfWork.GetRepository<Message>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public List<Message> GetMessages()
        {
            return _unitOfWork.GetRepository<Message>().Get();
        }
        public List<Message> GetByUserId(int idUser)
        {
            return _unitOfWork.GetRepository<Message>().Get(arg => arg.IdUserGeter == idUser);
        }
        public int GetNumberOfNewMessageByUserId(int id)
        {
            List<Message> message = new List<Message>();
            message = _unitOfWork.GetRepository<Message>().Get(arg => ((arg.IdUserGeter == id)&&(arg.IsRead == false)));
            return message.Count;
        }
        public void IsReadByMessageId(int id)
        {
            Message message = new Message();
            message = _unitOfWork.GetRepository<Message>().Get(id);
            message.IsRead = true;
            _unitOfWork.GetRepository<Message>().Update(message);
            _unitOfWork.SaveContext();
        }
        public void ReadForAllMessInDialog(int userId, int senderId)
        {
            Message message = new Message();
            List<Message> messages = new List<Message>();
            messages = _unitOfWork.GetRepository<Message>().Get(arg => (((arg.IdUserGeter == userId) && (arg.IdUserSender == senderId) && (arg.IsRead == false)) || (arg.IdUserSender == userId) && (arg.IdUserGeter == senderId) && (arg.IsRead == false)));
            foreach(Message messageInList in messages)
            {
                message = messageInList;
                message.IsRead = true;
                _unitOfWork.GetRepository<Message>().Update(message);
            }
            _unitOfWork.SaveContext();
        }
        public List<Message> GetMessageByUserAndSenderId(int userId, int senderId)
        {
            List<Message> message = new List<Message>();
            message = _unitOfWork.GetRepository<Message>().Get(arg => (((arg.IdUserGeter == userId)&&(arg.IdUserSender == senderId)) || (arg.IdUserSender == userId) && (arg.IdUserGeter == senderId)));
            return message;
        }
    }
}
