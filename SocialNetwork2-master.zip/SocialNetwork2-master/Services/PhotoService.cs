﻿using DataAccess.Repositories;
using Domain;
using System.Collections.Generic;
using System.Linq;

namespace Services
{
    public class PhotoService
    {
        private IUnitOfWork _unitOfWork;
        UserService _userSrvice = new UserService(new UnitOfWork());
        public PhotoService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public void Add(Photo photo)
        {
            _unitOfWork.GetRepository<Photo>().Add(photo);
            _unitOfWork.SaveContext();
        }
        public void Delete(int id)
        {
            _unitOfWork.GetRepository<Photo>().Delete(id);
            _unitOfWork.SaveContext();
        }
        public void Edit(Photo photo)
        {
            _unitOfWork.GetRepository<Photo>().Update(photo);
            _unitOfWork.SaveContext();
        }
        public List<Photo> GetAll()
        {
            return _unitOfWork.GetRepository<Photo>().Get();
        }
        public Photo GetPhotoById(int id)
        {
            return _unitOfWork.GetRepository<Photo>().Get(arg => arg.Id == id).FirstOrDefault();
        }
        public List<Photo> GetPhotoByUserId(int id)
        {
            return _unitOfWork.GetRepository<Photo>().Get(arg => arg.IdUser == id);
        }
        public List<Photo> GetPhotoByApplicationUserId(string id)
        {
            return _unitOfWork.GetRepository<Photo>().Get(arg => arg.Id == _userSrvice.GetUserIdByApplicationId(id));
        }
        public List<Photo> GetPhotoByAlbumId(int id)
        {
            return _unitOfWork.GetRepository<Photo>().Get(arg => arg.IdAlbum == id);
        }
    }
}
