﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace SocialNetwork2
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
            name: "UserPage",
            url: "user/{id}",
            defaults: new { controller = "User", action = "ViewUser" },
            constraints: new {id = @"\d{1}" }
            );

            routes.MapRoute(
            name: "UserPage(IdNumber2)",
            url: "user/{id}",
            defaults: new { controller = "User", action = "ViewUser" },
            constraints: new { id = @"\d{2}" }
            );

            routes.MapRoute(
            name: "UserPage(IdNumber3)",
            url: "user/{id}",
            defaults: new { controller = "User", action = "ViewUser" },
            constraints: new { id = @"\d{3}" }
            );


            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );

            routes.MapRoute(
            name: "UserPage(IdNumber4)",
            url: "user/{id}",
            defaults: new { controller = "User", action = "ViewUser" },
            constraints: new { id = @"\d{4}" }
            );
        }
    }
}
