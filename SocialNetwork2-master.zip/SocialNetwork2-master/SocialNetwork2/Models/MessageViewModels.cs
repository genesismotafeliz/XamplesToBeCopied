﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Domain;

namespace SocialNetwork2.Models
{
    public class MessageViewModels
    {
        public User User { get; set; }
        public List<User> UserList { get; set; }
        public Photo Photo { get; set; }
        public List<Message> Messages { get; set; }
    }
}