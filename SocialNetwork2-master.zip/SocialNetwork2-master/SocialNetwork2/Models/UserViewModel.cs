﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialNetwork2.Models
{
    public class UserViewModel
    {
        public User User { get; set; }
        public List<User> UserList { get; set; }
        public Photo Photo { get; set; }
        public List<Photo> ListPhoto { get; set; }
        public int ViewerUser { get; set; } // user which browsing this page
        public List<RequestToFriend> RequestToFriend { get; set; }
        public List<User> Friends { get; set; }
        public List<Wall> Walls { get; set; }
    }
}