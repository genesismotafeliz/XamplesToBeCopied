﻿using DataAccess.Repositories;
using Domain;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Services;
using SocialNetwork2.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SocialNetwork2.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        PhotoService _photoService = new PhotoService(new UnitOfWork());
        UserService _userService = new UserService(new UnitOfWork());
        WallService _wallService = new WallService(new UnitOfWork());
        public ActionResult Index()
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            User user = new User();
            user = _userService.GetUserByApplicationId(applicationUser.Id);
            if (user.Id < 10)
            {
                return RedirectToRoute("UserPage", new { user.Id });
            } else if(user.Id >= 10 && user.Id < 100)
            {
                return RedirectToRoute("UserPage(IdNumber2)", new { user.Id });
            }
            else if (user.Id >= 100 && user.Id < 1000)
            {
                return RedirectToRoute("UserPage(IdNumber3)", new { user.Id });
            }
            else
            {
                return RedirectToRoute("UserPage(IdNumber4)", new { user.Id });
            }
        }
        [HttpGet]
        public ActionResult UploadImage()
        {
            ViewBag.Title = "Upload image";
            return View();
        }
        [HttpPost]
        public ActionResult UploadImage(Photo photo, HttpPostedFileBase uploadImage, FormCollection form)
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            PhotoService photoService = new PhotoService(new UnitOfWork());
            if (ModelState.IsValid && uploadImage != null) {
                var x1 = Convert.ToInt32(double.Parse(form["x1"], new System.Globalization.CultureInfo("en-us")));
                var y1 = Convert.ToInt32(double.Parse(form["y1"], new System.Globalization.CultureInfo("en-us")));
                var x2 = Convert.ToInt32(double.Parse(form["x2"], new System.Globalization.CultureInfo("en-us")));
                var y2 = Convert.ToInt32(double.Parse(form["y2"], new System.Globalization.CultureInfo("en-us")));
                var w = Convert.ToInt32(double.Parse(form["w"], new System.Globalization.CultureInfo("en-us")));
                var h = Convert.ToInt32(double.Parse(form["h"], new System.Globalization.CultureInfo("en-us")));
                

                using (Image OriginalImage = Image.FromStream(uploadImage.InputStream, true, true))
                {
                    using (Bitmap bmp = new Bitmap(w, h))
                    {
                        bmp.SetResolution(OriginalImage.HorizontalResolution, OriginalImage.VerticalResolution);
                        using (Graphics Graphic = Graphics.FromImage(bmp))
                        {
                            Graphic.SmoothingMode = SmoothingMode.AntiAlias;
                            Graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            Graphic.PixelOffsetMode = PixelOffsetMode.HighQuality;
                            Graphic.DrawImage(OriginalImage, new Rectangle(0, 0, w, h), x1, y1, w, h, GraphicsUnit.Pixel);
                            MemoryStream ms = new MemoryStream();
                            bmp.Save(ms, OriginalImage.RawFormat);
                            byte[] imageData = ms.GetBuffer();
                            MemoryStream mstr = new MemoryStream(imageData);
                            Image img = (Bitmap)Image.FromStream(mstr);
                            float dpi = 72;
                            Int32 width = Convert.ToInt32((float)img.Width * dpi / img.HorizontalResolution);
                            Int32 height = Convert.ToInt32((float)img.Height * dpi / img.VerticalResolution);
                            Bitmap bmp1 = new System.Drawing.Bitmap(width, height);
                            bmp1.SetResolution(img.HorizontalResolution, img.VerticalResolution);
                            using (Graphics g = Graphics.FromImage(bmp1))
                            {
                                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                                g.SmoothingMode = SmoothingMode.HighQuality;

                                Rectangle src = new Rectangle(0, 0, img.Width, img.Height);
                                Rectangle dst = new Rectangle(0, 0, bmp1.Width, bmp1.Height);
                                g.DrawImage(img, dst, src, GraphicsUnit.Pixel);
                                MemoryStream mst = new MemoryStream();
                                bmp1.Save(mst, img.RawFormat);
                                photo.ImageByte = mst.GetBuffer();
                                photo.IdAlbum = 1;
                                photo.IdUser = _userService.GetUserIdByApplicationId(applicationUser.Id);
                                photoService.Add(photo);
                            }
                        }
                    }
                }
            }

            return RedirectToAction("Album");
        }
        public ActionResult Album()
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            UserViewModel model = new UserViewModel();
            model.ListPhoto = _photoService.GetPhotoByUserId(_userService.GetUserIdByApplicationId(applicationUser.Id));
            ViewBag.Title = "My album";
            return View(model);
        }
        public ActionResult Details(int id)
        {
            UserViewModel model = new UserViewModel();
            model.Photo = _photoService.GetPhotoById(id);
            if (model.Photo != null)
                return PartialView(model.Photo);
            return HttpNotFound();
        }
        [HttpGet]
        public ActionResult SelectImageToAvarat(int Id)
        {
            UserViewModel model = new UserViewModel();
            PhotoService photoService = new PhotoService(new UnitOfWork());
            model.Photo = photoService.GetPhotoById(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult SelectImageToAvarat(int id, FormCollection form)
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            PhotoService photoService = new PhotoService(new UnitOfWork());
            Photo photo = new Photo();
            if (ModelState.IsValid)
            {
                var x1 = Convert.ToInt32(double.Parse(form["x1"], new System.Globalization.CultureInfo("en-us")));
                var y1 = Convert.ToInt32(double.Parse(form["y1"], new System.Globalization.CultureInfo("en-us")));
                var x2 = Convert.ToInt32(double.Parse(form["x2"], new System.Globalization.CultureInfo("en-us")));
                var y2 = Convert.ToInt32(double.Parse(form["y2"], new System.Globalization.CultureInfo("en-us")));
                var w = Convert.ToInt32(double.Parse(form["w"], new System.Globalization.CultureInfo("en-us")));
                var h = Convert.ToInt32(double.Parse(form["h"], new System.Globalization.CultureInfo("en-us")));

                Photo selectPhoto = photoService.GetPhotoById(id);
                MemoryStream mstream = new MemoryStream(selectPhoto.ImageByte);
                using (Image OriginalImage = Image.FromStream(mstream))
                {
                    using (Bitmap bmp = new Bitmap(w, h))
                    {
                        bmp.SetResolution(OriginalImage.HorizontalResolution, OriginalImage.VerticalResolution);
                        using (Graphics Graphic = Graphics.FromImage(bmp))
                        {
                            Graphic.SmoothingMode = SmoothingMode.AntiAlias;
                            Graphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            Graphic.PixelOffsetMode = PixelOffsetMode.HighQuality;
                            Graphic.DrawImage(OriginalImage, new Rectangle(0, 0, w, h), x1, y1, w, h, GraphicsUnit.Pixel);
                            MemoryStream ms = new MemoryStream();
                            bmp.Save(ms, OriginalImage.RawFormat);
                            byte[] imageData = ms.GetBuffer();
                            MemoryStream mstr = new MemoryStream(imageData);
                            Image img = (Bitmap)Image.FromStream(mstr);
                            Bitmap bmp1 = new System.Drawing.Bitmap(200, 200);              // задаемо розрішення картинки
                            bmp1.SetResolution(img.HorizontalResolution, img.VerticalResolution);
                            using (Graphics g = Graphics.FromImage(bmp1))
                            {
                                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                                g.SmoothingMode = SmoothingMode.HighQuality;

                                Rectangle src = new Rectangle(0, 0, img.Width, img.Height);
                                Rectangle dst = new Rectangle(0, 0, bmp1.Width, bmp1.Height);
                                g.DrawImage(img, dst, src, GraphicsUnit.Pixel);
                                MemoryStream mst = new MemoryStream();
                                bmp1.Save(mst, img.RawFormat);
                                photo.ImageByte = mst.GetBuffer();
                                photo.IdAlbum = 0;
                                photo.IdUser = _userService.GetUserIdByApplicationId(applicationUser.Id);
                                photoService.Add(photo);
                            }
                        }
                    }
                }
            }
            
            User user = new Domain.User();
            user = _userService.GetUserByApplicationId(applicationUser.Id);
            List<Photo> avatarPhotos = photoService.GetPhotoByAlbumId(0);            
            user.AvatarIdFoto = avatarPhotos.Last().Id;
            _userService.Edit(user);
            return RedirectToAction("index");
        }
        //[Route("user/{id:int}")]
        public ActionResult ViewUser(int id)
        {
            UserViewModel model = new UserViewModel();
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            model.User = _userService.Get(id);
            model.ViewerUser = _userService.GetUserIdByApplicationId(applicationUser.Id);
            model.Walls = _wallService.GetByUserId(id);
            model.Walls.Reverse();
            ViewBag.Title = model.User.Name + " " + model.User.LastName;
            if (_userService.Get(id).AvatarIdFoto != 0)
            {
                model.Photo = _photoService.GetPhotoById(_userService.Get(id).AvatarIdFoto);
            }
            else
            {
                model.Photo = _photoService.GetPhotoById(7);
            }
            
            return View(model);
        }
        public ActionResult ViewUserPhotos(int id)
        {
            UserViewModel model = new UserViewModel();
            model.ListPhoto = _photoService.GetPhotoByUserId(id);
            ViewBag.Title = "Photo " + _userService.Get(id).Name + _userService.Get(id).LastName;
            return View(model);
        }
        public ActionResult AllUser()
        {
            UserViewModel model = new UserViewModel();
            model.UserList = _userService.Get();
            return View(model);
        }
        public ActionResult Friends()
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            UserViewModel model = new UserViewModel();
            model.Friends = _userService.GetFriendsByUserId(_userService.GetUserIdByApplicationId(applicationUser.Id));
            model.RequestToFriend = _userService.GetRequestDeclarantByUserId(_userService.GetUserIdByApplicationId(applicationUser.Id));
            ViewBag.Title = "My friends";
            return View(model);
        }        
        public ActionResult RequestToAddToFriend(int id)
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            RequestToFriend request = new RequestToFriend();
            request.AcceptRequestUserId = id;
            request.DeclerantUserId = _userService.GetUserIdByApplicationId(applicationUser.Id);
            _userService.RequestToAddToFriend(request);
            return RedirectToAction("Index");
        }
        public ActionResult AcceptRequestToFriend(int id)
        {
            _userService.AddTofriend(id);
            return RedirectToAction("Index");
        }
        public ActionResult CancelRequestToFriend(int id)
        {
            _userService.CanceledRequestToFriend(id);
            return RedirectToAction("Index");
        }
        public ActionResult FindUserByName(string name)
        {
            UserViewModel model = new UserViewModel();
            model.UserList = _userService.FindUserByName(name);
            return PartialView(model);
        }
        public ActionResult FindUserByNameFast(string name)
        {
            UserViewModel model = new UserViewModel();
            model.UserList = _userService.FindUserByName(name);
            return PartialView(model);
        }
        [HttpGet]
        public ActionResult AddNoteToWall(int userGeterId)
        {
            ViewBag.UserGeter = userGeterId;
            return View();
        }
        [HttpPost]
        public ActionResult AddNoteToWall(Wall wall, HttpPostedFileBase uploadImage)
        {            
            wall.IdOfTypeNote = 1;
            wall.DateOfCreate = DateTime.Now;
            if (uploadImage != null)
            {
                byte[] imageData = null;
                // считываем переданный файл в массив байтов
                using (var binaryReader = new BinaryReader(uploadImage.InputStream))
                {
                    imageData = binaryReader.ReadBytes(uploadImage.ContentLength);
                }
                // установка массива байтов
                wall.ImageNote = imageData;
            } else
            {
                wall.ImageNote = null;
            }
            _wallService.Add(wall);
            return Content("True");
            //return RedirectToAction("ViewUser","User",new { id = wall.UserId});
        }
        public ActionResult DeteleFromWall(int id)
        {
            _wallService.Delete(id);
            return RedirectToAction("Index");
        }
        public ActionResult WallPartial()
        {
            UserViewModel model = new UserViewModel();
            model.Walls = _wallService.GetByUserId(4);
            return PartialView(model);
        }
        [HttpGet]
        public ActionResult EditUser(int id)
        {
            Domain.User user = new Domain.User();
            user = _userService.Get(id);
            return View(user);
        }
        [HttpPost]
        public ActionResult EditUser(User user)
        {
            _userService.Edit(user);
            return View();
        }
    }
}