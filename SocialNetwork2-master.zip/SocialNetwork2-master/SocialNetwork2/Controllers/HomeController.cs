﻿using Microsoft.AspNet.Identity.Owin;
using System.Web;
using System.Web.Mvc;

namespace SocialNetwork2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "User");
            }
            else
            {
                return View();
            }
        }
        public ActionResult About()
        {
            return PartialView();
        }
        public ActionResult Contact()
        {
            return PartialView();
        }
    }
}