﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataAccess;
using Domain;
using SocialNetwork2.Models;
using Microsoft.AspNet.Identity;
using Services;
using DataAccess.Repositories;
using System.IO;
using Microsoft.AspNet.Identity.Owin;

namespace SocialNetwork2.Controllers
{
    public class AudiosController : Controller
    {
        UserService _userService = new UserService(new UnitOfWork());
        AudioService _audioService = new AudioService(new UnitOfWork());

        [HttpGet]
        public ActionResult Index()
        {
            return View(_audioService.GetAudios().ToList());
        }

        [HttpPost]
        public ActionResult Index(string _searchText)
        {
            var v1 = _audioService.GetAudio(1);
            var v2 = _audioService.GetAudio(2);
            v1.FileByte = v2.FileByte;
            _audioService.EditAudio(v1);
            if (!String.IsNullOrEmpty(_searchText))
            {
                return View(_audioService.GetAudio(_searchText).ToList());
            }
            return View(_audioService.GetAudios().ToList());
        }

        // GET: Audios/Create
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Audio audio, HttpPostedFileBase uploadAudio)
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            if (ModelState.IsValid)
            {
                audio.IdUser = _userService.GetUserIdByApplicationId(applicationUser.Id);
                if (uploadAudio != null)
                {
                    byte[] audioFile = null;
                    using (var binaryReader = new BinaryReader(uploadAudio.InputStream))
                    {
                        audioFile = binaryReader.ReadBytes(uploadAudio.ContentLength);
                    }
                    audio.FileByte = audioFile;
                    string _tempName = uploadAudio.FileName.ToString();
                    audio.Name = _tempName.Substring(0, _tempName.IndexOf("."));
                    audio.Extension = Path.GetExtension(uploadAudio.FileName).TrimStart('.');
                    audio.Artists = "No Artists";
                    audio.Genre = "Other";
                }
                else
                {
                    audio.FileByte = null;
                }
                _audioService.AddAudio(audio);
                return RedirectToAction("Index");
            }
            return View(audio);
        }

        // GET: Audios/Edit/5
        public ActionResult Edit(int id)
        {
            Audio audio = _audioService.GetAudioById(id);
            if (audio != null)
            {
                return PartialView("~/Views/Audios/partial/_editAudio.cshtml", audio);
            }

            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Audio audio)
        {
            if (ModelState.IsValid)
            {
                Audio _audioForUpdate = _audioService.GetAudioById(audio.Id);
                _audioForUpdate.Name = audio.Name;
                _audioForUpdate.Artists = audio.Artists;
                _audioForUpdate.Genre = audio.Genre;
                _audioForUpdate.Lyrics = audio.Lyrics;
                _audioService.EditAudio(_audioForUpdate);
                return RedirectToAction("Index");
            }
            return PartialView("~/Views/Audios/partial/_editAudio.cshtml", audio);
        }

        // GET: Audios/Delete/5
        public ActionResult Delete(int id)
        {
            Audio audio = _audioService.GetAudioById(id);
            if (audio == null)
            {
                return HttpNotFound();
            }
            return PartialView("~/Views/Audios/partial/_deleteAudio.cshtml", audio);
        }

        // POST: Audios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _audioService.DeleteAudio(id);
            return RedirectToAction("Index");
        }
        public ActionResult GetFileForPlay(int id)
        {
            var currentAudio = _audioService.GetAudioById(id);
            var file = currentAudio.FileByte;
            return File(file, "audio/" + currentAudio.Extension);
        }

    }
}
