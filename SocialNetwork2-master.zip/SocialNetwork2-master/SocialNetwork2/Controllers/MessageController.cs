﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Migrations;
using DataAccess.Repositories;
using Domain;
using Microsoft.AspNet.Identity;
using Services;
using SocialNetwork2.Models;
using Microsoft.AspNet.Identity.Owin;

namespace SocialNetwork2.Controllers
{
    [Authorize]
    public class MessageController : Controller

    {
        UserService _userService = new UserService(new UnitOfWork());
        MessageServise _messageServise = new MessageServise(new UnitOfWork());
        // GET: Message
        public ActionResult Index()
        {
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            MessageViewModels models=new MessageViewModels();
            MessageServise messageServise=new MessageServise(new UnitOfWork());
            List<Message> messageList = new List<Message>();
            List<User> userList = new List<User>();
            List<Message> messageListForForeach = new List<Message>();
            messageListForForeach = messageServise.GetByUserId(_userService.GetUserIdByApplicationId(applicationUser.Id));
            messageListForForeach.Reverse();
            foreach(var message in messageListForForeach)
            {
                if(userList.FirstOrDefault(arg => arg.Id == message.IdUserSender) == null)
                {
                    messageList.Add(message);
                    userList.Add(_userService.Get(message.IdUserSender));
                }
            }
            models.Messages = messageList;
            //models.Messages.Reverse();
            ViewBag.Title = "My message";
            return View(models);
        }
        [HttpGet]
        public ActionResult AddMessage(int idUser, int idMessage)
        {
            ViewBag.Title = "New message";
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            TempData["form"] = idUser;
            MessageViewModels model = new MessageViewModels();
            if (idMessage != 0)
            {
                //_messageServise.IsReadByMessageId(idMessage);
                Message message = new Message();
                message = _messageServise.GetMessage(idMessage);
                _messageServise.ReadForAllMessInDialog(_userService.GetUserIdByApplicationId(applicationUser.Id), message.IdUserSender);
                ViewBag.Message = _messageServise.GetMessageByUserAndSenderId(_userService.GetUserIdByApplicationId(applicationUser.Id), message.IdUserSender);
            }
            return View();
        }
        [HttpPost]
        public ActionResult AddMessage(Message message)
        {
            TempData.Remove("form");
            ApplicationUserManager userManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            ApplicationUser applicationUser = userManager.FindByEmail(User.Identity.Name);
            message.IdUserSender = _userService.GetUserIdByApplicationId(applicationUser.Id);
            message.DataSend = DateTime.Now;
            _messageServise.AddMessage(message);
            return RedirectToAction("Index");
        }
        public ActionResult DeleteMessage(int idMessage)
        {
            _messageServise.DeleteMessage(idMessage);
            return RedirectToAction("Index");
        }
    }
}