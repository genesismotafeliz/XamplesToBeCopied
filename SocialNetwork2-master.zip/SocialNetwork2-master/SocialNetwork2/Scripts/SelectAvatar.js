﻿$(function () {
    
    var oImage = document.getElementById('cropbox1');
    // destroy Jcrop if it is existed
    if (typeof jcrop_api != 'undefined') {
        jcrop_api.destroy();
        jcrop_api = null;
        $('#preview').width(oImage.naturalWidth);
        $('#preview').height(oImage.naturalHeight);
    }

    //Auto selected area
    var w = 500;
    var h = 500;
    var W = oImage.naturalWidth;
    var H = oImage.naturalHeight;
    var x = W / 2 - w / 2;
    var y = H / 2 - h / 2;
    var x1 = x + w;
    var y1 = y + h;

    // initialize Jcrop
    $('#cropbox1').Jcrop({
        minSize: [W/5, W/5], // min crop size
        aspectRatio: 1, // keep aspect ratio 1:1
        bgFade: true, // use fade effect
        bgColor: 'white',
        addClass: 'jcrop-light',
        bgOpacity: .6, // fade opacity
        boxWidth: 500, //Maximum width you want for your bigger images
        boxHeight: 500, //Maximum Height for your bigger images
        setSelect: [x, y, x1, y1],
        onChange: updateInfo,
        onSelect: updateInfo,
        onRelease: clearInfo
    }, function () {

        // use the Jcrop API to get the real image size
        var bounds = this.getBounds();
        boundx = bounds[0];
        boundy = bounds[1];

        // Store the Jcrop API in the jcrop_api variable
        jcrop_api = this;
    });
 
});

// update info by cropping (onChange and onSelect events handler)
function updateInfo(e) {

    var oImage = document.getElementById('cropbox1');
    var W = oImage.naturalWidth;
    var H = oImage.naturalHeight;

    $('#x1').val(e.x);
    $('#y1').val(e.y);
    $('#x2').val(e.x2);
    $('#y2').val(e.y2);
    $('#w').val(e.w);
    $('#h').val(e.h);

    var rx = 200 / e.w;
    var ry = 200 / e.h;

    $('#preview').css({
        width: Math.round(rx * W) + 'px',
        height: Math.round(ry * H) + 'px',
        marginLeft: '-' + Math.round(rx * e.x) + 'px',
        marginTop: '-' + Math.round(ry * e.y) + 'px'
    });
    
};

// clear info by cropping (onRelease event handler)
function clearInfo() {
    $('#w').val('');
    $('#h').val('');
};
