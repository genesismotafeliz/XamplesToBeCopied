﻿$(document).ready(function () {
    var top_show = 200; // В каком положении полосы прокрутки начинать показ кнопки "Наверх"
    var delay = 500; // Задержка прокрутки
    var bottom = $("footer").outerHeight(true);
    var l = $(".nav-stacked a:first").offset();
    var up = $("#top");
    up.offset(function (i, val) {
        return { left: l.left };
    });
    up.css("bottom", bottom);
    var w = $(".nav-stacked a:first").outerWidth(true);
    var h = $(".nav-stacked a:first").outerHeight(true);
    up.width(w);
    up.height(h);


    $(window).scroll(function () { // При прокрутке попадаем в эту функцию
        /* В зависимости от положения полосы прокрукти и значения top_show, скрываем или открываем кнопку "Наверх" */
        if ($(this).scrollTop() > top_show) $('#top').fadeIn();
        else $('#top').fadeOut();
    });
    $('#top').click(function () { // При клике по кнопке "Наверх" попадаем в эту функцию
        /* Плавная прокрутка наверх */
        $('body, html').animate({
            scrollTop: 0
        }, delay);
    });
});

$(document).on('click', '#SearchFast', function (e) {
    e.preventDefault();
    var msg = $('form').serialize();
    $("#results-fast").html('<p id="load"> Loading... </p>');
    $.ajax({
        type: "POST",
        url: "/User/FindUserByNameFast",
        data: msg,
        success: function (result) {
            if (result != "True") {
                $("#results-fast").html(result)
            } else {
                $("#results-fast").html('<p id="load"> Not found! </p>')
            }
        },
        traditional: true
    });
});
$(document).on('click', '#close', function () {
    $("#searchFastResults").remove();
});