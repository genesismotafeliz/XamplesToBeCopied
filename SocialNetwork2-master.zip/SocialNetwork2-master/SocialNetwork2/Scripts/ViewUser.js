﻿var isopen = false;
$('#action').click(function () {
    if (isopen) {
        $('.user-action').hide();
        isopen = false;
    } else {
        $(this).next().show();
        isopen = true;
    }    
    return false;
});
$('body, .user-action a').click(function () {
    $('.user-action').hide();
    isopen = false;
});




(function (b) { b.fn.autoResize = function (f) { var a = b.extend({ onResize: function () { }, animate: !0, animateDuration: 150, animateCallback: function () { }, extraSpace: 20, limit: 1E3 }, f); this.filter("textarea").each(function () { var d = b(this).css({ "overflow-y": "hidden", display: "block" }), f = d.height(), g = function () { var c = {}; b.each(["height", "width", "lineHeight", "textDecoration", "letterSpacing"], function (b, a) { c[a] = d.css(a) }); return d.clone().removeAttr("id").removeAttr("name").css({ position: "absolute", top: 0, left: -9999 }).css(c).attr("tabIndex", "-1").insertBefore(d) }(), h = null, e = function () { g.height(0).val(b(this).val()).scrollTop(1E4); var c = Math.max(g.scrollTop(), f) + a.extraSpace, e = b(this).add(g); h !== c && (h = c, c >= a.limit ? b(this).css("overflow-y", "") : (a.onResize.call(this), a.animate && "block" === d.css("display") ? e.stop().animate({ height: c }, a.animateDuration, a.animateCallback) : e.height(c))) }; d.unbind(".dynSiz").bind("keyup.dynSiz", e).bind("keydown.dynSiz", e).bind("change.dynSiz", e) }); return this } })(jQuery);

// инициализация
jQuery(function () {
    jQuery('textarea').autoResize();
});


// button upload
(function ($) {
    $(function () {
        $('.btn-file').each(function () {
            var self = this;
            $('input[type=file]', this).change(function () {
                // remove existing file info
                $(self).next().remove();
                // get value
                var value = $(this).val();
                // get file name
                var fileName = value.substring(value.lastIndexOf('/') + 1);
                // get file extension
                var fileExt = fileName.split('.').pop().toLowerCase();
                // append file info
                $('<span><i class="icon-file icon-' + fileExt + '"></i> ' + fileName + '</span>').insertAfter(self);
            });
        });
    });
})(jQuery);
function onFileSelect(e) {
    var
      f = e.target.files[0], // Первый выбранный файл
      reader = new FileReader,
      place = document.getElementById("preview") // Сюда покажем картинку
    ;
    reader.readAsDataURL(f);
    reader.onload = function (e) { // Как только картинка загрузится
        place.src = e.target.result;
    }
};
document.querySelector("input[type=file]").addEventListener("change", onFileSelect, false);



$(document).on('click', 'input[value=Send]', function (e) {
    var msg = $('#add-to-wall').serialize();
    $.ajax({
        type: "POST",
        url: "/User/AddNoteToWall",
        data: msg,
        success: function (result) {
            if (result == "True") {
                location.reload();
            } else {
                alert("O-no");
            }
        },
        traditional: true
    });
});
