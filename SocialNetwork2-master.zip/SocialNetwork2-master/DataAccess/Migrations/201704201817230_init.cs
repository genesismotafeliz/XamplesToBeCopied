namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Albums",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Deskription = c.String(),
                        IdUser = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Photos",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ImageByte = c.Binary(),
                        IdUser = c.Int(nullable: false),
                        IdAlbum = c.Int(nullable: false),
                        Name = c.String(),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Friends",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        IdUser = c.Int(nullable: false),
                        IdFriend = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Messages",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        IdUserSender = c.Int(nullable: false),
                        IdUserGeter = c.Int(nullable: false),
                        Text = c.String(),
                        DataSend = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RequestToFriends",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DeclerantUserId = c.Int(nullable: false),
                        AcceptRequestUserId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        LastName = c.String(),
                        Town = c.String(),
                        AvatarIdFoto = c.Int(nullable: false),
                        ApplicationUserId = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Walls",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.Int(nullable: false),
                        IdOfTypeNote = c.Int(nullable: false),
                        Header = c.String(),
                        Text = c.String(),
                        ImageNote = c.Binary(),
                        DateOfCreate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Walls");
            DropTable("dbo.Users");
            DropTable("dbo.RequestToFriends");
            DropTable("dbo.Messages");
            DropTable("dbo.Friends");
            DropTable("dbo.Photos");
            DropTable("dbo.Albums");
        }
    }
}
