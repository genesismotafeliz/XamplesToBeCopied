namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class addAudio : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Audios",
                c => new
                {
                    Id = c.Int(nullable: false, identity: true),
                    Name = c.String(),
                    FileByte = c.Binary(),
                    Extension = c.String(),
                    Artists = c.String(),
                    Genre = c.String(),
                    Lyrics = c.String(),
                    IdUser = c.Int(nullable: true),
                })
                .PrimaryKey(t => t.Id);

        }

        public override void Down()
        {
            DropTable("dbo.Audios");
        }
    }
}
