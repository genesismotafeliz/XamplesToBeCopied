namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class err : DbMigration
    {
        public override void Up()
        {
            DropTable("dbo.Audios");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.Audios",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        FileByte = c.Binary(),
                        Extension = c.String(),
                        IdUser = c.Int(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
    }
}
