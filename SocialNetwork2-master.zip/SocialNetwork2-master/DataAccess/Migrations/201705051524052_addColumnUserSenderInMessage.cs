namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addColumnUserSenderInMessage : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Walls", "UserSender", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Walls", "UserSender");
        }
    }
}
