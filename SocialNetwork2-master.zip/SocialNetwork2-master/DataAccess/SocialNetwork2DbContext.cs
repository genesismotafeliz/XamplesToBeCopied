﻿using Domain;
using System.Data.Entity;

namespace DataAccess
{
    public class SocialNetwork2DbContext : DbContext
    {
        public SocialNetwork2DbContext()
            : base("name = DefaultConnection4")
        {
            var instance = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
        }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Photo> Foto { get; set; }
        public virtual DbSet<Album> Album { get; set; }
        public virtual DbSet<Message> Message { get; set; }
        public virtual DbSet<RequestToFriend> RequestToFriend { get; set; }
        public virtual DbSet<Friends> Friends { get; set; }
        public virtual DbSet<Wall> Wall { get; set; }
        public virtual DbSet<Audio> Audio { get; set; }
    }
}
