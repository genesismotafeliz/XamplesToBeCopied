﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Audio : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [Display(Name = "Audio file")]
        public byte[] FileByte { get; set; }
        public string Artists { get; set; }
        public string Genre { get; set; }
        public string Lyrics { get; set; }
        public string Extension { get; set; }
        public int? IdUser { get; set; }
    }
}
