﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Wall : IEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int UserSender { get; set; }
        public int IdOfTypeNote { get; set; }
        public string Header{ get; set; }
        public string Text { get; set; }
        public byte[] ImageNote { get; set; }
        public DateTime DateOfCreate{ get; set; }
    }
}
