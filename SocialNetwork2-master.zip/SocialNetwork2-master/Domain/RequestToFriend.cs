﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class RequestToFriend : IEntity
    {
        public int Id { get; set; }
        public int DeclerantUserId {get;set;} //подає заявку на добавлення в друзі(заявник)
        public int AcceptRequestUserId { get; set; } //приймає заявку на добавлення в друзі(приймач)
    }
}
