﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UT.SL.Model
{
    public class ProgressModel
    {
        public string Title { get; set; }
        public double TopicValue { get; set; }
        public double MyValue { get; set; }
        public int Rank { get; set; }
        public string Color { get; set; }
    }
}
