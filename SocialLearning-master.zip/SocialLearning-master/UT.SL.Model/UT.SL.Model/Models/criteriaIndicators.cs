﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UT.SL.Model
{
    public class criteriaIndicators
    {
        public List<UT.SL.Data.LINQ.PeerAssessmentIndicator> paiList { get; set; }
        public UT.SL.Data.LINQ.PeerAssessmentCriteria criteria { get; set; }
    }
}
