﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UT.SL.Model
{
    public class AgentInfo
    {
        public string IP { get; set; }
        public string Browser { get; set; }
        public string OS { get; set; }
        public bool IsMobile { get; set; }
        public string ScreenRes { get; set; }
    }
}
