﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UT.SL.Model
{
    public class CategoryCourseModel
    {
        public int CategoryId { get; set; }
        public string CategoryTitle { get; set; }
        public string CourseTitle { get; set; }
    }
}
