USE [u643_SLRN]
GO

ALTER SCHEMA dbo 
    TRANSFER u643_admin.UserSoActProfile
GO


