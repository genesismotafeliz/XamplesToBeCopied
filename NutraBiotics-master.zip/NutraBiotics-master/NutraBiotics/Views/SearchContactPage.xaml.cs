﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NutraBiotics.Views
{
    public partial class SearchContactPage : ContentPage
    {
        public SearchContactPage()
        {
            InitializeComponent();
        }
    }
}
