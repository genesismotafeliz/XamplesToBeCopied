﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NutraBiotics.Views
{
    public partial class NewOrderDetailPage : ContentPage
    {
        public NewOrderDetailPage()
        {
            InitializeComponent();
        }
    }
}
