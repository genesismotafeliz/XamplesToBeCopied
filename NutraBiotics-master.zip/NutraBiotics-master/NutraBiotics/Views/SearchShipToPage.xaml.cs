﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NutraBiotics.Views
{
    public partial class SearchShipToPage : ContentPage
    {
        public SearchShipToPage()
        {
            InitializeComponent();
        }
    }
}
