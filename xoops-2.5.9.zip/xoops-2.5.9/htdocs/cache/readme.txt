Just kept for backward compatibility.
It is recommended to point the folder to xoops_data/caches/smarty_cache/ with a symbolic link (symlink).