XOOPS 2.5.9

The XOOPS Development Team is pleased to announce the release of XOOPS 2.5.9. This version includes
fixes and enhancements, security updates, PHP 7.1 compatibility.

Download XOOPS 2.5.9 from GitHub: https://github.com/XOOPS/XoopsCore25/releases


How to contribute
-----------------------------------
Bug reports and feature requests: https://github.com/XOOPS/XoopsCore25/issues
Patch and enhancement: https://github.com/XOOPS/XoopsCore25/blob/master/CONTRIBUTING.md
Documentation: https://www.gitbook.com/book/xoops/xoops-documentation-process/details
Support Forums: http://xoops.org/modules/newbb/

XOOPS Development Team
2017
