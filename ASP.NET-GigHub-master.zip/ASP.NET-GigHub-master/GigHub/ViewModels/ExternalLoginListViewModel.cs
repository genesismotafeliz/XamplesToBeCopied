namespace GigHub.ViewModels
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}