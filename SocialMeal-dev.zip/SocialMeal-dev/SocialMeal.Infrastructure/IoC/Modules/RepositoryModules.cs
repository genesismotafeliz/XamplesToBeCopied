﻿using System.Reflection;
using Autofac;
using SocialMeal.Core.Repositories;

namespace SocialMeal.Infrastructure.IoC.Modules
{
    public class RepositoryModules: Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            var assembly = typeof(RepositoryModules)
                .GetTypeInfo()
                .Assembly;

            builder.RegisterAssemblyTypes(assembly)
                .Where(x => x.IsAssignableTo<IRepository>())
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();
        }
    }
}
