﻿using Autofac;
using Microsoft.Extensions.Configuration;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.IoC.Modules;
using SocialMeal.Infrastructure.Mappers;
using SocialMeal.Infrastructure.Repositories;

namespace SocialMeal.Infrastructure.IoC
{
    public class ContainerModule : Autofac.Module
    {
        private readonly IConfiguration _configuration;

        public ContainerModule(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterInstance(AutoMapperConfig.Initialize())
                .SingleInstance();
            builder.RegisterModule<RepositoryModules>();
            builder.RegisterModule<ServiceModules>();
            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>();
        }
    }
}
