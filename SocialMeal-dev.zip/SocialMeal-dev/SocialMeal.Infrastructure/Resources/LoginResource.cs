﻿using System.ComponentModel.DataAnnotations;

namespace SocialMeal.Infrastructure.Resources
{
    public class LoginResource
    {
        [Required]
        [StringLength(255)]
        public string Email { get; set; }

        [Required]
        [StringLength(20)]
        public string Password { get; set; }

        [Required]
        [StringLength(255)]
        public string DeviceId { get; set; }

        [Required]
        [StringLength(255)]
        public string DeviceName { get; set; }
    }
}
