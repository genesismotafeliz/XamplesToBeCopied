﻿using System;
using System.ComponentModel.DataAnnotations;
using SocialMeal.Core.Domain;

namespace SocialMeal.Infrastructure.Resources
{
    public class NewEventResource
    {
        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public decimal Price { get; set; }

        [Required]
        public AddressResource Address { get; set; }

        [Required]
        public FoodType FoodType { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        public int MembersAmount { get; set; }
    }
}
