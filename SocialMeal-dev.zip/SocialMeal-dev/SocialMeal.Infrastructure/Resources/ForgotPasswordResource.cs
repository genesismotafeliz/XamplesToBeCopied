﻿using System.ComponentModel.DataAnnotations;

namespace SocialMeal.Infrastructure.Resources
{
    public class ForgotPasswordResource
    {
        [Required]
        [StringLength(255)]
        [EmailAddress]
        public string Email { get; set; }
    }
}
