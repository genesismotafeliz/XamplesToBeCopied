﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SocialMeal.Infrastructure.Resources
{
    public class RatingResource
    {
        [Required]
        public Guid UserId { get; set; }

        [Required]
        [Range(0,5)]
        public int Rate { get; set; }

        [Required]
        public DateTime Date { get; set; }
    }
}
