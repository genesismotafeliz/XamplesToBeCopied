﻿namespace SocialMeal.Infrastructure.Resources
{
    public class TokenResource
    {
        public string Token { get; set; }
        public long Expiry { get; set; }
    }
}
