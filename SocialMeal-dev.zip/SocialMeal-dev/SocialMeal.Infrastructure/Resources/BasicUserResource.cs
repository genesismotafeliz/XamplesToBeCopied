﻿using System;
using System.Collections.Generic;
using SocialMeal.Core.Domain;

namespace SocialMeal.Infrastructure.Resources
{
    public class BasicUserResource
    {
        public Guid Id { get; set; }

        public string Email { get; set; }

        public string FirstName { get; set; }

        public string Surname { get; set; }

        public string Thumbnail { get; set; }

        public string Description { get; set; }

        public Role Role { get; set; }

        public double Rating { get; set; }

        public List<FavouriteFoodResource> FavouriteFoodType { get; set; }
    }
}
