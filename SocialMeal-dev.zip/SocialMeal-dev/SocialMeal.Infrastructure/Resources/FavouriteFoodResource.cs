﻿using SocialMeal.Core.Domain;

namespace SocialMeal.Infrastructure.Resources
{
    public class FavouriteFoodResource
    {
        public FoodType Name { get; set; }
    }
}
