﻿using System.ComponentModel.DataAnnotations;
using SocialMeal.Infrastructure.Attributes;

namespace SocialMeal.Infrastructure.Resources
{
    public class ResetPasswordResource
    {
        [Required]
        [Password]
        [StringLength(255)]
        public string Password { get; set; }

        [Required]
        [StringLength(255)]
        public string Code { get; set; }
    }
}
