﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SocialMeal.Core.Domain;

namespace SocialMeal.Infrastructure.Resources
{
    public class EventResource
    {
        public Guid Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public decimal Price { get; set; }

        [Required]
        public AddressResource Address { get; set; }

        [Required]
        public FoodType FoodType { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        public int MembersAmount { get; set; }

        public Guid OwnerId { get; set; }

        public List<BasicUserResource> Participants { get; set; }
    }
}
