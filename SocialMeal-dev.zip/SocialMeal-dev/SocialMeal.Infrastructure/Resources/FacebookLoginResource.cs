﻿using System.ComponentModel.DataAnnotations;

namespace SocialMeal.Infrastructure.Resources
{
    public class FacebookLoginResource
    {
        [Required]
        [StringLength(255)]
        public string facebookToken { get; set; }

        [Required]
        [StringLength(255)]
        public string DeviceId { get; set; }

        [Required]
        [StringLength(255)]
        public string DeviceName { get; set; }
    }
}
