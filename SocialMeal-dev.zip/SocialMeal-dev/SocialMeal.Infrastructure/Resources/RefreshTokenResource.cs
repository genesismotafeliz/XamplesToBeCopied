﻿using System.ComponentModel.DataAnnotations;

namespace SocialMeal.Infrastructure.Resources
{
    public class RefreshTokenResource
    {
        [Required]
        [StringLength(255)]
        public string RefreshToken { get; set; }
    }
}
