﻿using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Mappers
{
    public class RatingMapperConfig : Profile
    {
        public RatingMapperConfig()
        {
            CreateMap<Rating, RatingResource>()
                .ForMember(x => x.UserId, opt => opt.MapFrom(u => u.RatedUser));

            CreateMap<RatingResource, Rating>()
                .ForMember(x => x.RatedUserId, opt => opt.Ignore())
                .ForMember(x => x.RatingUserId, opt => opt.Ignore());
        }
    }
}
