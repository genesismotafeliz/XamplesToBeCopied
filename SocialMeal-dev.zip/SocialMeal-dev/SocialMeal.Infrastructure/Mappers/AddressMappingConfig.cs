﻿using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Mappers
{
    public class AddressMappingConfig : Profile
    {
        public AddressMappingConfig()
        {
            CreateMap<Address, AddressResource>();

            CreateMap<AddressResource, Address>();
        }
    }
}
