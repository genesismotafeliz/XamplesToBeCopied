﻿using System;
using System.Linq;
using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Mappers
{
    public class UserMapperConfig : Profile
    {
        private Random _random = new Random();
        public UserMapperConfig()
        {
            CreateMap<ProfileResource, User>();

            CreateMap<User, BasicUserResource>()
                .ForMember(x => x.Rating, opt => opt.ResolveUsing(z => z.MyRatings.Count > 0 ? z.MyRatings.Average(rating => rating.Rate) : 0));

            CreateMap<EventUser, BasicUserResource>()
                .ForMember(x => x.Rating,
                    opt => opt.MapFrom(eu =>
                        eu.User.MyRatings.Count > 0 ? eu.User.MyRatings.Average(rating => rating.Rate) : 0))
                .ForMember(x => x.FavouriteFoodType, opt => opt.MapFrom(eu => eu.User.FavouriteFoodType))
                .ForMember(x => x.Description, opt => opt.MapFrom(eu => eu.User.Description))
                .ForMember(x => x.FirstName, opt => opt.MapFrom(eu => eu.User.FirstName))
                .ForMember(x => x.Id, opt => opt.MapFrom(eu => eu.User.Id))
                .ForMember(x => x.Role, opt => opt.MapFrom(eu => eu.User.Role))
                .ForMember(x => x.Surname, opt => opt.MapFrom(eu => eu.User.Surname))
                .ForMember(x => x.Email, opt => opt.MapFrom(eu => eu.User.Email))
                .ForMember(x => x.Thumbnail, opt => opt.MapFrom(eu => eu.User.Thumbnail));

            CreateMap<FacebookUserResource, RegisterResource>()
                .ForMember(x => x.Surname, opt => opt.MapFrom(fu => fu.LastName))
                .ForMember(x => x.Password, opt => opt.MapFrom(fu => fu.Email.Insert(0, _random.Next(0,1000).ToString())));
        }
    }
}
