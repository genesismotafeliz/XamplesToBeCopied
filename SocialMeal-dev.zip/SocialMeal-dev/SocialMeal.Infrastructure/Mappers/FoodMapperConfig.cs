﻿using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Mappers
{
    public class FoodMapperConfig : Profile
    {
        public FoodMapperConfig()
        {
            CreateMap<FavouriteFood, FavouriteFoodResource>();

            CreateMap<FavouriteFoodResource, FavouriteFood>();
        }
    }
}
