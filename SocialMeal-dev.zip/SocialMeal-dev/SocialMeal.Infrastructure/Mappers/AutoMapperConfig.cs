﻿using AutoMapper;

namespace SocialMeal.Infrastructure.Mappers
{
    public static class AutoMapperConfig
    {
        public static IMapper Initialize()
            => new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new FoodMapperConfig());
                    cfg.AddProfile(new AddressMappingConfig());
                    cfg.AddProfile(new RatingMapperConfig());
                    cfg.AddProfile(new UserMapperConfig());
                    cfg.AddProfile(new EventMapperConfig());
                })
                .CreateMapper();
    }
}
