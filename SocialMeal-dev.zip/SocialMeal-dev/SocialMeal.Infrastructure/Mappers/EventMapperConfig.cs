﻿using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Mappers
{
    public class EventMapperConfig : Profile
    {
        public EventMapperConfig()
        {
            CreateMap<Event, EventResource>()
                .ForMember(x => x.Participants, opt => opt.MapFrom(e => e.Participants));

            CreateMap<EventResource, Event>();

            CreateMap<NewEventResource, Event>();
        }
    }
}
