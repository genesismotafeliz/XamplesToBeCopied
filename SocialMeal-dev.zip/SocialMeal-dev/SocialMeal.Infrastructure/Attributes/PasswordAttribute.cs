﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace SocialMeal.Infrastructure.Attributes
{
    public class PasswordAttribute : ValidationAttribute
    {
        private static readonly Regex PasswordRegex = new Regex($@"^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9!@#\$%^&*()_+|]{{6,}}$");

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is string)
            {
                if (!PasswordRegex.Match(value.ToString()).Success)
                {
                    return new ValidationResult("Invalid Password");
                }
                return ValidationResult.Success;
            }
            return new ValidationResult("Password attribut is used in invalid element");
        }
    }
}
