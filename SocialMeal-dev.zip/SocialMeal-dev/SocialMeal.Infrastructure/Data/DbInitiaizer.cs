﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.IoC;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Data
{
    public class DbInitiaizer
    {
        public Random Random { get; } = new Random();
        public IAccountService _accountService { get; set; }
        public IRatingService _ratingService { get; set; } 
        public IEventService _eventService { get; set; }

        public async Task Initialize(SocialMealContext context, IAccountService accountService, IRatingService ratingService, IEventService eventService)
        {
            _accountService = accountService;
            _ratingService = ratingService;
            _eventService = eventService;

            context.Database.EnsureCreated();

            if (context.Users.Any())
            {
                return;
            }

            await Seed(context);
        }

        private async Task Seed(SocialMealContext context)
        {
            using (context)
            {
                var builder = new ContainerBuilder();
                builder.RegisterInstance(context).As<SocialMealContext>();
                builder.RegisterModule(new ContainerModule(null));
                var container = builder.Build();

                using (var scope = container.BeginLifetimeScope())
                {
                    //var accountService = scope.Resolve<AccountService>();
                    //var ratingService = scope.Resolve<IRatingService>();
                    //var eventService = scope.Resolve<IEventService>();
                    var addres = new AddressResource
                    {
                        City = "City",
                        Street = "Stret",
                        Number = "Number"
                    };

                    //creating 10 new users
                    for (var i = 0; i < 9; i++)
                    {
                        var user = new RegisterResource
                        {
                            FirstName = $"User_{i}_name",
                            Surname = $"User_{i}_surname",
                            Password = "Test123$",
                            Email = $"user{i}@test.com"
                        };

                        await _accountService.RegisterAsync(user, Role.User);
                    }
                    context.SaveChanges();

                    var users = context.Users.ToList();
                    //creating random rating for those users
                    for (int i = 0; i < 5; i++)
                    {
                        await _ratingService.RateUser(users[i].Id,
                            new RatingResource {Date = DateTime.UtcNow, Rate = Random.Next(0, 5), UserId =  users[i+1].Id});
                    }

                    for (int i = 0; i < 5; i++)
                    {
                        await _eventService.AddEventAsync(users[i].Id,
                            new NewEventResource
                            {
                                FoodType = FoodType.French,
                                Name = $"event{i}",
                                Date = DateTime.UtcNow.AddDays(i+1),
                                Description = $"event{i} description",
                                Price = i + 1,
                                MembersAmount = i + 2,
                                Address = addres
                            });
                    }
                    context.SaveChanges();
                }
            }
        }
    }
}
