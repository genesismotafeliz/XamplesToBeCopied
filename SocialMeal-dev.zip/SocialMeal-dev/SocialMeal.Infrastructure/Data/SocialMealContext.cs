﻿ using Microsoft.EntityFrameworkCore;
using SocialMeal.Core.Domain;

namespace SocialMeal.Infrastructure.Data
{
    public class SocialMealContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Session> Sessions { get; set; }
        public DbSet<Rating> Ratings { get; set; }
        public DbSet<FavouriteFood> FavouriteFood { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<EventUser> EventUsers { get; set; }

        public SocialMealContext(DbContextOptions<SocialMealContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            SetupUser(modelBuilder);
            SetupSession(modelBuilder);
            SetupRating(modelBuilder);
            SetupFavouriteFood(modelBuilder);
            SetupEvents(modelBuilder);
            SetupAddress(modelBuilder);
            SetupEventUsers(modelBuilder);
        }

        private void SetupEventUsers(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventUser>()
                .HasKey(x => new {x.UserId, x.EventId});

            modelBuilder.Entity<EventUser>()
                .HasOne(x => x.User)
                .WithMany(u => u.Events)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<EventUser>()
                .HasOne(x => x.Event)
                .WithMany(u => u.Participants)
                .HasForeignKey(x => x.EventId)
                .OnDelete(DeleteBehavior.Restrict);
        }

        private void SetupAddress(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Address>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Address>()
                .Property(x => x.City)
                .HasMaxLength(50)
                .IsRequired();

            modelBuilder.Entity<Address>()
                .Property(x => x.Street)
                .HasMaxLength(50)
                .IsRequired();
        }

        private void SetupEvents(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Event>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Event>()
                .Property(x => x.Name)
                .HasMaxLength(50)
                .IsRequired();

            modelBuilder.Entity<Event>()
                .Property(x => x.Date)
                .IsRequired();

            modelBuilder.Entity<Event>()
                .Property(x => x.FoodType)
                .IsRequired();

            modelBuilder.Entity<Event>()
                .Property(x => x.Description)
                .HasMaxLength(500);

            modelBuilder.Entity<Event>()
                .Property(x => x.MembersAmount)
                .IsRequired();

            modelBuilder.Entity<Event>()
                .HasOne(x => x.Owner)
                .WithMany(u => u.MyEvents);
        }

        private void SetupFavouriteFood(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FavouriteFood>()
                .HasKey(f => f.Id);

            modelBuilder.Entity<FavouriteFood>()
                .Property(f => f.Name)
                .IsRequired();
        }

        private void SetupRating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Rating>()
                .HasKey(r => new { r.RatedUserId, r.RatingUserId});

            modelBuilder.Entity<Rating>()
                .Property(r => r.Rate)
                .IsRequired();

            modelBuilder.Entity<Rating>()
                .HasOne(x => x.RatedUser)
                .WithMany(u => u.MyRatings)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Rating>()
                .HasOne(x => x.RatingUser)
                .WithMany(u => u.SendedRatings)
                .OnDelete(DeleteBehavior.Restrict);
        }

        private void SetupSession(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Session>()
                .HasKey(s => new {s.UserId, s.DeviceId});
        }

        private void SetupUser(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique(true);

            modelBuilder.Entity<User>()
                .Property(u => u.Email)
                .IsRequired()
                .HasMaxLength(255);

            modelBuilder.Entity<User>()
                .Property(u => u.Password)
                .IsRequired()
                .HasMaxLength(255);

            modelBuilder.Entity<User>()
                .Property(u => u.FirstName)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<User>()
                .Property(u => u.Surname)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<User>()
                .Property(u => u.Salt)
                .HasMaxLength(255);

            modelBuilder.Entity<User>()
                .Property(u => u.Thumbnail)
                .HasMaxLength(255);

            modelBuilder.Entity<User>()
                .Property(u => u.Description)
                .HasMaxLength(500);

            modelBuilder.Entity<User>()
                .Property(u => u.ResetCode)
                .HasMaxLength(100);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Sessions)
                .WithOne(s => s.User);

            modelBuilder.Entity<User>()
                .HasMany(u => u.FavouriteFoodType)
                .WithOne(f => f.User);
        }
    }
}
