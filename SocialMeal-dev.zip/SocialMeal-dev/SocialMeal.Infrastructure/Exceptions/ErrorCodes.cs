﻿namespace SocialMeal.Infrastructure.Exceptions
{
    public static class ErrorCodes
    {
        public static string InvalidEmail => "invalid_email";
        public static string UserNotExist => "user_not_exist";
        public static string InvalidCredentials => "invalid_credentials";
        public static string InvalidRefreshToken => "invalid_refresh_token";
        public static string InvalidResetCode => "invalid_reset_code";
        public static string InvalidRating => "invalid_rating";
        public static string EventNotExist => "event_not_exust";
        public static string NoPermision => "no_permission";
        public static string EventExist => "event_exist";
        public static string InvalidDate => "invalid_date";
        public static string InvalidPrice => "invalid_price";
        public static string InvalidEventMembers => "invalid_price";
        public static string InvalidFacebookToken => "invalid_facebook_token";
        public static string InvalidAvatar => "invalid_avatar";
    }
}
