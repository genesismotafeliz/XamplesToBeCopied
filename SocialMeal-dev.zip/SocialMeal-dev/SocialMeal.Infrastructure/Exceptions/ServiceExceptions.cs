﻿using System;
using SocialMeal.Core.Exceptions;

namespace SocialMeal.Infrastructure.Exceptions
{
    public class ServiceExceptions : SocialMealException
    {
        protected ServiceExceptions()
        {
        }

        public ServiceExceptions(string code) : base(code)
        {
        }

        public ServiceExceptions(string message, params object[] args) 
            : base(string.Empty, message, args)
        {
        }

        public ServiceExceptions(string code, string message, params object[] args) 
            : base(null, code, message, args)
        {
        }

        public ServiceExceptions(Exception innerException, string message, params object[] args) 
            : base(innerException, string.Empty, message, args)
        {
        }

        public ServiceExceptions(Exception innerException, string code, string message, params object[] args) 
            : base(code, string.Format(message, args), innerException)
        {
        }
    }
}
