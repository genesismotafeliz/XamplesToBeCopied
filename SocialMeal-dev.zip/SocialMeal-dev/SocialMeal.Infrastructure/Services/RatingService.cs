﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Services
{
    public class RatingService : IRatingService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public RatingService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task RateUser(Guid ratingUserId, RatingResource ratingResource)
        {
            var ratingUser = await GetUserAsync(ratingUserId, false);
            var ratedUser = await GetUserAsync(ratingResource.UserId, true);
            if (ratingUser.Id == ratedUser.Id)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidRating, "It is forbidden to rating yourself");
            }

            var rate = ratedUser.MyRatings.FirstOrDefault(r => r.RatingUserId == ratingUserId);
            if (rate == null)
            {
                rate = new Rating(ratingResource.Rate, ratingResource.Date);
                ratingUser.SendedRatings.Add(rate);
                ratedUser.MyRatings.Add(rate);
            }
            else
            {
                rate.Date = ratingResource.Date;
                rate.Rate = ratingResource.Rate;
            }

            await _unitOfWork.CompleteAsync();
        }

        private async Task<User> GetUserAsync(Guid id, bool isRated)
        {
            var user = await _unitOfWork.Users.GetAsync(id);
            if (user != null) return user;

            var destiny = isRated ? "Rated" : "Rating";
            throw new ServiceExceptions(ErrorCodes.UserNotExist, $"{destiny} user not exist");
        }
    }
}
