﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Services
{
    public class ProfileService : IProfileService
    {
        private readonly IImageService _imageService;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ProfileService(IImageService imageService, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _imageService = imageService;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<BasicUserResource> GetProfile(Guid userId)
        {
            var user = await GetUserFromDataBase(userId);

            return _mapper.Map<User, BasicUserResource>(user);
        }


        public async Task UpdateProfile(Guid userId, ProfileResource profile)
        {
            var user = await _unitOfWork.Users.GetAsync(userId);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.UserNotExist, "User not exist");
            }

            _mapper.Map(profile, user);
            user.FavouriteFoodType.Clear();
            foreach (var food in profile.FavouriteFoodTypes)
            {
                user.FavouriteFoodType.Add(new FavouriteFood{Name = food});
            }

            await _unitOfWork.CompleteAsync();
        }

        public async Task<string> UpdateAvatar(Guid userId, IFormFile avatar)
        {
            var user = await GetUserFromDataBase(userId);
            if (avatar == null || avatar.Length == 0)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidAvatar, "Avatar not exist");
            }
            if (avatar.Length > 5120000)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidAvatar, "Avatar can not be bigger than 5120000 bytes");
            }

            string photo;
            try
            {
                using (var imageStream = avatar.OpenReadStream())
                {
                    photo = await _imageService.SetThumbnails(imageStream);
                }
            }
            catch (ArgumentException)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidAvatar, "Invalid file format");
            }

            if (string.IsNullOrEmpty(photo))
            {
                var userHasThumbnail = user.Thumbnail != null;
                var oldThumbnail = user.Thumbnail;
                user.SetThumbnail(photo);

                await _unitOfWork.CompleteAsync();

                if (userHasThumbnail)
                {
                    await _imageService.DeletePhotoIfExist(oldThumbnail);
                }
            }
            return user.Thumbnail;

        }

        private async Task<User> GetUserFromDataBase(Guid userId)
        {
            var user = await _unitOfWork.Users.GetAsync(userId);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.UserNotExist, "User not exist");
            }
            return user;
        }
    }
}
