﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Extensions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Services
{
    public class AccountService : IAccountService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IEncrypter _encrypter;
        private readonly IJwtHandler _jwtHandler;
        private readonly IEmailService _emailService;
        private readonly IFacebookService _facebookService;
        private readonly IMapper _mapper;

        public AccountService(IUnitOfWork unitOfWork, IEncrypter encrypter, IJwtHandler jwtHandler
            , IEmailService emailService, IFacebookService facebookService, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _encrypter = encrypter;
            _jwtHandler = jwtHandler;
            _emailService = emailService;
            _facebookService = facebookService;
            _mapper = mapper;
        }

        public async Task RegisterAsync(RegisterResource resource, Role role)
        {
            await CheckIfEmailIsAvailable(resource.Email);

            var salt = _encrypter.GetSalt(resource.Password);
            var hash = _encrypter.GetHash(resource.Password, salt);

            var user = new User(Guid.NewGuid(), resource.Email, hash, resource.FirstName, resource.Surname, salt, role);

            await _unitOfWork.Users.AddAsync(user);
            await _unitOfWork.CompleteAsync();
        }

        public async Task<AuthorizationTokensResource> LoginAsync(LoginResource resource)
        {
            var user = await _unitOfWork.Users.GetAsync(resource.Email);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidCredentials, "Invalid credentials");
            }

            var hash = _encrypter.GetHash(resource.Password, user.Salt);
            if (user.Password != hash)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidCredentials, "Invalid credentials");
            }

            return await CreateAccessTokens(user, resource.DeviceId, resource.DeviceName);
        }

        public async Task<AuthorizationTokensResource> FacebookLoginAsync(FacebookLoginResource facebookLoginResource)
        {
            if (string.IsNullOrEmpty(facebookLoginResource.facebookToken))
            {
                throw new ServiceExceptions(ErrorCodes.InvalidFacebookToken, "Token is null or empty");
            }

            var facebookUser = await _facebookService.GetUserFromFacebookAsync(facebookLoginResource.facebookToken);
            var domainUser = await _unitOfWork.Users.GetAsync(facebookUser.Email);
            if (domainUser == null)
            {
                await RegisterAsync(_mapper.Map<RegisterResource>(facebookUser), Role.User);
                domainUser = await _unitOfWork.Users.GetAsync(facebookUser.Email);
            }

            return await CreateAccessTokens(domainUser, facebookLoginResource.DeviceId,
                facebookLoginResource.DeviceName);
        }

        private async Task<AuthorizationTokensResource> CreateAccessTokens(User user, string deviceId,
            string deviceName)
        {
            var accessToken = _jwtHandler.CreateAccessToken(user.Id, user.Email, user.Role);
            var refreshToken = _jwtHandler.CreateRefreshToken(user.Id);
            SetRefreshToken(user, refreshToken, deviceId, deviceName);

            user.IncreaseLoginNumber();
            await _unitOfWork.CompleteAsync();

            return new AuthorizationTokensResource { AccessToken = accessToken, RefreshToken = refreshToken };
        }

        public async Task<TokenResource> RefreshToken(Guid userId, string refreshToken)
        {
            var user = await _unitOfWork.Users.GetAsync(userId);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidRefreshToken, "Invalid refresh token");
            }

            var tokenHash = _encrypter.GetHash(refreshToken, user.Salt);
            var session = user.Sessions.FirstOrDefault(s => s.Token == tokenHash);
            if (session == null || session.IsExpired())
            {
                throw new ServiceExceptions(ErrorCodes.InvalidRefreshToken, "invalid refresh token");
            }
            session.Refresh();
            await _unitOfWork.CompleteAsync();

            return _jwtHandler.CreateAccessToken(user.Id, user.Email, user.Role);
        }

        public async Task ForgotPassword(string email)
        {
            var user = await _unitOfWork.Users.GetAsync(email);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidEmail, $"User with email: {email} not exist");
            }

            var resetCode = Guid.NewGuid().ToString();
            user.SetResetCode(resetCode);

            await _unitOfWork.CompleteAsync();
            await _emailService.SendResetPasswordLink(email, resetCode);
        }

        public async Task ResetPassword(string code, string password)
        {
            var user = await _unitOfWork.Users.GetByResetCodeAsync(code);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidResetCode, "Invalid reset code");
            }
            if (user.ResetCodeCreateTime < DateTime.UtcNow.AddMinutes(-20))
            {
                throw new ServiceExceptions(ErrorCodes.InvalidResetCode, "Reset code expired");
            }

            var salt = _encrypter.GetSalt(password);
            var hash = _encrypter.GetHash(password, salt);

            user.SetPassword(hash);
            user.SetSalt(salt);
            user.ClearResetCode();
            await _unitOfWork.CompleteAsync();
        }

        private async Task CheckIfEmailIsAvailable(string email)
        {
            var user = await _unitOfWork.Users.GetAsync(email);
            if (user != null)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidEmail, $"Email: {email} is taken");
            }
        }

        private void SetRefreshToken(User user, TokenResource refreshToken, string deviceId, string deviceName)
        {
            var tokenHash = _encrypter.GetHash(refreshToken.Token, user.Salt);
            var expires = DateTimeExtensions.ToDateTime(refreshToken.Expiry);

            var session = user.Sessions.SingleOrDefault(s => s.DeviceId == deviceId);
            if (session == null)
            {
                user.Sessions.Add(new Session(deviceId, deviceName, tokenHash, expires));
            }
            else
            {
                session.UpdateToken(tokenHash, expires);
            }
        }
    }
}
