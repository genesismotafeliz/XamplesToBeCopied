﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;


        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task SendResetPasswordLink(string email, string code)
        {
            const string subject = "Reset password link";
            var content = _configuration["EmailSettings:ResetLink"] + code;
            await SendEmail(email, subject, content);
        }

        private async Task SendEmail(string email, string subject, string content)
        {
            using (var client = new SmtpClient())
            {
                var credential = new NetworkCredential
                {
                    UserName = _configuration["EmailSettings:Email"],
                    Password = _configuration["EmailSettings:Password"]
                };

                client.Credentials = credential;
                client.Host = _configuration["EmailSettings:Host"];
                client.Port = int.Parse(_configuration["EmailSettings:Port"]);
                client.EnableSsl = true;

                using (var message = new MailMessage())
                {
                    message.To.Add(new MailAddress(email));
                    message.From = new MailAddress(_configuration["EmailSettings:Email"]);
                    message.Subject = subject;
                    message.Body = content;
                    client.Send(message);
                }
            }
            await Task.CompletedTask;
        }
    }
}
