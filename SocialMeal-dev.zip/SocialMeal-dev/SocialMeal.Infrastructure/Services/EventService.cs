﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.Infrastructure.Services
{
    public class EventService : IEventService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public EventService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<List<EventResource>> GetUserEventsAsync(Guid userId)
        {
            var user = await GetUserFromDataBaseAsync(userId);
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.OwnerId == user.Id);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetAllEventsAsync()
        {
            var events = await _unitOfWork.Events.GetAllAsync();

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task AddEventAsync(Guid userId, NewEventResource resource)
        {
            var user = await GetUserFromDataBaseAsync(userId);
            await CheckIfEventExistAsync(resource, user);
            var eventDomain = CreateNewEventDomainObject(resource);
            user.MyEvents.Add(eventDomain);

            await AddNewEventUserRecordToDataBaseAsync(user, eventDomain);
        }

        private async Task CheckIfEventExistAsync(NewEventResource resource, User user)
        {
            var eventObject = await _unitOfWork.Events.GetEventsAsync(x =>
                x.OwnerId == user.Id && x.Name == resource.Name && x.Date == resource.Date);
            if (eventObject.Count != 0)
            {
                throw new ServiceExceptions(ErrorCodes.EventExist, "This event already exist");
            }
        }

        private Event CreateNewEventDomainObject(NewEventResource resource)
        {
            var address = _mapper.Map<Address>(resource.Address);
            var eventDomain = new Event(resource.Name, resource.Date, resource.FoodType, resource.MembersAmount, address);
            eventDomain.SetPrice(resource.Price);
            eventDomain.SetDescription(resource.Description);

            return eventDomain;
        }

        private async Task AddNewEventUserRecordToDataBaseAsync(User user, Event eventDomani)
        {
            var eventUser = new EventUser(user, eventDomani);
            _unitOfWork.Events.AddEventUser(eventUser);

            await _unitOfWork.CompleteAsync();
        }

        public async Task EditEventAsync(Guid userId, EventResource resource)
        {
            var user = await GetUserFromDataBaseAsync(userId);
            var result = await GetEventFromDataBaseAsync(resource.Id);
            if (result.OwnerId != user.Id)
            {
                throw new ServiceExceptions(ErrorCodes.NoPermision, "You dont have permision to modify this event");
            }

            result.SetName(resource.Name);
            result.SetDate(resource.Date);
            result.SetFoodType(resource.FoodType);
            result.SetMembersAmount(resource.MembersAmount);
            result.SetDescription(resource.Description);
            result.SetPrice(resource.Price);

            await _unitOfWork.CompleteAsync();
        }

        public async Task<EventResource> GetEventAsync(Guid id)
        {
            var result = await GetEventFromDataBaseAsync(id);

            return _mapper.Map<EventResource>(result);
        }

        public async Task<List<EventResource>> GetEventsByDateAsync(DateTime? from, DateTime? to)
        {
            ValidateDate(from, to);
            var dateFrom = from ?? DateTime.MinValue;
            var dateTo = to ?? DateTime.MaxValue;
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.Date >= dateFrom && x.Date <= dateTo);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetEventsByOwer(Guid ownerId)
        {
            await GetUserFromDataBaseAsync(ownerId);
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.OwnerId == ownerId);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetEventsByPrice(decimal? minPrice, decimal? maxPrice)
        {
            ValidatePrice(minPrice, maxPrice);
            var minimal = minPrice ?? 0;
            var maximal = maxPrice ?? decimal.MaxValue;
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.Price > minimal && x.Price < maximal);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetEventsByName(string name)
        {
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.Name == name);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetEventsByFoodType(FoodType foodType)
        {
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.FoodType == foodType);

            return _mapper.Map<List<EventResource>>(events);
        }

        public async Task<List<EventResource>> GetEventsByMemberAmout(int? minMembers, int? maxMembers)
        {
            ValidateMembersAmount(minMembers, maxMembers);
            var minimal = minMembers ?? 0;
            var maximal = maxMembers ?? int.MaxValue;
            var events = await _unitOfWork.Events.GetEventsAsync(x => x.MembersAmount > minimal && x.MembersAmount < maximal);

            return _mapper.Map<List<EventResource>>(events);
        }

        private static void ValidateDate(DateTime? from, DateTime? to)
        {
            if (to < from)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidDate, "Date to can not be earlier than from");
            }
        }

        private static void ValidatePrice(decimal? minPrice, decimal? maxPrice)
        {
            if (maxPrice < minPrice)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidPrice, "Maximal price can not be lower than minimal");
            }
        }

        private static void ValidateMembersAmount(int? minMembers, int? maxMembers)
        {
            if (maxMembers < minMembers)
            {
                throw new ServiceExceptions(ErrorCodes.InvalidEventMembers, "Maximum amount of members can not be smaller than minimal");
            }
        }

        private async Task<User> GetUserFromDataBaseAsync(Guid id)
        {
            var user = await _unitOfWork.Users.GetAsync(id);
            if (user == null)
            {
                throw new ServiceExceptions(ErrorCodes.UserNotExist, "User not exist");
            }
            return user;
        }

        private async Task<Event> GetEventFromDataBaseAsync(Guid id)
        {
            var result = await _unitOfWork.Events.GetAsync(id);
            if (result == null)
            {
                throw new ServiceExceptions(ErrorCodes.EventNotExist, $"Event with id:{id} not exist");
            }
            return result;
        }
    }
}
