﻿using System;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IJwtHandler
    {
        TokenResource CreateAccessToken(Guid userId, string email, Role role);
        TokenResource CreateRefreshToken(Guid userId);
    }
}
