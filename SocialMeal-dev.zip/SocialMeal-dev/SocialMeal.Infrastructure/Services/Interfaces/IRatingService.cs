﻿using System;
using System.Threading.Tasks;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IRatingService : IService
    {
        Task RateUser(Guid ratingUserId, RatingResource ratingResource);
    }
}
