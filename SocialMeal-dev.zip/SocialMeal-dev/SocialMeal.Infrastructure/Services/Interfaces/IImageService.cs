﻿using System.IO;
using System.Threading.Tasks;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IImageService : IService
    {
        Task<string> SetThumbnails(Stream imageStream);
        Task DeletePhotoIfExist(string photoPath);
    }
}
