﻿namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IAuthService : IService
    {
    }
}
