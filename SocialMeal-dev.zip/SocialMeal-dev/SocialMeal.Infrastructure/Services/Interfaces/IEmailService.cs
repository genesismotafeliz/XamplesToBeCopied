﻿using System.Threading.Tasks;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IEmailService : IService
    {
        Task SendResetPasswordLink(string email, string code);
    }
}
