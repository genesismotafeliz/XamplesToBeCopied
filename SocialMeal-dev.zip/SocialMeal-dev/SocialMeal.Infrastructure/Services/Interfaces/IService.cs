﻿namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IService
    {
    }
}
