﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IEventService : IService
    {
        Task<List<EventResource>> GetUserEventsAsync(Guid userId);
        Task<List<EventResource>> GetAllEventsAsync();
        Task AddEventAsync(Guid userId, NewEventResource resource);
        Task EditEventAsync(Guid userId, EventResource resource);
        Task<EventResource> GetEventAsync(Guid id);
        Task<List<EventResource>> GetEventsByDateAsync(DateTime? from, DateTime? to);
        Task<List<EventResource>> GetEventsByOwer(Guid ownerId);
        Task<List<EventResource>> GetEventsByPrice(decimal? minPrice, decimal? maxPrice);
        Task<List<EventResource>> GetEventsByName(string name);
        Task<List<EventResource>> GetEventsByFoodType(FoodType foodType);
        Task<List<EventResource>> GetEventsByMemberAmout(int? minMembers, int? maxMembers);
    }
}