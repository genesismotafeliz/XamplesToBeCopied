﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IProfileService : IService
    {
        Task<BasicUserResource> GetProfile(Guid userId);
        Task UpdateProfile(Guid userId, ProfileResource profile);
        Task<string> UpdateAvatar(Guid userId, IFormFile avatar);
    }
}
