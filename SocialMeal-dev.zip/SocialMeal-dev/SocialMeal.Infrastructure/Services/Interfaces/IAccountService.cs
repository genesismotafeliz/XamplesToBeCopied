﻿using System;
using System.Threading.Tasks;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;

namespace SocialMeal.Infrastructure.Services.Interfaces
{
    public interface IAccountService : IService
    {
        Task RegisterAsync(RegisterResource resource, Role role);
        Task<AuthorizationTokensResource> LoginAsync(LoginResource resource);
        Task<TokenResource> RefreshToken(Guid userId, string refreshToken);
        Task ForgotPassword(string email);
        Task ResetPassword(string code, string password);
        Task<AuthorizationTokensResource> FacebookLoginAsync(FacebookLoginResource facebookToken);
    }
}
