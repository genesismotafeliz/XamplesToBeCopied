﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Data;

namespace SocialMeal.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly SocialMealContext _context;

        public UserRepository(SocialMealContext context)
        {
            _context = context;
        }

        public async Task AddAsync(User user)
        {
            _context.Users.Add(user);
            await Task.CompletedTask;
        }

        public async Task<User> GetAsync(Guid id)
            => await _context.Users.Include(u => u.Sessions)
                .Include(u => u.FavouriteFoodType)
                .Include(u => u.MyRatings)
                .Include(u => u.SendedRatings)
                .FirstOrDefaultAsync(u => u.Id == id);

        public async Task<User> GetAsync(string email)
            => await _context.Users.Include(u => u.Sessions)
                .Include(u => u.FavouriteFoodType)
                .FirstOrDefaultAsync(u => u.Email == email);

        public async Task<User> GetByResetCodeAsync(string resetCode)
            => await _context.Users.FirstOrDefaultAsync(u => u.ResetCode == resetCode);

        public async Task<List<User>> GetAllAsync(string email)
            => await _context.Users.Include(u => u.Sessions).Where(u => u.Email == email).ToListAsync();

        public async Task RemoveAsync(Guid id)
        {
            var user = await GetAsync(id);
            if (user != null)
            {
                _context.Users.Remove(user);
            }
            await Task.CompletedTask;
        }
    }
}
