﻿using System;
using System.Threading.Tasks;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Data;

namespace SocialMeal.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SocialMealContext _context;
        public IUserRepository Users { get; }
        public IEventRepository Events { get; }

        public UnitOfWork(SocialMealContext context)
        {
            _context = context;
            Users = new UserRepository(_context);
            Events = new EventRepository(_context);
        }

        public async Task CompleteAsync()
        {
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }


    }
}
