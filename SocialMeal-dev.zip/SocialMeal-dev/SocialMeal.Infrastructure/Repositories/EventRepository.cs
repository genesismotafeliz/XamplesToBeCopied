﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Data;

namespace SocialMeal.Infrastructure.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly SocialMealContext _context;

        public EventRepository(SocialMealContext context)
        {
            _context = context;
        }

        public void AddAsync(Event eventObject)
        {
            _context.Events.Add(eventObject);
        }

        public async Task<Event> GetAsync(Guid id)
        {
            var events = await GetAllAsync();

            return events.FirstOrDefault(x => x.Id == id);
        } 

        public async Task<List<Event>> GetAllAsync()
            => await _context.Events
            .Include(x => x.Address)
            .Include(x => x.Participants)
                .ThenInclude(p => p.User)
                    .ThenInclude(u => u.MyRatings)
            .Include(x => x.Participants)
                .ThenInclude(p => p.User)
                    .ThenInclude(u => u.FavouriteFoodType)
            .ToListAsync();

        public async Task<List<Event>> GetEventsAsync(Expression<Func<Event, bool>> predicate)
            => await _context.Events
            .Where(predicate)
            .Include(x => x.Address)
            .Include(x => x.Participants)
                .ThenInclude(p => p.User)
                    .ThenInclude(u => u.MyRatings)
            .Include(x => x.Participants)
                .ThenInclude(p => p.User)
                    .ThenInclude(u => u.FavouriteFoodType)
            .ToListAsync();


        public void AddEventUser(EventUser eventUser)
        {
            _context.EventUsers.Add(eventUser);
        }

        public async Task RemoveAsync(Guid id)
        {
            var eventObject = await GetAsync(id);
            if (eventObject != null)
            {
                _context.Events.Remove(eventObject);
            }
            await Task.CompletedTask;
        }
    }
}
