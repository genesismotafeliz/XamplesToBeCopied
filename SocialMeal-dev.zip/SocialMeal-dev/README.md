# SocialMeal
Open source social networking site for people who want to eat together
It is only API for application in ASP.NET Core Web API, Android application is here:
https://github.com/stramek/FoodShare

## Introduction

Social meal is an application that allows people to meet at a shared meal. 
The main purpose of the application is to improve interpersonal relationships, make new friends and a way to spend free time.
The application is dedicated to people who like to cook and willingly share a meal and also for people who like to eat well.

## Upcoming Features And Changes.

This is begining of development. At this moment project include:
- onion architecture
- basic model classes
- configured Entity Framework Core with migrations
- swagger
- authorization with JSON Web Token (access and refresh)
- custom error handling
- registration new users 
- login 
- reset password
- creation and modification my profile 
- creation event
- rating other event participant
- random testing data in data base initializer
- searchin events by localization, food type, price
- login with FB

Upcoming Features
- update avatar
- login with Twitter

## Instalation

- download Zip or git clone repo: https://github.com/Arkaady/SocialMeal.git
- requires .NET Standart 2.0
- required Visual Studio 2015 or higher/ Visual Studio Code
- reguired MSSQL Server 
- appsettings.json change SQL conection string to you ms sql server
- you can use also version for test, address: http://35.177.178.135/swagger/#/

## License
- MIT
