﻿namespace SocialMeal.Core.Exceptions
{
    public static class ErrorCodes
    {
        public static string InvalidUsername => "invalid_username";
        public static string InvalidEmail => "invalid_email";
        public static string InvalidRole => "invalid_role";
        public static string InvalidPassword => "invalid_password";
        public static string InvalidResetCode => "invalid_reset_code";
        public static string InvalidEventName => "invalid_event_name";
        public static string InvalidEventDate => "invalid_event_date";
        public static string InvalidEventPlace => "invalid_event_place";
        public static string InvalidEventMembersNumer => "invalid_event_members_number";
        public static string InvalidAddress => "invalid_address";
        public static string InvalidRating => "invalid_rating";
        public static string InvalidRatingDate => "invalid_rating_date";
        public static string InvalidEventPrice => "invalid_event_price";
        public static string InvalidEventDescription => "invalid_event_description";
    }
}
