﻿namespace SocialMeal.Core.Domain
{
    public enum FoodType
    {
        Italian = 0,
        French = 1
    }
}
