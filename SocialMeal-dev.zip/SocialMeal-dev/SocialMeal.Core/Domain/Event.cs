﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using SocialMeal.Core.Exceptions;

namespace SocialMeal.Core.Domain
{
    public class Event
    {
        public Guid Id { get; protected set; }

        public string Name { get; protected set; }

        public DateTime Date { get; protected set; }

        public decimal Price { get; protected set; }

        public FoodType FoodType { get; protected set; }

        public string Description { get; protected set; }

        public int MembersAmount { get; protected set; }

        public Address Address { get; set; }

        public Guid OwnerId { get; set; }

        public User Owner { get; set; }

        public ICollection<EventUser> Participants { get; set; }

        private DateTime CreatedAt { get; set; }

        public DateTime? UpdatedAt { get; protected set; }

        protected Event()
        {
        }

        public Event(string name, DateTime date, FoodType foodType, int members, Address address)
        {
            Id = Guid.NewGuid();
            SetName(name);
            SetDate(date);
            SetFoodType(foodType);
            SetMembersAmount(members);
            Address = new Address(address.City, address.Street, address.Number);
            CreatedAt = DateTime.UtcNow;
            Participants = new List<EventUser>();
        }

        public void SetName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new DomainException(ErrorCodes.InvalidEventName, "Event name is required.");
            }
            if (name.Length > 50)
            {
                throw new DomainException(ErrorCodes.InvalidEventName, "Event name cannot be longer then 50 characters.");
            }
            if (Name == name)
                return;
            
            Name = name;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetDate(DateTime date)
        {
            if (date < DateTime.UtcNow)
            {
                throw new DomainException(ErrorCodes.InvalidEventDate, "Event date must be in the future");
            }
            if (date == Date)
                return;

            Date = date;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetFoodType(FoodType foodType)
        {
            if (FoodType == foodType) return;
            FoodType = foodType;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetMembersAmount(int members)
        {
            if (members <= 1)
            {
                throw new DomainException(ErrorCodes.InvalidEventMembersNumer, "Event has to have more than 1 member");
            }
            if (members > 100)
            {
                throw new DomainException(ErrorCodes.InvalidEventMembersNumer, "Event can not have more than 100 participants");
            }
            if (members == MembersAmount)
                return;

            MembersAmount = members;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetPrice(decimal price)
        {
            if (price < 0)
            {
                throw new DomainException(ErrorCodes.InvalidEventPrice, "Event price can not be lower than 0");
            }
            if (price == Price)
                return;
            Price = price;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetDescription(string description)
        {
            if (description.Length > 500)
            {
                throw new DomainException(ErrorCodes.InvalidEventDescription, "Event description can not be longer then 500 characters.");
            }
            if (Description == description)
                return;

            Description = description;
            UpdatedAt = DateTime.UtcNow;
        }
    }
}
