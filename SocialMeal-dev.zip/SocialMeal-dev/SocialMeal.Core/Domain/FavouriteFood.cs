﻿namespace SocialMeal.Core.Domain
{
    public class FavouriteFood
    {
        public int Id { get; set; }

        public FoodType Name { get; set; }

        public User User { get; set; }
    }
}
