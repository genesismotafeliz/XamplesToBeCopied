﻿using SocialMeal.Core.Exceptions;

namespace SocialMeal.Core.Domain
{
    public class Address
    {
        public long Id { get; protected set; }
        public string City { get; protected set; }
        public string Street { get; protected set; }
        public string Number { get; protected set; }

        protected Address()
        {   
        }

        public Address(string city, string street, string number)
        {
            SetCity(city);
            SetStreet(street);
            SetNumber(number);
        }

        public void SetCity(string city)
        {
            if (string.IsNullOrEmpty(city))
            {
                throw new DomainException(ErrorCodes.InvalidAddress, "City name can not be null or empty");
            }
            if (city.Length > 50)
            {
                throw new DomainException(ErrorCodes.InvalidAddress, "City name can not be longet than 50 characters");
            }
            if (City == city)
                return;

            City = city;
        }

        public void SetStreet(string street)
        {
            if (string.IsNullOrEmpty(street))
            {
                throw new DomainException(ErrorCodes.InvalidAddress, "Street name can not be null or empty");
            }
            if (street.Length > 50)
            {
                throw new DomainException(ErrorCodes.InvalidAddress, "Street name can not be longet than 50 characters");
            }
            if (Street == street)
                return;

            Street = street;
        }

        public void SetNumber(string number)
        {
            if (number.Length > 50)
            {
                throw new DomainException(ErrorCodes.InvalidAddress, "Number can not be longet than 50 characters");
            }
            if (Number == number)
                return;

            Number = number;
        }
    }
}
