﻿using System;
using SocialMeal.Core.Exceptions;

namespace SocialMeal.Core.Domain
{
    public class Rating
    {
        public Guid RatedUserId { get; set; }

        public Guid RatingUserId { get; set; }

        public User RatedUser { get; set; }

        public User RatingUser { get; set; }

        public int Rate { get; set; }

        public DateTime Date { get; set; }

        protected Rating()
        {
        }

        public Rating(int rate, DateTime date)
        {
            SetRating(rate);
            SetDate(date);
        }

        private void SetRating(int rate)
        {
            if (rate < 0)
            {
                throw new DomainException(ErrorCodes.InvalidRating, "Rating can not be smaller than 0");
            }

            if (rate > 5)
            {
                throw new DomainException(ErrorCodes.InvalidRating, "Rating can not be bigger than 5");
            }

            if (Equals(rate, Rate))
                return;
            Rate = rate;
        }

        private void SetDate(DateTime date)
        {
            if (date > DateTime.UtcNow)
            {
                throw new DomainException(ErrorCodes.InvalidRatingDate, "Date can not be from the future");
            }

            if (Date == date)
                return;
            Date = date;
        }
    }
}