﻿using System;

namespace SocialMeal.Core.Domain
{
    public class EventUser
    {
        public Guid UserId { get; set; }

        public Guid EventId { get; set; }

        public User User { get; set; }

        public Event Event { get; set; }

        protected EventUser()
        { 
        }

        public EventUser(User user, Event eventObject)
        {
            User = user;
            Event = eventObject;
        }
    }

}
