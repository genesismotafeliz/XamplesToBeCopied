﻿namespace SocialMeal.Core.Domain
{
    public enum Role
    {
        Admin = 0,
        User = 1
    }
}
