﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using SocialMeal.Core.Exceptions;

namespace SocialMeal.Core.Domain
{
    public class User
    {
        private static readonly Regex EmailRegex = new Regex(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$");

        public Guid Id { get; protected set; }

        public string Email { get; protected set; }

        public string Password { get; protected set; }

        public string Salt { get; protected set; }

        public string FirstName { get; protected set; }

        public string Surname { get; protected set; }

        public string Thumbnail { get; protected set; }

        public string Description { get; protected set; }

        public ICollection<Rating> SendedRatings { get; protected set; }

        public ICollection<Rating> MyRatings { get; protected set; }

        public Role Role { get; protected set; }

        public ICollection<FavouriteFood> FavouriteFoodType { get; protected set; }

        public ICollection<EventUser> Events { get; protected set; }

        public ICollection<Event> MyEvents { get; set; }

        public string ResetCode { get; protected set; }

        public int LoginCount { get; protected set; }

        public DateTime? ResetCodeCreateTime { get; protected set; }

        public ICollection<Session> Sessions { get; protected set; }

        public DateTime CreatedAt { get; protected set; }

        public DateTime UpdatedAt { get; protected set; }


        protected User()
        {
            Sessions = new HashSet<Session>();
            FavouriteFoodType = new List<FavouriteFood>();
            SendedRatings = new List<Rating>();
            MyRatings = new List<Rating>();
            Events = new List<EventUser>();
            MyEvents = new List<Event>();
        }

        public User(Guid userId, string email, string password, string firstName, string surname, string salt, Role role) : this()
        {
            Id = userId;
            SetEmail(email);
            SetPassword(password);
            SetFirstName(firstName);
            SetSurname(surname);
            SetRole(role); 
            SetSalt(salt);
            CreatedAt = DateTime.UtcNow;
            LoginCount = 0;
        }

        public void SetEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                throw new DomainException(ErrorCodes.InvalidEmail, "Email can not be empty");
            }
            if (!EmailRegex.Match(email).Success)
            {
                throw new DomainException(ErrorCodes.InvalidEmail, "Invalid email.");
            }
            if (email.Length > 255)
            {
                throw new DomainException(ErrorCodes.InvalidEmail, "Email can not be longer than 255 characters");
            }
            if (Email == email)
                return;

            Email = email;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
            {
                throw new DomainException(ErrorCodes.InvalidPassword, "password can not be empty");
            }
            if (password.Length < 6)
            {
                throw new DomainException(ErrorCodes.InvalidPassword, "password has to be longer than 6 characters");
            }
            if (password.Length > 255)
            {
                throw new DomainException(ErrorCodes.InvalidPassword, "password can not be longer than 255 characters");
            }
            if (Password == password)
                return;

            Password = password;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetSalt(string salt)
        {
            if (string.IsNullOrWhiteSpace(salt))
            {
                throw new DomainException(ErrorCodes.InvalidPassword, "password can not be empty");
            }
            if (salt.Length > 255)
            {
                throw new DomainException(ErrorCodes.InvalidPassword, "password can not be longer than 255 characters");
            }
            if (Salt == salt)
                return;

            Salt = salt;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetRole(Role role)
        {
            if (Role == role) return;
            Role = role;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetFirstName(string firstName)
        {
            if (firstName == FirstName)
                return;
            if (string.IsNullOrWhiteSpace(firstName))
            {
                throw new DomainException("First name is required.");
            }
            if (firstName.Length > 50)
            {
                throw new DomainException("First name cannot be longer then 50 characters.");
            }
            FirstName = firstName;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetSurname(string surname)
        {
            if (surname == Surname)
                return;
            if (string.IsNullOrWhiteSpace(surname))
            {
                throw new DomainException("Surname is required.");
            }
            if (surname.Length > 50)
            {
                throw new DomainException("Surname cannot be longer then 50 characters.");
            }
            
            Surname = surname;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetThumbnail(string thumbnail)
        {
            if (thumbnail?.Length > 255)
            {
                throw new DomainException("Thumbnail path cannot be longer than 255 characters");
            }
            if (Thumbnail == thumbnail)
                return;

            Thumbnail = thumbnail;
            UpdatedAt = DateTime.UtcNow;
        }

        public void SetDescription(string description)
        {
            if (description.Length > 500)
            {
                throw new DomainException("description can not be longer than 500 characters");
            }
            if (Description == description)
                return;
            Description = description;
            UpdatedAt = DateTime.UtcNow;
        }

        public void IncreaseLoginNumber()
        {
            LoginCount += 1;
        }

        public void SetResetCode(string resetCode)
        {
            if (string.IsNullOrEmpty(resetCode))
            {
                throw new DomainException(ErrorCodes.InvalidResetCode, "reset code can not be empty");
            }
            if (resetCode.Length > 255)
            {
                throw new DomainException(ErrorCodes.InvalidResetCode, "Reset code can not be longaer than 255 characters");
            }
            if (resetCode == ResetCode)
                return;
            ResetCode = resetCode;
            ResetCodeCreateTime = DateTime.UtcNow;
            UpdatedAt = DateTime.UtcNow;
        }

        public void ClearResetCode()
        {
            ResetCode = null;
            ResetCodeCreateTime = null;
            UpdatedAt = DateTime.UtcNow;
        }
    }
}
