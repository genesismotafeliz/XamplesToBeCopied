﻿using System;

namespace SocialMeal.Core.Domain
{
    public class Session
    {
        public string DeviceId { get; protected set; }

        public string DeviceName { get; protected set; }

        public string Token { get; protected set; }

        public DateTime? LastRefresh { get; protected set; }

        public int RefreshCount { get; protected set; }

        public DateTime CreatedAt { get; protected set; }

        public DateTime UpdatedAt { get; protected set; }

        public DateTime Expires { get; protected set; }

        public User User { get; protected set; }

        public Guid UserId { get; protected set; }

        protected Session()
        {
        }

        public Session(string deviceId, string deviceName, string token, DateTime expires)
        {
            SetDevice(deviceId, deviceName);
            SetToken(token);
            SetExpires(expires);
            CreatedAt = DateTime.UtcNow;
            UpdatedAt = CreatedAt;
            RefreshCount = 0;
        }

        public void UpdateToken(string token, DateTime expires)
        {
            SetToken(token);
            SetExpires(expires);
            UpdatedAt = DateTime.UtcNow;
        }

        public bool IsExpired()
            => Expires <= DateTime.UtcNow;

        public void Refresh()
        {
            LastRefresh = DateTime.UtcNow;
            RefreshCount++;
        }

        private void SetDevice(string deviceId, string deviceName)
        {
            if (string.IsNullOrWhiteSpace(deviceId))
            {
                throw new Exception("DeviceId is required.");
            }
            if (string.IsNullOrWhiteSpace(deviceName))
            {
                throw new Exception("DeviceName is required.");
            }
            if (deviceId.Length > 255)
            {
                throw new Exception("DeviceId cannot be longer then 255 characters.");
            }
            if (deviceName.Length > 255)
            {
                throw new Exception("DeviceName cannot be longer then 255 characters.");
            }
            if (DeviceId == deviceId)
                return;

            DeviceId = deviceId;
            DeviceName = deviceName;
            UpdatedAt = DateTime.UtcNow;
        }

        private void SetToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new Exception("Token is required.");
            }
            if (token.Length > 255)
            {
                throw new Exception("Token cannot be longer then 255 characters.");
            }
            if (Token == token)
                return;

            Token = token;
        }

        private void SetExpires(DateTime expires)
        {
            if (expires <= DateTime.UtcNow)
            {
                throw new Exception("Expires must be in the future.");
            }
            if (Expires == expires)
                return;

            Expires = expires;
        }
    }
}
