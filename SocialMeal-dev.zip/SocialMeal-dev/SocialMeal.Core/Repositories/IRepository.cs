﻿namespace SocialMeal.Core.Repositories
{
    public interface IRepository
    {
    }
}
