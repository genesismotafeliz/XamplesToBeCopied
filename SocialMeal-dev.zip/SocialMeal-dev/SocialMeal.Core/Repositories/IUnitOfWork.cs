﻿using System.Threading.Tasks;

namespace SocialMeal.Core.Repositories
{
    public interface IUnitOfWork
    {
        IUserRepository Users { get; }
        IEventRepository Events { get; }

        Task CompleteAsync();
    }
}
