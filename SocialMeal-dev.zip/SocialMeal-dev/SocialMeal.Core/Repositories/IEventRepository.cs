﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using SocialMeal.Core.Domain;

namespace SocialMeal.Core.Repositories
{
    public interface IEventRepository : IRepository
    {
        void AddAsync(Event eventObject);
        Task<Event> GetAsync(Guid id);
        Task<List<Event>> GetAllAsync();
        Task RemoveAsync(Guid id);
        Task<List<Event>> GetEventsAsync(Expression<Func<Event, bool>> predicate);
        void AddEventUser(EventUser eventUser);
    }
}
