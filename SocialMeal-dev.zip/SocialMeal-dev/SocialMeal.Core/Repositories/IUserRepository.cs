﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SocialMeal.Core.Domain;

namespace SocialMeal.Core.Repositories
{
    public interface IUserRepository : IRepository
    {
        Task AddAsync(User user);
        Task<User> GetAsync(Guid id);
        Task<User> GetAsync(string email);
        Task<User> GetByResetCodeAsync(string resetCode);
        Task<List<User>> GetAllAsync(string email);
        Task RemoveAsync(Guid id);
    }
}
