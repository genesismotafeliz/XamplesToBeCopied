﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using Moq;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Extensions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services;
using SocialMeal.Infrastructure.Services.Interfaces;
using Xunit;

namespace SocialMeal.Tests.ServiceTests
{

    public class AccountServiceTests
    {
        private Mock<IUnitOfWork> _unitOfWork;
        private Mock<IEncrypter> _encrypter;
        private Mock<IJwtHandler> _jwtHandler;
        private Mock<IEmailService> _emailService;
        private Mock<IMapper> _mapper;
        private Mock<IFacebookService> _facebookService;
        private AccountService _accountService;
        private User _user;
        private RegisterResource _registerResource;
        private LoginResource _loginresource;
        private FacebookLoginResource _facebookLoginresource;
        private FacebookUserResource _facebookUserResource;

        public AccountServiceTests()
        {
            _unitOfWork = new Mock<IUnitOfWork>();
            _encrypter = new Mock<IEncrypter>();
            _jwtHandler = new Mock<IJwtHandler>();
            _emailService = new Mock<IEmailService>();
            _facebookService = new Mock<IFacebookService>();
            _mapper = new Mock<IMapper>();

            _accountService = new AccountService(_unitOfWork.Object, _encrypter.Object, _jwtHandler.Object, _emailService.Object, _facebookService.Object, _mapper.Object);

            _user = new User(Guid.NewGuid(), "user@user.com", "password", "firstName", "Surname", "salt", Role.User);
            _user.SetResetCode(Guid.NewGuid().ToString());

            _facebookUserResource = new FacebookUserResource
            {
                FirstName = _user.FirstName,
                Email = _user.Email,
                LastName = _user.Surname
            };

            _facebookLoginresource = new FacebookLoginResource
            {
                facebookToken = "token",
                DeviceName = "deviceName",
                DeviceId = "deviceId"
            };

            _encrypter.Setup(e => e.GetSalt(It.IsAny<string>())).Returns(_user.Salt);
            _encrypter.Setup(e => e.GetHash(It.IsAny<string>(), It.IsAny<string>())).Returns(_user.Password);

            _unitOfWork.Setup(x => x.Users.GetAsync(_user.Email))
                .ReturnsAsync(_user);

            _unitOfWork.Setup(x => x.Users.GetAsync(_user.Id))
                .ReturnsAsync(_user);

            _unitOfWork.Setup(x => x.Users.GetByResetCodeAsync(_user.ResetCode))
                .ReturnsAsync(_user);

            _jwtHandler.Setup(x => x.CreateAccessToken(_user.Id, _user.Email, _user.Role))
                .Returns(new TokenResource());

            _jwtHandler.Setup(x => x.CreateRefreshToken(_user.Id))
                .Returns(new TokenResource
                {
                    Token = "token",
                    Expiry = DateTime.UtcNow.AddMinutes(5).ToTimeStamp()
                });

            _facebookService.Setup(x => x.GetUserFromFacebookAsync(It.IsAny<string>()))
                .ReturnsAsync(_facebookUserResource);

            _registerResource = new RegisterResource
            {
                Email = "newUser@user.com",
                Password = "password1",
                FirstName = "firstName",
                Surname = "surname"
            };

            _loginresource = new LoginResource
            {
                Email = _user.Email,
                Password = _user.Password,
                DeviceId = "deviceId",
                DeviceName = "deviceName"
            };

            _mapper.Setup(x => x.Map<RegisterResource>(It.IsAny<FacebookUserResource>()))
                .Returns(_registerResource);
        }

    

        #region RegisterAsync

        [Fact]
        public async Task RegisterAsync_should_throw_exception_when_email_is_taken()
        {
            _registerResource.Email = _user.Email;

            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _accountService.RegisterAsync(_registerResource, Role.User));

            Assert.Equal(exception.Code, ErrorCodes.InvalidEmail);
        }

        [Fact]
        public async Task RegisterAsync_should_register_new_user()
        {
            await _accountService.RegisterAsync(_registerResource, Role.User);

            _unitOfWork.Verify(x => x.CompleteAsync(), Times.Once);
        }

        #endregion


        #region LoginAsync

        [Fact]
        public async Task LoginAsync_should_throw_exception_when_user_not_exist()
        {
            _loginresource.Email = "wrong@Email.com";

            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _accountService.LoginAsync(_loginresource));

            Assert.Equal(exception.Code, ErrorCodes.InvalidCredentials);
        }

        [Fact]
        public async Task LoginAsync_should_return_tokens()
        {
            var tokens = await _accountService.LoginAsync(_loginresource);

            Assert.NotNull(tokens);
            _unitOfWork.Verify(x => x.CompleteAsync(), Times.Once);
        }

        #endregion

        #region FacebookLogin

        [Fact]
        public async Task FacebookLogin_should_throw_exception_ehen_facebook_token_is_null_or_empty()
        {
            _facebookLoginresource.facebookToken = "";

            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _accountService.FacebookLoginAsync(_facebookLoginresource));

            Assert.Equal(exception.Code, ErrorCodes.InvalidFacebookToken);
        }

        [Fact]
        public async Task FacebookLogin_should_login_user()
        {
            var tokens = await _accountService.FacebookLoginAsync(_facebookLoginresource);

            Assert.NotNull(tokens);
            _unitOfWork.Verify(x => x.CompleteAsync(), Times.Once);
        }

        #endregion

        #region ForgotPassword

        [Fact]
        public async Task ForgotPassword_should_throw_exception_when_user_not_exist()
        {
            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _accountService.ForgotPassword("notexisting@email.com"));

            Assert.Equal(exception.Code, ErrorCodes.InvalidEmail);
        }

        [Fact]
        public async Task ForgotPassword_should_send_reset_code()
        {
            await _accountService.ForgotPassword(_user.Email);

            _unitOfWork.Verify(x => x.CompleteAsync(), Times.Once);
        }

        #endregion

        #region ResetPassword

        [Fact]
        public async Task ResetPassword_should_throw_exception_when_user_with_sender_code_not_exist()
        {
            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _accountService.ResetPassword(Guid.NewGuid().ToString(), _user.Password));

            Assert.Equal(exception.Code, ErrorCodes.InvalidResetCode);
        }

        #endregion
    }
}
