﻿using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Moq;
using SocialMeal.Core.Domain;
using SocialMeal.Core.Exceptions;
using SocialMeal.Core.Repositories;
using SocialMeal.Infrastructure.Exceptions;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services;
using Xunit;
using ErrorCodes = SocialMeal.Infrastructure.Exceptions.ErrorCodes;
using ErrorCodesDomain = SocialMeal.Core.Exceptions.ErrorCodes;

namespace SocialMeal.Tests.ServiceTests
{
    public class RatingServiceTests
    {
        private Mock<IMapper> _mapper;
        private Mock<IUnitOfWork> _unitOfWork;
        private User _user;
        private User _ratedUser;
        private RatingResource _ratingResource;
        private RatingService _ratingService;

        public RatingServiceTests()
        {
            _mapper = new Mock<IMapper>();
            _unitOfWork = new Mock<IUnitOfWork>();
            _user = new User(Guid.NewGuid(), "user@test.com", "Test123", "firstName", "surname", "salt", Role.User);
            _ratedUser = new User(Guid.NewGuid(), "ratedUser@test.com", "Test123", "firstName", "surname", "salt", Role.User);
            _ratingResource = new RatingResource
            {
                Rate = 4,
                Date = DateTime.UtcNow,
                UserId = _ratedUser.Id
            };

            _unitOfWork.Setup(x => x.Users.GetAsync(_user.Id))
                .ReturnsAsync(_user);

            _unitOfWork.Setup(x => x.Users.GetAsync(_ratedUser.Id))
                .ReturnsAsync(_ratedUser);

            _ratingService = new RatingService(_unitOfWork.Object, _mapper.Object);
        }

        [Fact]
        public async Task RatedUser_should_throw_exception_when_rated_user_not_exist()
        {
            _ratingResource.UserId = Guid.NewGuid();

            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _ratingService.RateUser(_user.Id, _ratingResource));

            Assert.Equal(exception.Code, ErrorCodes.UserNotExist);
        }

        [Fact]
        public async Task RatedUser_should_throw_exception_when_user_trying_rate_himself()
        {
            _ratingResource.UserId = _user.Id;

            var exception = await Assert.ThrowsAsync<ServiceExceptions>(async () =>
                await _ratingService.RateUser(_user.Id, _ratingResource));

            Assert.Equal(exception.Code, ErrorCodes.InvalidRating);
        }

        [Fact]
        public async Task RatedUser_should_throw_exception_when_rate_is_bigger_than_5()
        {
            _ratingResource.Rate = 6;

            var exception = await Assert.ThrowsAsync<DomainException>(async () =>
                await _ratingService.RateUser(_user.Id, _ratingResource));

            Assert.Equal(exception.Code, ErrorCodesDomain.InvalidRating);
        }

        [Fact]
        public async Task RatedUser_should_throw_exception_when_rate_is_lesser_than_0()
        {
            _ratingResource.Rate = -1;

            var exception = await Assert.ThrowsAsync<DomainException>(async () =>
                await _ratingService.RateUser(_user.Id, _ratingResource));

            Assert.Equal(exception.Code, ErrorCodesDomain.InvalidRating);
        }

        [Fact]
        public async Task RatedUser_should_throw_exception_when_date_is_from_the_future()
        {
            _ratingResource.Date = DateTime.UtcNow.AddDays(1);

            var exception = await Assert.ThrowsAsync<DomainException>(async () =>
                await _ratingService.RateUser(_user.Id, _ratingResource));

            Assert.Equal(exception.Code, ErrorCodesDomain.InvalidRatingDate);
        }

        [Fact]
        public async Task RatedUser_should_add_new_rate()
        {
            await _ratingService.RateUser(_user.Id, _ratingResource);

            _unitOfWork.Verify(x => x.CompleteAsync());
        }
    }
}
