﻿using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialMeal.Infrastructure.Data;
using SocialMeal.Infrastructure.Services;
using SocialMeal.Infrastructure.Services.Interfaces;

namespace SocialMeal.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = BuildWebHost(args);

            using (var scope = host.Services.CreateScope())
            {
                var service = scope.ServiceProvider;
                try
                {
                    var context = service.GetRequiredService<SocialMealContext>();
                    var accountService = service.GetRequiredService<IAccountService>();
                    var ratingService = service.GetRequiredService<IRatingService>();
                    var eventService = service.GetRequiredService<IEventService>();

                    var dbInitialize = new DbInitiaizer();
                    dbInitialize.Initialize(context, accountService, ratingService, eventService).ConfigureAwait(false).GetAwaiter().GetResult();
                }
                catch (Exception e)
                {
                    var logger = service.GetRequiredService<ILogger<Program>>();
                    logger.LogError(e, "Error while seeding database");
                }
            }

            host.Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}

