﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SocialMeal.API.Controllers
{
    public class ProfileController : Controller
    {
        private readonly IProfileService _profileService;

        public ProfileController(IProfileService profileService)
        {
            _profileService = profileService;
        }

        [HttpGet]
        [Authorize]
        [Route("me/profile")]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(BasicUserResource))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetMyProfile()
        {
            var userId = new Guid(User.Identity.Name);
            var userProfile = await _profileService.GetProfile(userId);
            return Ok(userProfile);
        }

        [HttpPut]
        [Authorize]
        [Route("me/profile")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> UpdateMyProfile([FromBody]ProfileResource profile)
        {
            var userId = new Guid(User.Identity.Name);
            await _profileService.UpdateProfile(userId, profile);
            return Ok();
        }

        [HttpPut]
        [Authorize]
        [Route("me/avatar")]
        [RequestSizeLimit(10000000)]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UpdateAvatar(IFormFile avatar)
        {
            var userId = new Guid(User.Identity.Name);
            await _profileService.UpdateAvatar(userId, avatar);
            return Ok();
        }
    }
}