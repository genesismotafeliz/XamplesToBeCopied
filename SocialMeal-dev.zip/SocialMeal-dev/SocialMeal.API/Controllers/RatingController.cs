﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SocialMeal.API.Controllers
{
    public class RatingController : Controller
    {
        private readonly IRatingService _ratingService;

        public RatingController(IRatingService ratingService)
        {
            _ratingService = ratingService;
        }

        [HttpPut]
        [Authorize]
        [Route("rating")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> UpdateMyProfile([FromBody]RatingResource ratingResource)
        {
            var userId = new Guid(User.Identity.Name);
            await _ratingService.RateUser(userId, ratingResource);
            return Ok();
        }
    }
}