﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SocialMeal.API.Controllers
{
    public class EventController : Controller
    {
        private readonly IEventService _eventService;

        public EventController(IEventService eventService)
        {
            _eventService = eventService;
        }

        [HttpGet]
        [Route("me/events")]
        [Authorize]
        [SwaggerResponse((int) HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int) HttpStatusCode.BadRequest)]
        [SwaggerResponse((int) HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetMyEvents()
        {
            var userId = new Guid(User.Identity.Name);
            var events = await _eventService.GetUserEventsAsync(userId);
            return Ok(events);
        }

        [HttpPost]
        [Route("me/event")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> AddEvent([FromBody]NewEventResource resource)
        {
            var userId = new Guid(User.Identity.Name);
            await _eventService.AddEventAsync(userId, resource);
            return Ok();
        }

        [HttpPut]
        [Route("me/event")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> EditEvent([FromBody]EventResource resource)
        {
            var userId = new Guid(User.Identity.Name);
            await _eventService.EditEventAsync(userId, resource);
            return Ok();
        }

        [HttpGet]
        [Route("events")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _eventService.GetAllEventsAsync();
            return Ok(events);
        }

        [HttpGet]
        [Route("event/{id}")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(EventResource))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventById(Guid id)
        {
            var result = await _eventService.GetEventAsync(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("events/{ownerId}")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByOwner(Guid ownerId)
        {
            var events = await _eventService.GetEventsByOwer(ownerId);
            return Ok(events);
        }

        [HttpGet]
        [Route("events/{name}")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByOwner(string name)
        {
            var events = await _eventService.GetEventsByName(name);
            return Ok(events);
        }

        [HttpGet]
        [Route("events/date")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByDate(DateTime? from = null, DateTime? to = null)
        {
            var events = await _eventService.GetEventsByDateAsync(from, to);
            return Ok(events);
        }

        [HttpGet]
        [Route("events/price")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByPrice(decimal? minPrice = null, decimal? maxPrice = null)
        {
            var events = await _eventService.GetEventsByPrice(minPrice, maxPrice);
            return Ok(events);
        }

        [HttpGet]
        [Route("events/foodType")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByPrice(FoodType foodType)
        {
            var events = await _eventService.GetEventsByFoodType(foodType);
            return Ok(events);
        }

        [HttpGet]
        [Route("events/members")]
        [Authorize]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(List<EventResource>))]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetEventsByPrice(int? minMembers = null, int? maxMembers = null)
        {
            var events = await _eventService.GetEventsByMemberAmout(minMembers, maxMembers);
            return Ok(events);
        }
    }
}
