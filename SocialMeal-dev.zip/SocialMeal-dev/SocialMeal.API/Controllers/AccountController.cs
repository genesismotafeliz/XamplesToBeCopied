﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialMeal.Core.Domain;
using SocialMeal.Infrastructure.Resources;
using SocialMeal.Infrastructure.Services.Interfaces;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SocialMeal.API.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpPost]
        [Route("account/register")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> RegisterAsync([FromBody]RegisterResource resource)
        {
            await _accountService.RegisterAsync(resource, Role.User);
            return Ok();
        }

        [HttpPost]
        [Route("account/login")]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(AuthorizationTokensResource))]
        public async Task<IActionResult> LoginAsync([FromBody]LoginResource resource)
        {
            var authorizationTokens = await _accountService.LoginAsync(resource);
            return Ok(authorizationTokens);
        }

        [HttpPost]
        [Route("account/login/facebook")]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(AuthorizationTokensResource))]
        public async Task<IActionResult> FacebookLoginAsync([FromBody] FacebookLoginResource resource)
        {
            var authorizationTokens = await _accountService.FacebookLoginAsync(resource);
            return Ok(authorizationTokens);
        }

        [HttpPost]
        [Authorize]
        [Route("account/refreshToken")]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        [SwaggerResponse((int)HttpStatusCode.Unauthorized)]
        [SwaggerResponse((int)HttpStatusCode.OK, typeof(TokenResource))]
        public async Task<IActionResult> RefreshToken([FromBody]RefreshTokenResource resource)
        {
            var userId = new Guid(User.Identity.Name);
            var accesToken = await _accountService.RefreshToken(userId, resource.RefreshToken);
            return Ok(accesToken);
        }

        [HttpPost]
        [Route("account/forgot-password")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ForgotPassword([FromBody]ForgotPasswordResource resource)
        {
            await _accountService.ForgotPassword(resource.Email);
            return Ok();
        }

        [HttpPost]
        [Route("account/reset-password")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        [SwaggerResponse((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ResetPassword([FromBody]ResetPasswordResource resource)
        {
            await _accountService.ResetPassword(resource.Code, resource.Password);
            return Ok();
        }
    }
}