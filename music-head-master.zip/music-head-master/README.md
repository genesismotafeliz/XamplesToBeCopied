I stored this code mostly for historic purposes.  
Long time ago, in 2008 or even early (it's long time for me)  
I was very inspired to write social network for musicians and I did it.  
Here in Russia we have long holidays (~10 days) starting from 1 January, main part of code was written in this time period,
and after I was improving it some time, last chages were made at 2010 year.  

Source code is C# for asp.net WebForms. Db - MySql.  
Code is a bit naive for today, but I have too good memories for this project, to just drop the code away.  
If someone will be interesting in this project, fill free to take code and use it as u wish.
