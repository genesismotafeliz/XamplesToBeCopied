﻿SET NAMES 'utf8';
insert into commentsubjtables (Id, TableName) values (1, 'lyrics');
insert into commentsubjtables (Id, TableName) values (2, 'music');
insert into commentsubjtables (Id, TableName) values (3, 'video');
insert into commentsubjtables (Id, TableName) values (4, 'images');

