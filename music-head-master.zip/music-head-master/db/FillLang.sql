﻿SET NAMES 'utf8';
insert into site_language (LangCode, Text) values("en", "English");
insert into site_language (LangCode, Text) values("ru", "Русский");